===========================================

Original data file:

    OF_5m5m_V1_0.dat

The 5mx5m OF.

===========================================

Original data in my format:

    OF_5m5m_my_format.dat

The program for doing the format transform is in a single file:

    OF_to_my_format.cpp

So it is straightforward to compile and run.

===========================================

Shift of half interval in longitude is done
by the single file program

    OF_rm_lon_shift.cpp

What it does is to generate the file

    longitudeShift.txt

and then call

    longitudeShift

to perform the longitudinal shift for the 0.5mx0.5m OF that may be
used for generating lower resolution OFs.

The result is in the files:

    OF_5m5m_my_format_no_shift.dat

"no_shift" means the first grid point in longitude
is not shifted half the grid interval, i.e. it is
0 instead of half the grid interval as in the
original data.

The OF in this file is not truncated to integers. They are to be
used to generate lower resolution OFs. Not truncating at this stage
preserves the cos-Fourier coefficients of the original data.

=============================================

Generation of OF for any grid is done using the
program

OF_generate.cpp

See

README_OF_generate.txt

for detailed explanation.

=============================================

The files 

OF_5m5m_my_format.dat and OF_5m5m_my_format_no_shift.dat

are too large, and are not included in the uploaded .7z files. The user can 
generate them by compiling and running the programs 

OF_to_my_format.cpp and OF_rm_lon_shift.cpp


