#include <cmath>
#include <cstdlib> 
#include <iostream>
#include <fstream>

#include "check_error.h"

using namespace std;
 
int main(int argc,char *argv[])
{
    string sourcefile;

    cout<<endl
        <<"Usage: OF_generate [file]"<<endl
        <<"   Input data locations are specified in [file]"<<endl
        <<"   The default for [file] is \"OF_generate.txt\""<<endl
        <<"   Sea README_OF_generate.txt for detail description"<<endl;
           
    if(argc==1)
    {
        sourcefile="OF_generate.txt";    
    }
    else if(argc==2)
    {
        sourcefile=argv[1];
    }
    else    
    {
        cout<<"Too many arguments"<<endl;
        exit(1);     
    }

    cout<<endl<<"Doing ..."<<endl;
     
    string iGL,oGL,own,ifile,ofile;
    int inlat,inlon,onlat,onlon;
    
    ifstream input;

    cout<<"Reading data from the file: "<<sourcefile<<endl;
   
    input.open(sourcefile.c_str());
    
    input>>iGL;
    check_error(!(iGL=="Gauss"||iGL=="Lobbato"), "Must be Gauss or Lobbata");
    input>>inlat;
    input>>inlon;
    input>>ifile;
    input>>oGL;
    check_error(!(oGL=="Gauss"||oGL=="Lobbato"), "Must be Gauss or Lobbata");
    input>>own;
    check_error(!(own=="wShift"||own=="nShift"), "Must be wShift or nShift");
    input>>onlat;
    input>>onlon;
    input>>ofile;    

    input.close();
   
    cout<<"Reading complete"<<endl;
    ofstream out;

    out.open("TransformGrids.txt");
    
    out<<"floating"<<endl;
    out<<iGL<<endl;
    out<<inlat<<"  "<<inlon<<endl;
    out<<oGL<<endl;
    out<<onlat<<"  "<<onlon<<endl;
    out<<1<<endl;
    out<<ifile<<" "<<"tmp_file_OF_generate_nShift.txt"<<endl;
    
    out.close();
    
    system("TransformGrids TransformGrids.txt");
    
    if(own=="wShift")
    {
    
        out.open("longitudeShift.txt");
        
        out<<"addShift"<<endl;
        out<<onlat<<" "<<onlon<<endl;
        out<<1<<endl;
        out<<"tmp_file_OF_generate_nShift.txt tmp_file_OF_generate_wShift.txt"<<endl;
        
        out.close();
        
        system("longitudeShift longitudeShift.txt");
    }

    cout<<"rounding to 1 and 0"<<endl;

    string rfile;
    if(own=="nShift")rfile="tmp_file_OF_generate_nShift.txt";
    else rfile="tmp_file_OF_generate_wShift.txt";
    
    input.open(rfile.c_str());
    out.open(ofile.c_str());
    out.precision(9);
    double lat,lon,of;
    
    for(int k=0;k<onlat*onlon;k++)
    {
        input>>lat;
        input>>lon;   
        input>>of;
        
        out<<lat<<"  "<<lon<<"  ";
        if(of>=0.5)out<<"1";
        else out<<"0";
        out<<endl;
    }
    
    out.close();
    input.close();
    
    system("pause");
 //   
    return 0;   
}
