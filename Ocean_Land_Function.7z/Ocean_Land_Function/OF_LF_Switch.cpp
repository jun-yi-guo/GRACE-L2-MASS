#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

using namespace std;

int main()
{
    int nlat,nlon,of,i,N;
    double lat,lon;
    string ifile,ofile;
    
    ifstream ctrl("OF_LF_Switch.txt");
    
    ctrl>>nlat;
    ctrl>>nlon;
    ctrl>>ifile;
    ctrl>>ofile;

    ifstream input(ifile.c_str());
    ofstream output(ofile.c_str());
   
    N=nlat*nlon;

    for(i=0;i<N;i++)
    {
       input>>lat;
       input>>lon;
       input>>of;

       output<<lat<<"  "<<lon<<"  "<<1-of<<endl;
       
       if(i%50000==0)cout<<i<<" over "<<N<<" done"<<endl<<flush;
    }

//    system("pause");
    return 0;
}
