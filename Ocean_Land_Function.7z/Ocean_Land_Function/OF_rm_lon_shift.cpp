#include <cmath>
#include <cstdlib>
#include <iostream>
#include <fstream>

using namespace std;
 
int main()
{
  int i,j,k;
  
  ofstream ctl;
  
  ctl.open("longitudeShift.txt");
  
  ctl<<"rmShift"<<endl;
  ctl<<2160<<"  "<<4320<<endl;
  ctl<<1<<endl;
  ctl<<"OF_5m5m_my_format.dat  OF_5m5m_my_format_no_shift.dat"<<endl;
  
  ctl.close();
  
  system("longitudeShift longitudeShift.txt");

//

  ctl.open("longitudeShift.txt");
  
  ctl<<"rmShift"<<endl;
  ctl<<720<<"  "<<1440<<endl;
  ctl<<1<<endl;
  ctl<<"OF_0_25d0_25d_my_format.dat OF_0_25d0_25d_my_format_no_shift.dat"<<endl;
  
  ctl.close();

  system("longitudeShift longitudeShift.txt");

  return 0;   
}
 