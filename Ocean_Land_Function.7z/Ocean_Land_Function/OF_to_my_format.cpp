#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

int main()
{
    
    int numLat, numLon;
    ifstream input;
    ofstream out;
    
    int i,j,M;
    
    float delta;
    
    char str[80];
    
    float lat,lon;

    char of;    
    
    numLat=2160, numLon=4320;
    input.open("OF_5m5m_V1_0.dat");
    out.open("OF_5m5m_my_format.dat");
    
    out.precision(9);
    
    delta=360.0/numLon;


    cout<<"Doing ..."<<endl<<flush;
    
    for(i=0;i<10;i++)input.getline(str,80);

    for(i=0;i<numLat;i++)
    {
         M=i*numLon;
         lat=90.0-(i+0.5)*delta;
         for(j=0;j<numLon;j++)
         {
             lon=(j+0.5)*delta;
             input>>of;
             out<<lat<<"    "<<lon<<"    "<<of<<endl;
         }
    }
         
    input.close();
    out.close();
    
    
    numLat=720, numLon=1440;
    input.open("OF_0_25d0_25d_V1_0.dat");
    out.open("OF_0_25d0_25d_my_format.dat");
    
    out.precision(9);
    
    delta=360.0/numLon;

    cout<<"Doing ..."<<endl<<flush;
    
    for(i=0;i<10;i++)input.getline(str,80);

    for(i=0;i<numLat;i++)
    {
         M=i*numLon;
         lat=90.0-(i+0.5)*delta;
         for(j=0;j<numLon;j++)
         {
             lon=(j+0.5)*delta;
             input>>of;
             out<<lat<<"    "<<lon<<"    "<<of<<endl;
         }
    }
         
    input.close();
    out.close();

    numLat=72, numLon=144;
    input.open("OF_2_5d2_5d_V1_0.dat");
    out.open("OF_2_5d2_5d_my_format.dat");
    
    out.precision(9);
    
    
    delta=360.0/numLon;


    cout<<"Doing ..."<<endl<<flush;
    
    for(i=0;i<10;i++)input.getline(str,80);

    for(i=0;i<numLat;i++)
    {
         M=i*numLon;
         lat=90.0-(i+0.5)*delta;
         for(j=0;j<numLon;j++)
         {
             lon=(j+0.5)*delta;
             input>>of;
             out<<lat<<"    "<<lon<<"    "<<of<<endl;
         }
    }
         
    input.close();
    out.close();

	return 0; 
}
