=====================================================

This is a single file program. So it is straightforward
to compile. If g++ is used:

g++ OF_generate.cpp -o OF_generate

=====================================================

To excecute the program under Linux/Unix:

./OF_generate

or

./OF_generate FILE

The parameters telling what to do is given the FILE.
The default of FILE is OF_generate.txt.

This program calls

grid_conv

and

longitudeShift

so they must be in the working directory or path search
directory.

=====================================================

The parameters are set in FILE.

The first line should be "Gauss" or "Lobbato",
meaning the input data are over a Gauss or Lobbato
type grid.

The second line contains two integer values, which are,
respectively, the numbers of nodes in
latitude and longitude of the grid of input data.

The third line is the file name of input data.

The fourth line contains two strings. The first
should be "Gauss" or "Lobbato", meaning the output
data should be over a Gauss or Lobbato type grid
on latitude. The second one should be "wShift" or
"nShift", meaning the output data should be over
a longitudinal grid with half interval shift, or
no shift.

The fifth line contains two integer values, which are,
respectively, the numbers of nodes in latitude and
longitude of the grid of output data.

The sixth line is the file name of output data

************************************
*                                  *
*       An example of FILE         *
*                                  *
************************************

Gauss
2160 4320
OF_5m5m_my_format_no_shift.dat
Gauss wShift
72 144
OF_2_5d2_5d_my_result_with_shift.dat

=====================================================

Data format of input and output files:

Lat(0) Lon(0) Data(0,0)
Lat(0) Lon(1) Data(0,1)
....
Lat(1) Lon(0) Data(1,0)
Lat(1) Lon(1) Data(1,1)
....

Lat(0),Lat(1),.... should be in descending order,
from 90 to -90, and Lon(0),Lon(1),.... in ascending
order from 0 to 360. See example files as references.
Input data of grid are checked for correctness.
