#include <cstdlib>
#include <iostream>
#include <cmath>    
#include <fstream>   

#include "grid.h"
 
using namespace std;

int iland(int &J,int &K,mat<int>&lds)
{
    int j,k,n=0;
    for(j=0;j<lds.numRows();j++)
    for(k=0;k<lds.numCols();k++)
    {
        if(lds[j][k]==-1)
        {
            J=j;
            K=k;
            n++;
        }
    }
    return n;
}

int land(int type,int nland, mat<int>&lds)
{
    int j,k,J,K,n=0;
    
    int NLAT=lds.numRows();
    int NLON=lds.numCols();
    
    for(j=0;j<NLAT;j++)
    for(k=0;k<NLON;k++)
    {
        if(lds[j][k]==-1)
        {
            J=j;
            K=k-1;
            if(K<0)K=NLON+K;
            if(lds[J][K]==nland)
            {
                lds[j][k]=nland;
                n++;
            }
            
            K=k+1;
            if(K>=NLON)K=K-NLON;
            if(lds[J][K]==nland)
            {
                lds[j][k]=nland;
                n++;
            }
            
            if(j<NLAT-1)
            {
                J=j+1;
                K=k;
                if(lds[J][K]==nland)
                {
                    lds[j][k]=nland;
                    n++;
                }
                 
                if(type>0)
                {
                    K=k-1;
                    if(K<0)K=NLON+K;
                    if(lds[J][K]==nland)
                    {
                        lds[j][k]=nland;
                        n++;
                    }
                    
                    K=k+1;
                    if(K>=NLON)K=K-NLON;
                    if(lds[J][K]==nland)
                    {
                        lds[j][k]=nland;
                        n++;
                    }
                }
            }
            
            if(j>0)
            {
                J=j-1;
                K=k;
                if(lds[J][K]==nland)
                {
                    lds[j][k]=nland;
                    n++;
                }
                 
                if(type>0)
                {
                    K=k-1;
                    if(K<0)K=NLON+K;
                    if(lds[J][K]==nland)
                    {
                        lds[j][k]=nland;
                        n++;
                    }
                    
                    K=k+1;
                    if(K>=NLON)K=K-NLON;
                    if(lds[J][K]==nland)
                    {
                        lds[j][k]=nland;
                        n++;
                    }
                }
            }         
        }
    }
    return n;    
}

int main(int argc, char *argv[])
{
    int type,NLAT,NLON;
    string gt,ifile,ofile;
    
    int j,k,J,K,LL,LH;
    int nland,ngrd,ngrdld;

    ifstream input("land_divider.txt");
    
    input>>type;
    input>>NLAT;
    input>>NLON;
    input>>gt;
    input>>ifile;
    input>>ofile;
    
    mat<int>of(NLAT,NLON);
    mat<int>lds(NLAT,NLON);
    grid grd(gt,NLAT,NLON);

    grd.input(ifile,of);
    for(j=0;j<NLAT;j++)
    for(k=0;k<NLON;k++)
    {
        if(of[j][k]==1)lds[j][k]=0;
        else lds[j][k]=-1;
    }

    nland=0;
    
    for(;;)
    {
        ngrd=iland(J,K,lds);
        if(ngrd==0)break;
        
        nland++;
        lds[J][K]=nland;
        
        do
        {
            ngrdld=land(type,nland,lds);
        }
        while(ngrdld!=0);
        
        cout<<"Marking land number: "<<nland<<endl;    
    }

    grd.output(ofile,lds);
//    system("PAUSE");
    return 0;
}
