#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

#include "check_error.h"
#include "vec.h"
#include "mat.h"
#include "grid.h"

using namespace std;

double psi(double cost1,double sint1,double cost2,double sint2,double cosld)
{
    double p;
    p=cost1*cost2+sint1*sint2*cosld;
    if(p<-1.0)p=-1.0;
    if(p>1.0)p=1.0;        
    return acos(p);
}

int error_return(string msg)
{
   cout<<msg<<endl;
   return 0;    
}

int main()
{
    ifstream ctl("Mask_Coastal_Ocean.txt");
    string type,ifile,ofile;
    int nLat,nLon;
    double R,D,Dr,d,mask;
    
    ctl>>type;
    ctl>>nLat;
    ctl>>nLon;

    ctl>>ifile;
    ctl>>R;
    ctl>>D;
    ctl>>mask;
    ctl>>ofile;
    
    Dr=D/R;

    if(type!="Gauss"&&type!="Lobatto")error_return("type must be 'Gauss' or 'Lobatto'");
    
    grid grd(type,nLat,nLon);
 
    mat<float> of(nLat,nLon),new_of(nLat,nLon);
    grd.input(ifile,of);
 
    vec<double> cost(nLat),sint(nLat),cosl(nLon);
    double PI=4.0*atan(1.0);
    double d2r=PI/180.0;
    
    double tmp;
    for(int i=0;i<nLat;i++)
    {
        tmp=(90.0-grd.latitude(i))*d2r;
        cost[i]=cos(tmp); 
        sint[i]=sin(tmp);
    }
        
    for(int i=0;i<nLon;i++)
    {
        cosl[i]=cos(grd.longitude(i)*d2r);
    }
    
    new_of=of;
    
    for(int j=0;j<nLat;j++)
    for(int k=0;k<nLon;k++)
    if(of[j][k]==1)
    {
        for(int jj=0;jj<nLat;jj++)
        for(int kk=0;kk<nLon;kk++)
        if(of[jj][kk]==0)
        {
            d=psi(cost[j],sint[j],cost[jj],sint[jj],cosl[abs(k-kk)]);  
            if(d<Dr)
            {
                new_of[j][k]=mask;
                goto done;
            }
        }
        done:
        if(k==0)cout<<".";
    }

    grd.output(ofile,new_of);

//    system("pause");
    return 0;    
}
