#include <cstdlib>
#include <iostream>
#include <cmath>    
#include <fstream>   

#include "grid.h"
#include "vec.h"
 
using namespace std;

int main(int argc, char *argv[])
{
    int type,NLAT,NLON;
    string gt,ifile,ofile;
    
    int i,j,k,NL;

    ifstream input("land_pieces.txt");
    
    input>>NLAT;
    input>>NLON;
    input>>gt;
    input>>ifile;
    input>>NL;
    
    vec<int> LE(NL);
    for(i=0;i<NL;i++)input>>LE[i];
    
    input>>ofile;
    
    mat<int>lds(NLAT,NLON);
    mat<int>ldsex(NLAT,NLON);
    grid grd(gt,NLAT,NLON);

    grd.input(ifile,lds);
    for(j=0;j<NLAT;j++)
    for(k=0;k<NLON;k++)
    {
        ldsex[j][k]=0;
        for(i=0;i<NL;i++)if(lds[j][k]==LE[i])ldsex[j][k]=1;
    }

    grd.output(ofile,ldsex);
//    system("PAUSE");
    return 0;
}
