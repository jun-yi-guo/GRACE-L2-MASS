//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <fstream>
#include <string>
#include <cmath>
#include <algorithm> 
 
#include "rshc.h"

using namespace std;

int main()
{
    int l,m,MDEG,TDEG;       
    rshc spectin,spectout;
    string ifile,ofile;

    ifstream input("Truncate_GIA_SHCs.txt");

    input>>MDEG;
    input>>TDEG;
    
    check_error(TDEG>MDEG,"truncation degree too high");

    spectin.resize(MDEG);
    spectout.resize(TDEG);
    
    input>>ifile;
    input>>ofile;   
	 
    spectin.input_do(ifile.c_str());

    for(l=0;l<=TDEG;l++)
    {
        spectout.c(0,l)=spectin.c(0,l);
        for(m=1;m<=l;m++)
        {
            spectout.c(m,l)=spectin.c(m,l);
            spectout.s(m,l)=spectin.s(m,l);                 
        }
    }   
    spectout.output_s0(ofile.c_str(),16);   

//    system("pause");
    return 0;
}
