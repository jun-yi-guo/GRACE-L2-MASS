//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <fstream>
#include <string>
#include <cmath>
#include <algorithm>

#include "rshc.h"

using namespace std;

int main()
{
    int i,j,k,l,m,MDEG,TDEG,DEG,numFile;       
    rshc spectin,spectout;
    string ifile,ofile;

    ifstream input("Truncate_SHCs.txt");

    input>>MDEG;
    input>>TDEG;
    input>>numFile;
    
//    check_error(TDEG>MDEG,"truncation bandwidth too high");

    spectin.resize(MDEG);
    spectout.resize(TDEG);
    DEG=min(MDEG,TDEG);
    
    for(i=0;i<numFile;i++)
    {
        input>>ifile;
        input>>ofile;

        spectin.input_s0(ifile.c_str());

        for(l=0;l<=DEG;l++)
        {
            spectout.c(0,l)=spectin.c(0,l);
            for(m=1;m<=l;m++)
            {
                spectout.c(m,l)=spectin.c(m,l);
                spectout.s(m,l)=spectin.s(m,l);                 
            }
        }
        if(DEG<TDEG)
        {
            for(l=DEG+1;l<=TDEG;l++)
            {
                spectout.c(0,l)=0.0;
                for(m=1;m<=l;m++)
                {
                    spectout.c(m,l)=0.0;
                    spectout.s(m,l)=0.0;                 
                }
            }            
        }
        
        spectout.output_s0(ofile.c_str(),16);   
        
        cout<<i+1<<" over "<<numFile<<" done"<<endl;        
    }

//    system("pause");
    return 0;
}
