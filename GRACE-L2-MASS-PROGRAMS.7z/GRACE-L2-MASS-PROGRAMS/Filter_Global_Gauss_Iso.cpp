//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <iostream>
#include <cmath>
#include <fstream>
     
#include "Filter_Global_Gauss_Iso.h"
    
using namespace std;

int main(int argc, char *argv[])
{  
    int i,NLAT,NLON,NFILE;
    double r;
    string ifile,ofile;
    double tmp;

    ifstream input("Filter_Global_Gauss_Iso.txt");

    input>>NLAT;
    input>>NLON;
    input>>r;    
    input>>NFILE;

    filter_gauss filter("Gauss",r,NLAT,NLON);
    
    for(i=0;i<NFILE;i++)
    {
        input>>ifile;
        input>>ofile;
        filter.solve(ifile,ofile);
        cout<<i+1<<" over "<<NFILE<<" done"<<endl;
    }
    
    system("PAUSE");
    return 1;
}
