//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <iostream>
#include <cmath>  
#include <fstream>
     
#include "Filter_Global_Gauss_Mix.h"

using namespace std;

int main(int argc, char *argv[])
{
    int i,NLAT,NLON,NFILE;
    double rt,rl;
    string W,ifile,ofile;
    double tmp;
    
    ifstream input("Filter_Global_Gauss_Mix.txt");
    
    input>>NLAT;
    input>>NLON;
    input>>W;
    input>>rt;
    input>>rl;
    input>>NFILE;
    
    filter_global_grid_gauss filter(rt,rl,W,NLAT,NLON);
    
    for(i=0;i<NFILE;i++)
    {
        input>>ifile;
        input>>ofile;
        filter.solve(ifile,ofile);
        cout<<i+1<<" over "<<NFILE<<" done"<<endl;
    }
    
//    system("PAUSE");
    return 0;
}
