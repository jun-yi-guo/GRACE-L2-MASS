//Copyright: Jun-Yi Guo

#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>

using namespace std;

void usage()
{
    cerr<<endl<<"USAGE: logitudeFormat [dataDescriptionFile]"<<endl;
    cerr<<"Defaut `dataDescriptionFile' is logitudeFormat.txt"<<endl;
}

int main(int argc, char *argv[])
{
	int i, j, k, numLat, numLon, numFile;

    enum {from180to360,from360to180}type; 

    string ifile, ofile, stmp;
    
    double lat, *lon, *data, dtmp, dlon;

 	ifstream input;
 	
    if(argc>2)
    {
        usage();
        return 0;
    }
    else if(argc==1)
    {
        input.open("longitudeFormat.txt");
        if(!input.is_open())
        {
            usage();
            cerr<<endl<<"`longitudeFormat.txt' does not exist"<<endl;
            return 0;
        }
    }
    else
    {
        input.open(argv[1]);        
        if(!input.is_open())
        {
            usage();
            cerr<<endl<<"`"<<argv[1]<<"' dose not exist"<<endl;
            return 0;
        }
    }

    input>>stmp;
    if(stmp=="from180to360")type=from180to360;
    else if(stmp=="from360to180")type=from360to180;
    else
    {
        cerr<<"Wrong transform type: Only `from180to360' or `from360to180' accepted"<<endl;
        return 0;
    }
    
	input>>numLat;
	input>>numLon;

    if(numLon%2==1)
    {
        cerr<<"number of longitudinal node must be even"<<endl;
        exit(1);
    }

    lon=new double[numLon];
    data=new double[numLon];
	
	input>>numFile;

    ifstream in;
    ofstream out;

    dlon=360.0/numLon;

    for(k=0;k<numFile;k++)
    {
        input>>ifile;
        input>>ofile;
        
        if(ifile==ofile)
        {
            cerr<<"Input and output files must be different"<<endl;
            return 0;
        }
        in.open(ifile.c_str());
        out.open(ofile.c_str());
        for(i=0;i<numLat;i++)
        {
            for(j=0;j<numLon;j++)
            {
               in>>dtmp;
               in>>lon[j];
               in>>data[j];
               if(j>0)if(dtmp!=lat||fabs(lon[j]-lon[j-1]-1.0)>1.0e-2)
               {
                   cerr<<"Error in latitude or longitude data"<<endl;
                   return 0;
               }
               lat=dtmp;
            }
            
            switch(type)
            {
              case from180to360:
                   
                for(j=numLon/2;j<numLon;j++)
                {
                    out<<lat<<"   "<<lon[j]<<"   "<<data[j]<<endl;
                }
                for(j=0;j<numLon/2;j++)
                {
                    out<<lat<<"   "<<lon[j]+360.0<<"   "<<data[j]<<endl;
                }  
                break;
                
              case from360to180:
                   
                for(j=numLon/2;j<numLon;j++)
                {
                    out<<lat<<"   "<<lon[j]-360<<"   "<<data[j]<<endl;
                }
                for(j=0;j<numLon/2;j++)
                {
                    out<<lat<<"   "<<lon[j]<<"   "<<data[j]<<endl;
                }  
                break;  
            }      
        }

        in.close();
        out.close();
        
        cout<<k+1<<"   "<<ifile<<"   "<<ofile<<endl<<flush; 
    }

    delete[]lon;
    delete[]data;

    system("pause");

	return 1; 
}
