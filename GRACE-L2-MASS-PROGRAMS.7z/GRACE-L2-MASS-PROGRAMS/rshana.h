//Copyright: Jun-Yi Guo

#ifndef rshana_h
#define rshana_h

#include <fstream>
#include <string>
#include <sstream>

#include <algorithm>

#include "fftpack++.h"

#include "legendre.h" 
#include "rshc.h"
#include "mat.h"
#include "rsht.h" 
//#include "chebcoll.h"

using namespace std;

class rshana
{
  private:

    int bw_;
    int ngrid_;
    double *w_;
    
    double factor,half_factor;

    void create(int bw)
    {
        bw_=bw;
        if(bw_==0)return;
        
        ngrid_=2*bw_;
        
        double PI=4.0*atan(1.0);
        factor=2.0*PI/bw_;
        factor/=4.0*PI; //modified to t changing mormalization
        
        half_factor=factor/2.0;
		
		w_=new(nothrow)double[bw_];
        check_error(w_==NULL, "not enough memory");
    }

    void destroy()
    {
        if(bw_!=0)
        {
            bw_=0;
            delete[]w_;
        }                
    }

  public:

    /**
     *  Constructor
     */
     
    explicit rshana(int bw=0)
    {
        create(bw);
    }

    /**
     *  Denstructor
     */

    ~rshana()
    {
        destroy();
    }

    void resize(int bw=0)
    {
        if(bw_!=bw)
        {
            destroy();
            create(bw);
        }   
    }

    void initialize(vec<double> &t, trig_multi_theta &trig_t)
    {
    	check_error(t.size()!=bw_, "Size of theta mismatch");
    	check_error(trig_t.len!=bw_, "Size of trig mismatch");
    	
    	int j,k;
    	vec<double>fac(bw_);
    	for(k=0;k<bw_;k++)fac[k]=0.5/(k+0.5);
    	
        double tmp=2.0/bw_;
        for(j=0;j<bw_;j++)
        {
            w_[j]=0.0;
            for(k=0;k<bw_;k++)
            {
                w_[j]+=fac[k]*sin((2.0*k+1.0)*t[j]);
            }
            w_[j]*=tmp*trig_t.s[j];
        }
        
//        ChebColl cc(ChebColl::Gauss,2*bw_);
//        for(j=0;j<bw_;j++)cout<<w_[j]<<"   "<<cc.Weight_Int(j)<<"   "<<(w_[j]-cc.Weight_Int(j))/w_[j]<<endl;
//        for(j=0;j<bw_;j++)w_[j]=cc.Weight_Int(j);
    }

    void analysis(rshc &coef, rfft &rfft_, legendre_multi_theta &p_, mat<double>& data)
    {
    	check_error(coef.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
    	check_error(p_.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
        check_error(data.numRows()!=ngrid_||data.numCols()!=ngrid_,"error in grid size");
        check_error(rfft_.size()!=ngrid_,"fft object size mismatch");

        int i,j,k,l,m;
        double tmp;

        int N=ngrid_-1;

        vec<double> r1(ngrid_);
        vec<double> r2(ngrid_);

        for(l=0;l<bw_;l++)
        {
            coef.c(0,l)=0.0;                  
            for(m=1;m<=l;m++)
            {
                coef.c(m,l)=0.0;                  
                coef.s(m,l)=0.0;    
            }
        }

        for(j=0;j<bw_;j++)
        {
            for(k=0;k<ngrid_;k++)
            {
                r1[k]=data[j][k];
                r2[k]=data[N-j][k];
            }

            rfft_.forward(r1);
            rfft_.forward(r2);

           // m=0
            for(l=0;l<bw_;l++)
            {
                tmp=p_[j][0][l]*w_[j];
                coef.c(0,l)+=r1[0]*tmp;
                if(l%2==0)
                {
                    coef.c(0,l)+=r2[0]*tmp;
                }
                else
                {
                    coef.c(0,l)-=r2[0]*tmp;
                }
            }

            // m=1,...
            for(m=1;m<bw_;m++)
            for(l=m;l<bw_;l++)
            {
                tmp=p_[j][m][l]*w_[j];
                
                coef.c(m,l)+=r1[2*m-1]*tmp;
                coef.s(m,l)-=r1[2*m]*tmp;

                if((l-m)%2==0)
                {
                    coef.c(m,l)+=r2[2*m-1]*tmp;
                    coef.s(m,l)-=r2[2*m]*tmp;
                }else
                {
                    coef.c(m,l)-=r2[2*m-1]*tmp;
                    coef.s(m,l)+=r2[2*m]*tmp;
                }
            }
        }

        for(l=0;l<bw_;l++)
        {
            coef.c(0,l)*=half_factor;                  
            for(m=1;m<=l;m++)
            {
                coef.c(m,l)*=factor;                  
                coef.s(m,l)*=factor;  
            }
        }        
    }

    void analysis(rshc &coef,  rfft &rfft_, legendre &lgdr, trig_multi_theta &trig_t, mat<double>& data)
    {
    	check_error(coef.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
    	check_error(lgdr.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
        check_error(data.numRows()!=ngrid_||data.numCols()!=ngrid_,"error in grid size");
		check_error(rfft_.size()!=ngrid_,"fft object size mismatch");    

		legendre_one_theta p_(bw_-1);

        int i,j,k,l,m;
        double tmp;

        int N=ngrid_-1;

        vec<double> r1(ngrid_);
        vec<double> r2(ngrid_);

        for(l=0;l<bw_;l++)
        {
            coef.c(0,l)=0.0;                  
            for(m=1;m<=l;m++)
            {
                coef.c(m,l)=0.0;                  
                coef.s(m,l)=0.0;    
            }
        }

        for(j=0;j<bw_;j++)
        {
            lgdr.evaluate(p_,trig_t,j);
            
            for(k=0;k<ngrid_;k++)
            {
                r1[k]=data[j][k];
                r2[k]=data[N-j][k];
            }

            rfft_.forward(r1);
            rfft_.forward(r2);

           // m=0
            for(l=0;l<bw_;l++)
            {
                tmp=p_[0][l]*w_[j];
                coef.c(0,l)+=r1[0]*tmp;
                if(l%2==0)
                {
                    coef.c(0,l)+=r2[0]*tmp;
                }
                else
                {
                    coef.c(0,l)-=r2[0]*tmp;
                }
            }

            // m=1,...
            for(m=1;m<bw_;m++)
            for(l=m;l<bw_;l++)
            {
                tmp=p_[m][l]*w_[j];
                
                coef.c(m,l)+=r1[2*m-1]*tmp;
                coef.s(m,l)-=r1[2*m]*tmp;

                if((l-m)%2==0)
                {
                    coef.c(m,l)+=r2[2*m-1]*tmp;
                    coef.s(m,l)-=r2[2*m]*tmp;
                }else
                {
                    coef.c(m,l)-=r2[2*m-1]*tmp;
                    coef.s(m,l)+=r2[2*m]*tmp;
                }
            }
        }

        for(l=0;l<bw_;l++)
        {
            coef.c(0,l)*=half_factor;                  
            for(m=1;m<=l;m++)
            {
                coef.c(m,l)*=factor;                  
                coef.s(m,l)*=factor;  
            }
        }   
    }
};

#endif
