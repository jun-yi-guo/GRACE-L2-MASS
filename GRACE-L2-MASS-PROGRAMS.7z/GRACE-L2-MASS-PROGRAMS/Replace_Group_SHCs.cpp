//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

#include "rshc.h"
#include "mat.h"
#include "vec.h"

using namespace std;

int main()
{
    int i,j,Deg,numFile,numCoef;
    string rfile,ifile,ofile;
    
    ifstream control("Replace_Group_SHCs.txt");
    
    control>>Deg;
    control>>rfile;
    ifstream rput(rfile.c_str());

    rput>>numFile;
    
    control>>i;
    check_error(i!=numFile,"Error: number of file in two sources are different");

    vec<string> yyyy(numFile);
    vec<string> ddd(numFile);
    
    for(i=0;i<numFile;i++)
    {
        rput>>yyyy[i];
        rput>>ddd[i];
    }
    
    rput>>numCoef;
    rput>>i;
    
    vec<char> ncs(numCoef);
    vec<int>  deg(numCoef);
    vec<int>  ord(numCoef);
    mat<double> coef(numCoef,numFile);   
    
    for(i=0;i<numCoef;i++)
    {
        rput>>ncs[i];
        if(ncs[i]!='c'&&ncs[i]!='s')
        {
            cout<<"Name of coeficient must be 'c' or 's'. Input is "<< ncs[i]<<endl;
            return 0;
        }
        rput>>deg[i];
        rput>>ord[i];   
        
        for(j=0;j<numFile;j++)rput>>coef[i][j];                   
    }
    
    rshc shc(Deg);
    
    for(i=0;i<numFile;i++)
    {
        control>>ifile;
        control>>ofile;

        check_error(yyyy[i]!=ifile.substr(0,4)||ddd[i]!=ifile.substr(5,3),"file name inconsistant");

        shc.input_s0(ifile.c_str());
        
        for(j=0;j<numCoef;j++)
        {
            if(ncs[j]=='c')shc.c(ord[j],deg[j])=coef[j][i];
            else shc.s(ord[j],deg[j])=coef[j][i];
        }
        
        shc.output_s0(ofile.c_str(),15);

        cout<<ifile<<" -> "<<ofile<<": year="<<yyyy[i]<<", ddd="<<ddd[i]<<endl;
    }
    
    return 1;
}
