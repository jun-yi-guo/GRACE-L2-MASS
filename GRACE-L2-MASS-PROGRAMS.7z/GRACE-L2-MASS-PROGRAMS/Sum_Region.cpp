//Copyright: Jun-Yi Guo

#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <cmath>
#include <cstdlib>

using namespace std;

int main()
{
    cout<<"Must be used for Gauss type grid over latitude"<<endl;
    
	int i,j,k,m,numLat,numLon,numFile,*rm;

    string ifile, rfile, ofile;
    
    double R, R2, *lat0, *lon0, dlat, dlon, darea, lat, lon, data, sum, area;
    
    double tol=1.0e-3;
    
    double d2r=4.0*atan(1.0)/180.0;

 	ifstream input("Sum_Region.txt");

    input>>R;
    
    R2=R*R;
    
    input>>numLat;
    input>>numLon;
    
    dlat=(180.0/numLat)*d2r;
    dlon=(360.0/numLon)*d2r;
    
    darea=dlat*dlon;

    input>>rfile;
    
    ifstream inr(rfile.c_str());
    
    rm=new int[numLat*numLon];
    lat0=new double[numLat];
    lon0=new double[numLon];
    
    k=0;
    area=0.0;
    for(i=0;i<numLat;i++)
    for(j=0;j<numLon;j++)
    {
        inr>>lat0[i];
        inr>>lon0[j];
        inr>>rm[k]; 
        
        if(rm[k]==1)area+=dlon*(sin(lat0[i]*d2r+0.5*dlat)-sin(lat0[i]*d2r-0.5*dlat));//darea*cos(lat0[i]*d2r);
  
        k++;                   
    }
    area*=R2;
    
    input>>ofile;
      
    ofstream out(ofile.c_str());
    
    ifstream in;
	input>>numFile;

    for(m=0;m<numFile;m++)
    {
        input>>ifile;
        in.open(ifile.c_str());

        sum=0.0;
        k=0;
        for(i=0;i<numLat;i++)
        for(j=0;j<numLon;j++)
        {
            in>>lat;
            in>>lon;
            if(fabs(lat-lat0[i])>tol||fabs(lon-lon0[j])>tol)
            {
                cout<<"Error in data file: Grid different"<<endl;
                system("pause");
                return 0;    
            }
            in>>data; 
            
            if(rm[k]==1)sum+=data*dlon*(sin(lat*d2r+0.5*dlat)-sin(lat*d2r-0.5*dlat));//darea*cos(lat*d2r);

            k++;                   
        }
        
        sum*=R2;
        out<<ifile<<"   "<<sum<<"   "<<sum/area<<endl;

        in.close();
        cout<<ifile<<" done."<<endl; 
    }

    delete[]rm;
    delete[]lat0;
    delete[]lon0;
    
//    system("pause");

	return 0; 
}
