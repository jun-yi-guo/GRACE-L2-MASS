//Copyright: Jun-Yi Guo

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <fstream>
#include <string>  
#include <sstream>
#include <iomanip>
 
#include "check_error.h" 
#include "vec.h"
#include "mat.h"
#include "grid.h" 
#include "rsht.h" 

#include "mat_lower_triangle.h"

using namespace std;

void set_kn(vec<double> &kn);

int main(int argc,char *argv[])
{ 
	int i,j,k,l,m,n,p,q,itmp;
	double dtmp;

	//4 pi G/g_R
	double PI=4.0*atan(1.0);
	double G=6.6742e-11; 
	double GM=3.986005e+14;
	
	ifstream ctl("SHCs2Mass_AsphericalEarth.txt");	
	
	double R,gR,coef;
	
	ctl>>R;
	gR=GM/(R*R);
	coef=4*PI*G/gR;	
	
	int bw_topo;
	string ifile_topo;	
	
	ctl>>bw_topo;
	ctl>>ifile_topo;
	
	int maxDeg_topo=bw_topo-1;
	int numlat_topo=2*bw_topo, numlon_topo=2*bw_topo;

	int bw_mass;
	int num_mass;
	
	ctl>>bw_mass;
	ctl>>num_mass;	
	
	int maxDeg_mass=bw_mass-1;
	int numlat_mass=2*bw_mass, numlon_mass=2*bw_mass;

	vec<string> ifile_mass(num_mass),ofile_mass(num_mass); 
	for(i=0;i<num_mass;i++)
	{
		ctl>>ifile_mass[i];
		ctl>>ofile_mass[i];
	}

	ctl.close();
	
	mat_lower_triangle<rshc> delta_k_qp(bw_mass);
	mat_lower_triangle<rshc> delta_k_qm(bw_mass);
	
	for(p=0;p<=maxDeg_mass;p++)
	for(q=0;q<=p;q++)
	{
		delta_k_qp[p][q].resize(maxDeg_mass);
		delta_k_qm[p][q].resize(maxDeg_mass);
		
//		delta_k_qp[p][q]=0.0;
//		delta_k_qm[p][q]=0.0;
	}

	cout<<"Pre-camputation ..."<<endl;
	{
		mat<double> epsilon(numlat_topo,numlon_topo);
		grid grd_topo("Gauss",numlat_topo,numlon_topo);
		grd_topo.input(ifile_topo,epsilon);
		epsilon/=R;
	
		rsht_memo rsht(bw_topo);
		rshc SHCsp(maxDeg_topo),SHCsm(maxDeg_topo);	
		
		vec<double> theta(2*bw_topo);
		for(int j=0;j<2*bw_topo;j++)
			theta[j]=rsht.theta(j);
	
		mat<double>lambda_sin(2*bw_topo,bw_topo),lambda_cos(2*bw_topo,bw_topo);
		for(int k=0;k<2*bw_topo;k++)
		for(int m=0;m<=maxDeg_topo;m++)	
		{
			lambda_sin[k][m]=rsht.lambda_sm(k,m);
			lambda_cos[k][m]=rsht.lambda_cm(k,m);
		}
	
		legendre_multi_theta alf(theta,maxDeg_topo);
		alf.setNormType(legendre_multi_theta::CplxFull);
		for(int n=0;n<=maxDeg_topo;n++)
		for(int k=0;k<=n;k++)
		for(int j=0;j<2*bw_topo;j++)
			alf[j][k][n]=rsht.lgdr(j,k,n);
		alf.toRealFull();
	
		mat<double> delta_k(numlat_topo,numlon_topo);
	
		for(int p=0;p<=maxDeg_mass;p++)
		for(int q=0;q<=p;q++)
		{
			if(q%10==0)cout<<"doing degree p="<<p<<" and order q="<<q<<"   "<<endl;
	
			// q positive, cos 
			for(int j=0;j<2*bw_topo;j++)
			for(int k=0;k<2*bw_topo;k++)
				delta_k[j][k]=(pow(1.0+epsilon[j][k],p+2)-1.0)*alf[j][q][p]*lambda_cos[k][q]/(2.0*p+1.0);
	
			SHCsp.setNormType(rshc::CplxFull);
			rsht.forward(SHCsp,delta_k);
			SHCsp.toRealFull();
	
			for(int n=0;n<=maxDeg_mass;n++)
			{
				dtmp=2.0*n+1.0;
				for(int k=0;k<=n;k++)
				{
					delta_k_qp[p][q].c(k,n)=SHCsp.c(k,n)*dtmp;
					delta_k_qp[p][q].s(k,n)=SHCsp.s(k,n)*dtmp;
				}		
			}
	
			// q negative, sin 
			for(int j=0;j<2*bw_topo;j++)
			for(int k=0;k<2*bw_topo;k++)
				delta_k[j][k]=(pow(1.0+epsilon[j][k],p+2)-1.0)*alf[j][q][p]*lambda_sin[k][q]/(2.0*p+1.0);
			
			SHCsm.setNormType(rshc::CplxFull);
			rsht.forward(SHCsm,delta_k);
			SHCsm.toRealFull();
	
			for(int n=0;n<=maxDeg_mass;n++)
			{
				dtmp=2.0*n+1.0;
				for(int k=0;k<=n;k++)
				{
					delta_k_qm[p][q].c(k,n)=SHCsm.c(k,n)*dtmp;
					delta_k_qm[p][q].s(k,n)=SHCsm.s(k,n)*dtmp;
				}			
			}
		}
	}

	cout<<"Calculating mass"<<endl;
	
	vec<double> kn(361);
    set_kn(kn);
//    kn=0.0;

	mat<double> mass(numlat_mass,numlon_mass);
	rshc SHCphi_t(maxDeg_mass),SHCm_1(maxDeg_mass),SHCm_t(maxDeg_mass);
	SHCm_1.setNormType(rshc::RealFull);
	SHCm_t.setNormType(rshc::RealFull);
	
 	//approximate
 	double dtmp_c,dtmp_s,dtmp_nc,dtmp_ns;
 	grid grd_mass("Gauss",numlat_mass,numlon_mass);
	rsht_memo rsht(bw_mass); 	

	for(i=0;i<num_mass;i++)
	{
		SHCphi_t.input_s0(ifile_mass[i].c_str());
		for(p=0;p<bw_mass;p++)
		{
//			dtmp=(2.0*p+1.0)/coef;
			dtmp=(2.0*p+1.0)/(coef*(1.0+kn[p]));
			for(q=0;q<=p;q++)
			{
				SHCm_1.c(q,p)=SHCphi_t.c(q,p)*dtmp;
				SHCm_1.s(q,p)=SHCphi_t.s(q,p)*dtmp;
		
				dtmp_c=0.0;
				dtmp_s=0.0;		
				for(n=0;n<bw_mass;n++)
				for(k=0;k<=n;k++)
				{
					dtmp_c+=SHCphi_t.c(k,n)*delta_k_qp[p][q].c(k,n)+SHCphi_t.s(k,n)*delta_k_qp[p][q].s(k,n);
					dtmp_s+=SHCphi_t.c(k,n)*delta_k_qm[p][q].c(k,n)+SHCphi_t.s(k,n)*delta_k_qm[p][q].s(k,n);
				}
		
				SHCm_1.c(q,p)-=dtmp*dtmp_c;
				SHCm_1.s(q,p)-=dtmp*dtmp_s;
			}
		}
		
		for(int iter=0;iter<5;iter++)
		{
		 	for(p=0;p<bw_mass;p++)
			{
//	    		dtmp=(2.0*p+1.0)/coef;
				dtmp=(2.0*p+1.0)/(coef*(1.0+kn[p]));
				for(q=0;q<=p;q++)
				{
					SHCm_t.c(q,p)=SHCphi_t.c(q,p)*dtmp;
					SHCm_t.s(q,p)=SHCphi_t.s(q,p)*dtmp;
		
					dtmp_c=0.0;
					dtmp_s=0.0;		
					for(n=0;n<bw_mass;n++)
					{
						dtmp_nc=0.0;
						dtmp_ns=0.0;
						for(k=0;k<=n;k++)
						{
							dtmp_nc+=SHCm_1.c(k,n)*delta_k_qp[p][q].c(k,n)+SHCm_1.s(k,n)*delta_k_qp[p][q].s(k,n);
							dtmp_ns+=SHCm_1.c(k,n)*delta_k_qm[p][q].c(k,n)+SHCm_1.s(k,n)*delta_k_qm[p][q].s(k,n);
						}
						dtmp_c+=dtmp_nc/(2.0*n+1.0);
						dtmp_s+=dtmp_ns/(2.0*n+1.0);
					}
		
					SHCm_t.c(q,p)-=dtmp_c*(2.0*p+1.0);
					SHCm_t.s(q,p)-=dtmp_s*(2.0*p+1.0);		
				}
		 	}
		 	
		 	SHCm_1=SHCm_t;	
		}
		
		SHCm_t.toCplxFull();
		rsht.inverse(mass,SHCm_t);
		
		grd_mass.output(ofile_mass[i].c_str(),mass);
		
		cout<<i+1<<" out of "<<num_mass<<" done"<<endl;
	}
	return 0;
}

void set_kn(vec<double> &kn)
{
double k[]={
 7.850579533e-18,  2.084968543e-14, -3.051803391e-01, -1.958691549e-01, -1.335304418e-01,      
-1.045708643e-01, -9.018961292e-02, -8.191138704e-02, -7.638383631e-02, -7.225505927e-02,      
-6.893919634e-02, -6.615316015e-02, -6.374145754e-02, -6.160802068e-02, -5.968816680e-02,      
-5.793595815e-02, -5.631776476e-02, -5.480854492e-02, -5.338946315e-02, -5.204625555e-02,      
-5.076806044e-02, -4.954656148e-02, -4.837535122e-02, -4.724945451e-02, -4.616497015e-02,      
-4.511880089e-02, -4.410844991e-02, -4.313186773e-02, -4.218733726e-02, -4.127338789e-02,      
-4.038873166e-02, -3.953221605e-02, -3.870278944e-02, -3.789947600e-02, -3.712135773e-02,      
-3.636756171e-02, -3.563725127e-02, -3.492961993e-02, -3.424388738e-02, -3.357929692e-02,      
-3.293511390e-02, -3.231062471e-02, -3.170513637e-02, -3.111797626e-02, -3.054849201e-02,      
-2.999605149e-02, -2.946004278e-02, -2.893987409e-02, -2.843497368e-02, -2.794478968e-02,      
-2.746878985e-02, -2.700646132e-02, -2.655731023e-02, -2.612086130e-02, -2.569665748e-02,      
-2.528425938e-02, -2.488324484e-02, -2.449320836e-02, -2.411376061e-02, -2.374452784e-02,      
-2.338515134e-02, -2.303528689e-02, -2.269460423e-02, -2.236278647e-02, -2.203952961e-02,      
-2.172454197e-02, -2.141754370e-02, -2.111826629e-02, -2.082645207e-02, -2.054185376e-02,      
-2.026423399e-02, -1.999336492e-02, -1.972902775e-02, -1.947101240e-02, -1.921911706e-02,      
-1.897314784e-02, -1.873291843e-02, -1.849824977e-02, -1.826896968e-02, -1.804491261e-02,      
-1.782591931e-02, -1.761183658e-02, -1.740251697e-02, -1.719781853e-02, -1.699760460e-02,      
-1.680174355e-02, -1.661010856e-02, -1.642257743e-02, -1.623903237e-02, -1.605935979e-02,      
-1.588345018e-02, -1.571119785e-02, -1.554250085e-02, -1.537726077e-02, -1.521538260e-02,      
-1.505677458e-02, -1.490134810e-02, -1.474901753e-02, -1.459970012e-02, -1.445331588e-02,      
-1.430978746e-02, -1.416904008e-02, -1.403100138e-02, -1.389560135e-02, -1.376277225e-02,      
-1.363244849e-02, -1.350456658e-02, -1.337906502e-02, -1.325588426e-02, -1.313496660e-02,      
-1.301625611e-02, -1.289969860e-02, -1.278524154e-02, -1.267283399e-02, -1.256242653e-02,      
-1.245397126e-02, -1.234742168e-02, -1.224273269e-02, -1.213986050e-02, -1.203876263e-02,      
-1.193939781e-02, -1.184172598e-02, -1.174570823e-02, -1.165130677e-02, -1.155848488e-02,      
-1.146720688e-02, -1.137743810e-02, -1.128914484e-02, -1.120229434e-02, -1.111685474e-02,      
-1.103279505e-02, -1.095008517e-02, -1.086869576e-02, -1.078859833e-02, -1.070976513e-02,      
-1.063216915e-02, -1.055578412e-02, -1.048058446e-02, -1.040654526e-02, -1.033364226e-02,      
-1.026185186e-02, -1.019115104e-02, -1.012151740e-02, -1.005292910e-02, -9.985364882e-03,      
-9.918804004e-03, -9.853226264e-03, -9.788611966e-03, -9.724941911e-03, -9.662197376e-03,      
-9.600360106e-03, -9.539412297e-03, -9.479336581e-03, -9.420116019e-03, -9.361734083e-03,      
-9.304174644e-03, -9.247421965e-03, -9.191460686e-03, -9.136275813e-03, -9.081852710e-03,      
-9.028177088e-03, -8.975234992e-03, -8.923012795e-03, -8.871497191e-03, -8.820675179e-03,      
-8.770534059e-03, -8.721061426e-03, -8.672245155e-03, -8.624073400e-03, -8.576534582e-03,      
-8.529617384e-03, -8.483310743e-03, -8.437603844e-03, -8.392486111e-03, -8.347947204e-03,      
-8.303977009e-03, -8.260565636e-03, -8.217703410e-03, -8.175380864e-03, -8.133588741e-03,      
-8.092317979e-03, -8.051559711e-03, -8.011305261e-03, -7.971546135e-03, -7.932274021e-03,      
-7.893480781e-03, -7.855158445e-03, -7.817299214e-03, -7.779895447e-03, -7.742939663e-03,      
-7.706424534e-03, -7.670342883e-03, -7.634687678e-03, -7.599452032e-03, -7.564629194e-03,      
-7.530212553e-03, -7.496195628e-03, -7.462572066e-03, -7.429335643e-03, -7.396480256e-03,      
-7.363999925e-03, -7.331888784e-03, -7.300141083e-03, -7.268751183e-03, -7.237713557e-03,      
-7.207022780e-03, -7.176673535e-03, -7.146660605e-03, -7.116978872e-03, -7.087623315e-03,      
-7.058589010e-03, -7.029871122e-03, -7.001464909e-03, -6.973365717e-03, -6.945568978e-03,      
-6.918070208e-03, -6.890865006e-03, -6.863949053e-03, -6.837318107e-03, -6.810968003e-03,      
-6.784894655e-03, -6.759094046e-03, -6.733562234e-03, -6.708295346e-03, -6.683289581e-03,      
-6.658541202e-03, -6.634046541e-03, -6.609801992e-03, -6.585804015e-03, -6.562049129e-03,      
-6.538533917e-03, -6.515255019e-03, -6.492209133e-03, -6.469393016e-03, -6.446803479e-03,      
-6.424437387e-03, -6.402291660e-03, -6.380363270e-03, -6.358649239e-03, -6.337146640e-03,      
-6.315852595e-03, -6.294764275e-03, -6.273878898e-03, -6.253193721e-03, -6.232706069e-03,      
-6.212413279e-03, -6.192312757e-03, -6.172401937e-03, -6.152678282e-03, -6.133139379e-03,      
-6.113782721e-03, -6.094605940e-03, -6.075606672e-03, -6.056782594e-03, -6.038131421e-03,      
-6.019650907e-03, -6.001338839e-03, -5.983193039e-03, -5.965211363e-03, -5.947391704e-03,      
-5.929731983e-03, -5.912230158e-03, -5.894884215e-03, -5.877692176e-03, -5.860652087e-03,      
-5.843762031e-03, -5.827020116e-03, -5.810424480e-03, -5.793973291e-03, -5.777664743e-03,      
-5.761497057e-03, -5.745468483e-03, -5.729577297e-03, -5.713821799e-03, -5.698200317e-03,      
-5.682711202e-03, -5.667352831e-03, -5.652123604e-03, -5.637021945e-03, -5.622046302e-03,      
-5.607195145e-03, -5.592466967e-03, -5.577860283e-03, -5.563373630e-03, -5.549005564e-03,      
-5.534754666e-03, -5.520619534e-03, -5.506598788e-03, -5.492691067e-03, -5.478895030e-03,      
-5.465209356e-03, -5.451632741e-03, -5.438163901e-03, -5.424801569e-03, -5.411544498e-03,      
-5.398391456e-03, -5.385341231e-03, -5.372392626e-03, -5.359544460e-03, -5.346795572e-03,      
-5.334144815e-03, -5.321591056e-03, -5.309133181e-03, -5.296770090e-03, -5.284500697e-03,      
-5.272323934e-03, -5.260238745e-03, -5.248244089e-03, -5.236338940e-03, -5.224522284e-03,      
-5.212793123e-03, -5.201150472e-03, -5.189593358e-03, -5.178120823e-03, -5.166731920e-03,      
-5.155425715e-03, -5.144201289e-03, -5.133057732e-03, -5.121994147e-03, -5.111009650e-03,      
-5.100103368e-03, -5.089274439e-03, -5.078522013e-03, -5.067845252e-03, -5.057243327e-03,      
-5.046715421e-03, -5.036260728e-03, -5.025878451e-03, -5.015567806e-03, -5.005328016e-03,      
-4.995158316e-03, -4.985057951e-03, -4.975026174e-03, -4.965062250e-03, -4.955165452e-03,      
-4.945335062e-03, -4.935570372e-03, -4.925870682e-03, -4.916235302e-03, -4.906663550e-03,      
-4.897154753e-03, -4.887708246e-03, -4.878323374e-03, -4.868999488e-03, -4.859735948e-03,      
-4.850532122e-03, -4.841387387e-03, -4.832301126e-03, -4.823272730e-03, -4.814301599e-03,      
-4.805387139e-03, -4.796528763e-03, -4.787725894e-03, -4.778977957e-03, -4.770284390e-03,      
-4.761644633e-03, -4.753058136e-03, -4.744524354e-03, -4.736042750e-03, -4.727612793e-03,      
-4.719233956e-03};
        
for(int i=0;i<361;i++)kn[i]=k[i];
        
}
