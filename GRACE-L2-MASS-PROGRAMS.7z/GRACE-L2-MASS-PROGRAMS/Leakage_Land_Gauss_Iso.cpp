//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <iostream>
#include <cmath>     
#include <fstream>  
    
#include "Leakage_Land_Gauss_Iso.h"
   
using namespace std; 
  
int main(int argc, char *argv[])
{
    int i,NLAT,NLON,mulat,mulon,NFILE;
    double r,R;
    string ifile,ofile,of_file;
    double tmp;
      
    ifstream input("Leakage_Land_Gauss_Iso.txt");
        
    input>>of_file;
    input>>NLAT;
    input>>NLON;
    input>>r;
    input>>mulat; 
    input>>mulon;
    input>>NFILE;

    leakage_land_gauss filter(of_file,r,NLAT,NLON,mulat,mulon);
    
    for(i=0;i<NFILE;i++)
    {
        input>>ifile;
        input>>ofile;
        filter.solve(ifile,ofile);
        cout<<i+1<<" over "<<NFILE<<" done"<<endl;
    }

//    system("PAUSE");
    return 0;
}
