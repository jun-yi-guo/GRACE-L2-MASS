//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

#include "rshc.h"
#include "mat.h"
#include "vec.h"

using namespace std;

int main()
{
    int i,j,Deg,numFile,numCoef;
    string ifile,ofile;
    
    ifstream control("Extract_Group_SHCs.txt");
    
    control>>numCoef;
    
    vec<char> ncs(numCoef);
    vec<int>  deg(numCoef);
    vec<int>  ord(numCoef);
    
    for(i=0;i<numCoef;i++)
    {
        control>>ncs[i];
        if(ncs[i]!='c'&&ncs[i]!='s')
        {
            cout<<"Name of coeficient must be 'c' or 's'"<<endl;
            return 0;
        }
        control>>deg[i];
        control>>ord[i];                      
    }
    
    control>>ofile;

    control>>Deg;
    control>>numFile;
    
    rshc shc(Deg);
    vec<string> yyyy(numFile);
    vec<string> ddd(numFile);
    mat<double> coef(numCoef,numFile);
        
    for(i=0;i<numFile;i++)
    {
        control>>ifile;
        yyyy[i]=ifile.substr(0,4);
        ddd[i]=ifile.substr(5,3);

        shc.input_s0(ifile.c_str());
        
        for(j=0;j<numCoef;j++)
        {
            if(ncs[j]=='c')coef[j][i]=shc.c(ord[j],deg[j]);
            else coef[j][i]=shc.s(ord[j],deg[j]);
        }

        cout<<"Reading file "<<ifile<<" year="<<yyyy[i]<<", ddd="<<ddd[i]<<endl;
    }
    
    cout<<"Outputing"<<endl<<flush;

    ofstream output(ofile.c_str());
    output.precision(16);
    
    output<<numFile<<endl;
    for(i=0;i<numFile;i++)output<<yyyy[i]<<"   "<<ddd[i]<<endl;
    
    output<<numCoef<<"   "<<3<<endl;
 
    for(i=0;i<numCoef;i++)
    {
        output<<ncs[i]<<"  "<<deg[i]<<"   "<<ord[i];
        for(j=0;j<numFile;j++)output<<"   "<<coef[i][j];
        output<<endl;
    }
                          
    output.close();

    return 1;
}
