//Copyright: Jun-Yi Guo

#ifndef mat_lower_triangle_h
#define mat_lower_triangle_h

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <sstream>

#include "check_error.h"

using namespace std;

template<class T>class mat_lower_triangle
{
  private:

    T* v_;
    T** r_;
    
    int n_;
    int nn_;
    
    void initialize(int n)
    {
		check_error(n<1,"Size must be at least 1.");

        n_=n;
        nn_=n_*(n_+1)/2;

        r_=new(nothrow)T*[n_];
        check_error(r_==NULL,"not enough menory");
				     	
        v_=new(nothrow)T[nn_];
        check_error(v_==NULL,"not enough menory");
        r_[0]=v_;

        for(int i=1;i<n_;i++)r_[i]=r_[i-1]+i;
    }

    void destroy()
    {
        if(nn_!=0)
        {
            delete[](r_);
            delete[](v_);
        }
    }

  public:

        /**
         * Construct an object of \em m rows and \em n columns.
         * The values of the elements are unspecified
         */
         
    explicit mat_lower_triangle(int n=0)
    {
        initialize(n);
    }

        /** 
         * The copy constructor 
         */
         
    mat_lower_triangle(const mat_lower_triangle<T>& A)
    {
        initialize(A.n_);
        int i,j;
        for(i=0;i<n_;i++)for(j=0;j<=i;j++)r_[i][j]=A[i][j];
    }
    
        /**
         * The destructor.
         */

    ~mat_lower_triangle()
    {
        destroy();
    }
    
       /** 
         * Element accessing using [][]. No bound check is made. 
         */

    T* operator[](int i)
    {
        return r_[i];
    }

        /** 
         * Element accessing using [][]. No bound check is made. 
         */

    const T* operator[](int i) const
    {
        return r_[i];
    }
    
         /**
         * The \em rv is assigned to \em lv. The sizes of \em rv and
         * of \em lv should be equal.
         */
         
     mat_lower_triangle<T>& operator=(const mat<T> &A)
    {
        if(this==&A)return *this;
        check_error(n_!=A.n_,"Sizes are different");
        
        int i,j;
        for(i=0;i<n_;i++)for(j=0;j<=i;j++)r_[i][j]=A[i][j];
        
        return *this;
    }
       
        /**
         * The \em rv is assigned to every element of \em lv. 
         */        
         
    mat_lower_triangle<T>& operator=(const T& a)
    {
        int i,j;
        for(i=0;i<n_;i++)for(j=0;j<=i;j++)r_[i][j]=a;
        return *this;
    }
    
    T* vecPtr() const
    {
        return v_;
    }
    
    int dim() const
    {
        return n_;
    }

    int size() const
    {
        return nn_;
    }
    
};

#endif 
