//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

#include "rshc.h"

using namespace std;

double fileNameToYear(string file)
{
    string yyyy,ddd;
    
    yyyy=file.substr(0,4);
    ddd=file.substr(5,3);

    return atoi(yyyy.c_str())+atoi(ddd.c_str())/365.25; 
}

int main()
{
    int i,j,k,n,m,N,M,NF;
    double c,s;
    string stmp;
    char ctmp[1001];
    string ifile,ofile;
    
    ifstream control("Extract_SHCs.txt");
    
    control>>N;
    M=N;
    control>>NF;

    rshc sc(N);
    rshc scdot(N);
    scdot=0.0;

    ifstream input;

    for(k=0;k<NF;k++)
    {
        control>>ifile;
        control>>ofile;
      
        input.open(ifile.c_str());
        
        sc.c(0,0)=1.0;
        sc.c(0,1)=0.0;
        sc.c(1,1)=0.0;
        sc.s(1,1)=0.0;
        
        for(;;)
        {
            input>>stmp;   

            if(stmp!="GRCOF2"&&stmp!="GRDOTA")
            {
                input.getline(ctmp,1000);
            }
            else
            {
                input>>n;
                input>>m;
                input>>c;
                input>>s;   
                input.getline(ctmp,1000);         
        
                if(stmp=="GRCOF2")
                { 
                    sc.c(m,n)=c;
                    if(m!=0)sc.s(m,n)=s;                           
                }
                else if(stmp=="GRDOTA")
                {
                    scdot.c(m,n)=c;
                    if(m!=0)scdot.s(m,n)=s;  
                }

                if(m==M&&n==N)break;
            }
        }

        for(j=0;j<sc.numCoef();j++)sc[j]+=scdot[j]*(fileNameToYear(ifile)-2000.0);

        sc.output_s0(ofile.c_str(),16);

        input.close();
        
        cout<<k+1<<"  "<<ifile<<"  "<<ofile<<endl<<flush;
    }

    return 0;
}
