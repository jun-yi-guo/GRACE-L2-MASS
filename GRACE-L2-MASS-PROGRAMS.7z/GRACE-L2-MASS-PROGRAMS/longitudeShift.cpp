//Copyright: Jun-Yi Guo

#include <iostream>
#include <fstream>
#include <string>
 
#include "longitudeShift.h"

using namespace std;

int main(int argc,char *argv[])
{
    string sourcefile;

    cout<<endl
        <<"Usage: longitudeShift [file]"<<endl
        <<"   Input data locations are specified in [file]"<<endl
        <<"   The default for [file] is \"longitudeShift.txt\""<<endl
        <<"   Sea README_longitudeShift.txt for detail description"<<endl;
           
    if(argc==1)
    {
        sourcefile="longitudeShift.txt";    
    }
    else if(argc==2)
    {
        sourcefile=argv[1];
    }
    else    
    {
        cout<<"Too many arguments"<<endl;
        exit(1);     
    }

    cout<<endl<<"Doing ..."<<endl;
     
    (longitudeShift)(sourcefile); 

    return 1;
} 
