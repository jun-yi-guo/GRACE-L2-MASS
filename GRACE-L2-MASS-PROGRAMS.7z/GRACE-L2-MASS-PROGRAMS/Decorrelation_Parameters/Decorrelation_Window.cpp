// Copyright: Jun-Yi Guo

#include <iostream>
#include <fstream>
#include <cmath>
#include <sstream>
#include <algorithm>
  
using namespace std;

int main()
{
    double i,nc,n,m,w;
    double A,p,al,K,N;
    
    ifstream in("Decorrelation_Window.txt");
    
    in>>N;
	in>>nc;	
	
	ostringstream name,name_figure;    
	ofstream out,out_figure;

    for(i=0;i<nc;i++)
    {
    	in>>A;
    	in>>p;
    	in>>al;
    	in>>K;
    	
		name.str("");
	    name<<"window_A"<<A<<"_p"<<p<<"_gamma"<<al<<"_K"<<K<<"_Nmax"<<N<<".txt"; 
	    
		name_figure.str("");
	    name_figure<<"window_A"<<A<<"_p"<<p<<"_gamma"<<al<<"_K"<<K<<"_Nmax"<<N<<"_figure.txt";  
	
	    out.open(name.str().c_str());
	    out_figure.open(name_figure.str().c_str());
	
	    out<<N<<endl;
	    for(n=0;n<=N;n++)
	    for(m=0;m<=n;m++)
	    {
	        w=A*exp(-pow(((1.0-al)*pow(m,p)+al*pow(n,p)),1.0/p)/K);
	        w=(int(w/2.0))*2+1;                    
	        w=max(int(w),5);
	        out<<n<<"  "<<m<<"  "<<w<<endl;
	        out_figure<<n<<"  "<<m<<"  "<<w<<endl;
	    }
    	out.close();
		out_figure.close();	        	
	}

    in.close();

//    system("pause");
    return 0;   
}
