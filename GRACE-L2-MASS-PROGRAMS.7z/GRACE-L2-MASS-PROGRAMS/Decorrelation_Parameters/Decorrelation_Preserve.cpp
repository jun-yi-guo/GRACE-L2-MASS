// Copyright: Jun-Yi Guo

#include <iostream>
#include <fstream>
#include <cmath>
#include <sstream>
#include <string>

using namespace std;

int main(int argc, char *argv[])
{
    double nf,n,m,al;
    double r,n0,n1;

    ifstream in("Decorrelation_Preserve.txt");

	in>>nf;
	
    ostringstream name;	
    ostringstream name_figure;
    ofstream out;
    ofstream out_figure;
    
    for(int k=0;k<nf;k++)
    {
	    in>>r;
	    in>>n0;
	    in>>n1;
	    
	    name.str("");
	    name<<"preserved_r"<<r<<"_l0"<<n0<<"_lm"<<n1<<".txt";
	        
	    out.open(name.str().c_str());
	    
	    al=(n1-n0)/pow(n1,r);
	
	    out<<n1<<endl;
	    
	    for(m=0;m<=n1;m++)
	    {
	        n=n0+al*pow(m,r);
	        out<<m<<"  "<<int(n)<<endl;
	    }
	    
	    out.close();
	       	
		name_figure.str("");
	    name_figure<<"preserved_r"<<r<<"_l0"<<n0<<"_lm"<<n1<<"_figure.txt";
	    
	    out_figure.open(name_figure.str().c_str());
	    
	    double step=0.01;
	    
	    for(m=0;m<=n1;m+=step)
	    {
	        n=n0+al*pow(m,r);
	        out_figure<<n<<"  "<<m<<"   "<<0<<endl;
	    }
	    
	    out_figure.close();
	    
	    cout<<k+1<<" over "<<nf<<" done ..."<<endl;
	}

 //   system("pause");
    return 0;
}
