#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>

using namespace std;

int main(int argc, char *argv[])
{
    int n,k,deg,N,nl;
   
    ifstream ctl;
    
    if(argc==1)ctl.open("Decorrelation_Preserve_Plot.txt");
    else if(argc==2)ctl.open(argv[1]); 
    else
    {
        cout<<"Incorrect usage";
        return 0;
    }
    
    ctl>>deg;
    
    ctl>>N;
    string shc[N];
    string ofile[N];
    for(n=0;n<N;n++)
	{
		ctl>>shc[n];
		ctl>>ofile[n];
	}
    
    ctl>>nl;
    string line[nl];
    for(n=0;n<N;n++)ctl>>line[n];
    
    ctl.close();
    
    ofstream out;

    for(n=0;n<N;n++)
    {
        out.open("Decorrelation_Preserve_Plot.sh");
        
        out<<"#! /bin/csh"<<endl;
        out<<"# to prepare for grd file"<<endl;
        
        out<<"set file1=\""<<shc[n]<<"\""<<endl;
        for(k=0;k<nl;k++)out<<"set file"<<k+2<<"=\""<<line[k]<<"\""<<endl;
        
        
        out<<"set file9=\""<<ofile[n]<<"\""<<endl;
        
        out<<"gmtset ANNOT_FONT_SIZE_PRIMARY=8"<<endl;
        out<<"gmtset MAP_FRAME_PEN 0.01c ANNOT_OFFSET_PRIMARY 0.05c MAP_TICK_LENGTH_PRIMARY 0.0c"<<endl;
        
		out<<"foreach i ( 1 )"<<endl;
        
        out<<"psbasemap -R0/"<<deg<<"/0/"<<deg<<" -Jx.1/.1 -B10g10/10g10WSen -K -V -Y1.8 -X.9 -P > $file9[$i]"<<endl;
        out<<"makecpt -T0.1/3.1/0.2 -Cwysiwyg>slope.cpt"<<endl;
        out<<"psxy $file1[$i] -Cslope.cpt -R -Jx.1/.1d -G0 -W1 -Sc0.1c -K -V -O -P >> $file9[$i]"<<endl;
        for(k=0;k<nl;k++)
        	out<<"psxy $file"<<k+2<<"[$i] -Cslope.cpt -R -Jx.1/.1d -G0 -W1 -Sc0.05c -K -V -O -P >> $file9[$i]"<<endl;
        out<<"psscale -Cslope.cpt -D3.0/-0.4/6.5/0.15h -O -B0.2/:: -P >> $file9[$i]"<<endl;
        out<<"psconvert -A $file9[$i] "<<endl;

        out<<"rm -f slope.cpt"<<endl;
        out<<"rm -f *.grd"<<endl;

        out<<"end"<<endl;
        out.close();
        
        system("chmod 700 Decorrelation_Preserve_Plot.sh");
        system("./Decorrelation_Preserve_Plot.sh");
        
        cout<<n+1<<" over "<<N<<" done"<<endl;
    }
}
