#! /bin/csh
# to prepare for grd file
set file1="wwindow_A_20_p1.7_gamma0.09_K10_Nmax60_figure.txt"
set file2="preserved_r3.5_l045_lm20_figure.txt"
set file3="preserved_r3.5_l055_lm28_figure.txt"
