#! /bin/csh
# to prepare for grd file

set file1="2014_008_00_STD_Clm.txt"
set file2="preserved_r3.5_l020_lm10_figure.txt"
set file3="preserved_r3.5_l035_lm15_figure.txt"

set file5="2014_008_00_STD_Clm_error.ps"

foreach i ( 1 )

gmtset ANNOT_FONT_SIZE_PRIMARY=8
gmtset MAP_FRAME_PEN 0.01c ANNOT_OFFSET_PRIMARY 0.05c MAP_TICK_LENGTH_PRIMARY 0.0c

psbasemap -R0/63/0/63 -Jx.1/.1 -B10g10/10g10WSen -K -V -Y1.8 -X.9 -P > $file5[$i]
makecpt -T0.1/3.1/0.2 -Cwysiwyg>slope.cpt
psxy $file1[$i] -Cslope.cpt -R -Jx.1/.1d -G0 -W1 -Sc0.1c -K -V -O -P >> $file5[$i]
psxy $file2[$i] -Cslope.cpt -R -Jx.1/.1d -G0 -W1 -Sc0.05c -K -V -O -P >> $file5[$i]
psxy $file3[$i] -Cslope.cpt -R -Jx.1/.1d -G0 -W1 -Sc0.05c -K -V -O -P >> $file5[$i]

#surface $file1[$i] -R -I1 -Gslope1.grd -T1
#grdimage slope1.grd -R -Jx -B -Cslope.cpt -O -K -P >> $file5[$i]

psscale -Cslope.cpt -D3.0/-0.4/6.5/0.15h -O -B0.2/:: -P >> $file5[$i]

psconvert -A $file5[$i] 
rm -f slope.cpt
end
