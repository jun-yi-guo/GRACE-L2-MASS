// Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

#include "rshc.h"

using namespace std;

int main()
{
    int i,j,k,n,m,N,TN,M,NF;
    double c,s;
    string stmp;
    char ctmp[2000],ifile[120],ofile[120];
    
    ifstream control("Extract_Error_C_lm.txt");
    
    control>>N;
    M=N;
    control>>TN;
    control>>NF;

    rshc sc(N);

    ifstream input;
    ofstream output;

    for(k=0;k<NF;k++)
    {
        control>>ifile;
        control>>ofile;
        input.open(ifile);
        
        for(;;)
        {
            input>>stmp;    
            if(stmp!="GRCOF2")
            {
                input.getline(ctmp,2000);
            }
            else
            { 
                input>>n;
                input>>m;
                input>>c;
                input>>s; 
                input>>c;
                input>>s;                   
                input.getline(ctmp,2000);
                
                sc.c(m,n)=c;
                if(m!=0)sc.s(m,n)=s;                           
                if(m==M&&n==N)break;
            }
        }
        
        sc.c(0,0)=0.0;
        sc.c(0,1)=0.0;
        sc.c(1,1)=0.0;
        sc.s(1,1)=0.0;
       
        output.open(ofile);
        
        for(m=0;m<=TN;m++)
        for(n=m;n<=TN;n++)
            output<<n<<"  "<<m<<"  "<<sc.c(m,n)*1.0e+12<<endl;
        
        input.close();
        output.close();
        
        cout<<k+1<<"  "<<ifile<<"  "<<ofile<<endl<<flush;
    }

    return 0;
}
