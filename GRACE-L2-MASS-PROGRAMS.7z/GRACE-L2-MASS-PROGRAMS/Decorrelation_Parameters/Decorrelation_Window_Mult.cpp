// Copyright: Jun-Yi Guo

#include <iostream>
#include <fstream>
#include <cmath>
#include <sstream>
#include <algorithm>

using namespace std;

int main()
{
    double i,nc,n,m,w;
    double A,p,al,K,N;
    int counter;
    
    ifstream in("Decorrelation_Window.txt");
    ofstream out_list("Decorrelation_Window_Plot.txt");
    
    N=60;

	ostringstream name_figure,name_list;    
	ofstream out_figure;
	
	out_list<<N<<endl;
	out_list<<4<<endl;
	out_list<<"preserved_r3.5_l045_lm20_figure.txt"<<endl;
	out_list<<"preserved_r3.5_l055_lm28_figure.txt"<<endl;
	out_list<<"preserved_r3.5_l045_lm15_figure.txt"<<endl;
	out_list<<"preserved_r3.5_l055_lm25_figure.txt"<<endl;
	out_list<<8645<<endl;

	for(A=20;A<=40;A+=5)
	for(p=1.7;p<=3;p+=0.1)
    for(al=0.06;al<=0.25;al+=0.01)
    for(K=10;K<=40;K+=5)
    {
		name_figure.str("");
	    name_figure<<"wwindow_A_"<<A<<"_p"<<p<<"_gamma"<<al<<"_K"<<K<<"_Nmax"<<N<<"_figure.txt";  
	    
		name_list.str("");
	    name_list<<"wwindow_A_"<<A<<"_p"<<p<<"_gamma"<<al<<"_K"<<K<<"_Nmax"<<N<<"_figure.ps";  	    
	    
//	    cout<<name_figure.str()<<endl;
	
//	    out_figure.open(name_figure.str().c_str());
	
	    for(n=0;n<=N;n++)
	    for(m=0;m<=n;m++)
	    {
	        w=A*exp(-pow(((1.0-al)*pow(m,p)+al*pow(n,p)),1.0/p)/K);
	        w=(int(w/2.0))*2+1;                    
	        w=max(int(w),5);
//	        out_figure<<n<<"  "<<m<<"  "<<w<<endl;
	    }
		out_figure.close();	 
		
		out_list<<name_figure.str()<<"   "<<name_list.str()<<endl;
		
		counter++;
		if(counter%200==0)cout<<".";      	
	}
	
	out_list.close();
    in.close();

//    system("pause");
    return 0;   
}
