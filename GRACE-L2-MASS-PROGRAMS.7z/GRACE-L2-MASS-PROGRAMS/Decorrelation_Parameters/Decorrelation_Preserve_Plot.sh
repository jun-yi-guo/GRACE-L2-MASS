#! /bin/csh
# to prepare for grd file
set file1="2019_228_00_STD_Clm.txt"
set file2="preserved_r3.5_l045_lm20_figure.txt"
set file3="preserved_r3.5_l055_lm28_figure.txt"
set file9="2019_228_00_STD_Clm_Preserve.ps"
gmtset ANNOT_FONT_SIZE_PRIMARY=8
gmtset MAP_FRAME_PEN 0.01c ANNOT_OFFSET_PRIMARY 0.05c MAP_TICK_LENGTH_PRIMARY 0.0c
foreach i ( 1 )
psbasemap -R0/60/0/60 -Jx.1/.1 -B10g10/10g10WSen -K -V -Y1.8 -X.9 -P > $file9[$i]
makecpt -T0.1/3.1/0.2 -Cwysiwyg>slope.cpt
psxy $file1[$i] -Cslope.cpt -R -Jx.1/.1d -G0 -W1 -Sc0.1c -K -V -O -P >> $file9[$i]
psxy $file2[$i] -Cslope.cpt -R -Jx.1/.1d -G0 -W1 -Sc0.05c -K -V -O -P >> $file9[$i]
psxy $file3[$i] -Cslope.cpt -R -Jx.1/.1d -G0 -W1 -Sc0.05c -K -V -O -P >> $file9[$i]
psscale -Cslope.cpt -D3.0/-0.4/6.5/0.15h -O -B0.2/:: -P >> $file9[$i]
psconvert -A $file9[$i] 
rm -f slope.cpt
rm -f *.grd
end
