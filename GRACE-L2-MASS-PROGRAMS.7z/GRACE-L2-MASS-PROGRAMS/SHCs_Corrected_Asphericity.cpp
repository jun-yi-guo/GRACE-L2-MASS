#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <fstream>
#include <string>  
#include <sstream>
#include <iomanip>

#include "check_error.h" 
#include "vec.h"
#include "mat.h"
#include "grid.h" 
#include "rsht.h" 

#include "mat_lower_triangle.h"

using namespace std;

int main(int argc,char *argv[])
{ 
	int i,j,k,l,m,n,p,q,itmp;
	double dtmp;

	//4 pi G/g_R
	double PI=4.0*atan(1.0);
	double G=6.6742e-11; 
	double GM=3.986005e+14;

	ifstream ctl("SHCs_Corrected_Asphericity.txt");	
	
	double R,gR,coef;
	
	ctl>>R;
	gR=GM/(R*R);
	coef=4*PI*G/gR;	
	
	int bw_topo;
	string ifile_topo;	
	
	ctl>>bw_topo;
	ctl>>ifile_topo;
	
	int maxDeg_topo=bw_topo-1;
	int numlat_topo=2*bw_topo, numlon_topo=2*bw_topo;

	int maxDeg_mass,bw_mass;
	int num_mass;
	
	ctl>>maxDeg_mass;
	ctl>>num_mass;	
	
	bw_mass=maxDeg_mass+1;
	int numlat_mass=2*bw_mass, numlon_mass=2*bw_mass;

	vec<string> ifile_mass(num_mass),ofile_mass(num_mass); 
	for(i=0;i<num_mass;i++)
	{
		ctl>>ifile_mass[i];
		ctl>>ofile_mass[i];
		
//		cout<<ifile_mass[i]<<" "<<ofile_mass[i]<<endl;
	}

	ctl.close();
	
	mat_lower_triangle<rshc> delta_k_qp(bw_mass);
	mat_lower_triangle<rshc> delta_k_qm(bw_mass);
	
	for(p=0;p<=maxDeg_mass;p++)
	for(q=0;q<=p;q++)
	{
		delta_k_qp[p][q].resize(maxDeg_mass);
		delta_k_qm[p][q].resize(maxDeg_mass);
		
//		delta_k_qp[p][q]=0.0;
//		delta_k_qm[p][q]=0.0;
	}

	cout<<"Pre-camputation ..."<<endl;
	{
		mat<double> epsilon(numlat_topo,numlon_topo);
		grid grd_topo("Gauss",numlat_topo,numlon_topo);
		grd_topo.input(ifile_topo,epsilon);
		epsilon/=R;
	
		rsht_memo rsht(bw_topo);
		rshc SHCsp(maxDeg_topo),SHCsm(maxDeg_topo);	
		
		vec<double> theta(2*bw_topo);
		for(int j=0;j<2*bw_topo;j++)
			theta[j]=rsht.theta(j);
	
		mat<double>lambda_sin(2*bw_topo,bw_topo),lambda_cos(2*bw_topo,bw_topo);
		for(int k=0;k<2*bw_topo;k++)
		for(int m=0;m<=maxDeg_topo;m++)	
		{
			lambda_sin[k][m]=rsht.lambda_sm(k,m);
			lambda_cos[k][m]=rsht.lambda_cm(k,m);
		}
	
		legendre_multi_theta alf(theta,maxDeg_topo);
		alf.setNormType(legendre_multi_theta::CplxFull);
		for(int n=0;n<=maxDeg_topo;n++)
		for(int k=0;k<=n;k++)
		for(int j=0;j<2*bw_topo;j++)
			alf[j][k][n]=rsht.lgdr(j,k,n);
		alf.toRealFull();
	
		mat<double> delta_k(numlat_topo,numlon_topo);
	
		for(int p=0;p<=maxDeg_mass;p++)
		for(int q=0;q<=p;q++)
		{
			if(q%10==0)cout<<"doing degree p="<<p<<" and order q="<<q<<"   "<<endl;
	
			// q positive, cos 
			for(int j=0;j<2*bw_topo;j++)
			for(int k=0;k<2*bw_topo;k++)
				delta_k[j][k]=(pow(1.0+epsilon[j][k],p+2)-1.0)*alf[j][q][p]*lambda_cos[k][q]/(2.0*p+1.0);
	
			SHCsp.setNormType(rshc::CplxFull);
			rsht.forward(SHCsp,delta_k);
			SHCsp.toRealFull();
	
			for(int n=0;n<=maxDeg_mass;n++)
			{
				dtmp=2.0*n+1.0;
				for(int k=0;k<=n;k++)
				{
					delta_k_qp[p][q].c(k,n)=SHCsp.c(k,n)*dtmp;
					delta_k_qp[p][q].s(k,n)=SHCsp.s(k,n)*dtmp;
				}		
			}
	
			// q negative, sin 
			for(int j=0;j<2*bw_topo;j++)
			for(int k=0;k<2*bw_topo;k++)
				delta_k[j][k]=(pow(1.0+epsilon[j][k],p+2)-1.0)*alf[j][q][p]*lambda_sin[k][q]/(2.0*p+1.0);
			
			SHCsm.setNormType(rshc::CplxFull);
			rsht.forward(SHCsm,delta_k);
			SHCsm.toRealFull();
	
			for(int n=0;n<=maxDeg_mass;n++)
			{
				dtmp=2.0*n+1.0;
				for(int k=0;k<=n;k++)
				{
					delta_k_qm[p][q].c(k,n)=SHCsm.c(k,n)*dtmp;
					delta_k_qm[p][q].s(k,n)=SHCsm.s(k,n)*dtmp;
				}			
			}
		}
	}	

	cout<<"Calculating corrected potential"<<endl;
	
	rshc SHCphi_t(maxDeg_mass),SHCm0(maxDeg_mass);
	
	double dtmp_c,dtmp_s,dtmp_nc,dtmp_ns;

	for(i=0;i<num_mass;i++)
	{
		SHCm0.input_s0(ifile_mass[i].c_str());
		
		for(p=0;p<=maxDeg_mass;p++)
		{       
			dtmp=(2.0*p+1.0)/coef;
			
			for(q=0;q<=p;q++)
			{
				SHCm0.c(q,p)*=dtmp;
				SHCm0.s(q,p)*=dtmp;				
			}
		}
	
		for(p=0;p<=maxDeg_mass;p++)
		{       
			dtmp=coef/(2.0*p+1.0);
			for(q=0;q<=p;q++)
			{
				SHCphi_t.c(q,p)=dtmp*SHCm0.c(q,p);
				SHCphi_t.s(q,p)=dtmp*SHCm0.s(q,p);
				
				dtmp_c=0.0;
				dtmp_s=0.0;
				for(n=0;n<=maxDeg_mass;n++)
				{         
					dtmp_nc=0.0;
					dtmp_ns=0.0;
					for(k=0;k<=n;k++)
					{
						dtmp_nc+=SHCm0.c(k,n)*delta_k_qp[p][q].c(k,n)+SHCm0.s(k,n)*delta_k_qp[p][q].s(k,n);
						dtmp_ns+=SHCm0.c(k,n)*delta_k_qm[p][q].c(k,n)+SHCm0.s(k,n)*delta_k_qm[p][q].s(k,n);
					}
					dtmp_c+=dtmp_nc/(2.0*n+1.0);
				    dtmp_s+=dtmp_ns/(2.0*n+1.0);
				}
				SHCphi_t.c(q,p)+=coef*dtmp_c;
				SHCphi_t.s(q,p)+=coef*dtmp_s;
			}		
		}

		SHCphi_t.output_s0(ofile_mass[i].c_str());
		
		cout<<i+1<<" out of "<<num_mass<<" done"<<endl;
	}
	return 0;
}
