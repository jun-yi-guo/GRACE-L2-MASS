//Copyright: Jun-Yi Guo

#ifndef fss_h
#define fss_h

#include "fftpack++.h"
#include "mat.h"
#include "grid.h"
#include "check_error.h"
#include "trig.h"

using namespace std;

class rfssg
{
    private:
    
    int nlat_;
    int nlon_;

    vec<double> rlat_;
    vec<double> rlon_;

    rcosg cost_;
    rfs   rfs_;

    void initialize(int nlat,int nlon)
    {
        nlat_=nlat;
        nlon_=nlon;
        rlat_.resize(nlat_);
        rlon_.resize(nlon_);
        cost_.resize(nlat_);
        rfs_.resize(nlon_);
    }

    public:

    rfssg(int nlat=0,int nlon=0)
    {
        initialize(nlat,nlon);
    }

    ~rfssg(){}

    void resize(int nlat=0,int nlon=0)
    {
        if(nlat!=nlat_||nlon!=nlon_)
        {
            initialize(nlat,nlon);
        }
    }

    void forward(mat<double>& x)
    {
         check_error(nlat_!=x.numRows()||nlon_!=x.numCols(), 
             "Wrong input data dimention");

         int j,k,n,m;


         for(k=0;k<nlon_;k++)
         {
             for(j=0;j<nlat_;j++)
             {
                 rlat_[j]=x[j][k];
             }
             cost_.forward(rlat_);
             for(j=0;j<nlat_;j++)
             {
                 x[j][k]=rlat_[j];
             }
         }
         
         for(j=0;j<nlat_;j++)
         {
             for(k=0;k<nlon_;k++)
             {
                 rlon_[k]=x[j][k];
             }
             rfs_.forward(rlon_);
             for(k=0;k<nlon_;k++)
             {
                 x[j][k]=rlon_[k];
             }
         }         
    }

    void inverse(mat<double>& x)
    {
         check_error(nlat_!=x.numRows()||nlon_!=x.numCols(), 
             "Wrong input data dimention");

         int j,k,n,m;

         for(k=0;k<nlon_;k++)
         {
             for(j=0;j<nlat_;j++)
             {
                 rlat_[j]=x[j][k];
             }
             cost_.inverse(rlat_);
             for(j=0;j<nlat_;j++)
             {
                 x[j][k]=rlat_[j];
             }
         }

         for(j=0;j<nlat_;j++)
         {
             for(k=0;k<nlon_;k++)
             {
                 rlon_[k]=x[j][k];
             }
             rfs_.inverse(rlon_);
             for(k=0;k<nlon_;k++)
             {
                 x[j][k]=rlon_[k];
             }
         }                  
    }     
};

class rfssl
{
    private:
    
    int nlat_;
    int nlon_;

    vec<double> rlat_;
    vec<double> rlon_;

    rcosl cost_;
    rfs   rfs_;

    void initialize(int nlat,int nlon)
    {
        nlat_=nlat;
        nlon_=nlon;
        rlat_.resize(nlat_);
        rlon_.resize(nlon_);
        cost_.resize(nlat_);
        rfs_.resize(nlon_);
    }

    public:

    rfssl(int nlat=0,int nlon=0)
    {
        initialize(nlat,nlon);
    }

    ~rfssl(){}

    void resize(int nlat=0,int nlon=0)
    {
        if(nlat!=nlat_||nlon!=nlon_)
        {
            initialize(nlat,nlon);
        }
    }

    void forward(mat<double>& x)
    {
         check_error(nlat_!=x.numRows()||nlon_!=x.numCols(), 
             "Wrong input data dimention");

         int j,k,n,m;
         
         for(k=0;k<nlon_;k++)
         {
             for(j=0;j<nlat_;j++)
             {
                 rlat_[j]=x[j][k];
             }
             cost_.forward(rlat_);
             for(j=0;j<nlat_;j++)
             {
                 x[j][k]=rlat_[j];
             }
         }
         
         for(j=0;j<nlat_;j++)
         {
             for(k=0;k<nlon_;k++)
             {
                 rlon_[k]=x[j][k];
             }
             rfs_.forward(rlon_);
             for(k=0;k<nlon_;k++)
             {
                 x[j][k]=rlon_[k];
             }
         }         
    }

    void inverse(mat<double>& x)
    {
         check_error(nlat_!=x.numRows()||nlon_!=x.numCols(), 
             "Wrong input data dimention");

         int j,k,n,m;

         for(k=0;k<nlon_;k++)
         {
             for(j=0;j<nlat_;j++)
             {
                 rlat_[j]=x[j][k];
             }
             cost_.inverse(rlat_);
             for(j=0;j<nlat_;j++)
             {
                 x[j][k]=rlat_[j];
             }
         }

         for(j=0;j<nlat_;j++)
         {
             for(k=0;k<nlon_;k++)
             {
                 rlon_[k]=x[j][k];
             }
             rfs_.inverse(rlon_);
             for(k=0;k<nlon_;k++)
             {
                 x[j][k]=rlon_[k];
             }
         }
    }
};

class realLatGridTrans
{
    private:
	
	rcosg g_trans_in;
	rcosg g_trans_out;
	
	rcosl l_trans_in;
	rcosl l_trans_out;
	
	int nlat_in,nlon_in;
	string type_in;
	
	int nlat_out,nlon_out;
	string type_out;

   void initialize(string type_in_="0",int nlat_in_=0,int nlon_in_=0,string type_out_="0",int nlat_out_=0,int nlon_out_=0)
    {
    	if(type_in_=="0")return;
    	check_error(type_in_!="Gauss"&&type_in_!="Lobbato",
			"data_grid_type must be Gauss or Lobbato");
		check_error(type_out_!="Gauss"&&type_out_!="Lobbato",
			"data_grid_type must be Gauss or Lobbato");
			
		check_error(nlon_in_!=nlon_out_, "In and out longitude grid size must be equal.");
    	
		type_in=type_in_;
		nlat_in=nlat_in_;
		nlon_in=nlon_in_;
		
		type_out=type_out_;
		nlat_out=nlat_out_;
		nlon_out=nlon_out_;
		
		if(type_in=="Gauss")g_trans_in.resize(nlat_in);
		else l_trans_in.resize(nlat_in);
		
		if(type_out=="Gauss")g_trans_out.resize(nlat_out);
		else l_trans_out.resize(nlat_out);		
    }

    public:

    realLatGridTrans(string type_in_="0",int nlat_in_=0,int nlon_in_=0, string type_out_="0",int nlat_out_=0,int nlon_out_=0)
    {
        initialize(type_in_, nlat_in_, nlon_in_, type_out_, nlat_out_, nlon_out_);
    }
    
    realLatGridTrans(grid &grid_in, grid &grid_out)
    {
    	string type_in_=grid_in.lat_grid_type();
		int nlat_in_=grid_in.num_lat_grid();
		int nlon_in_=grid_in.num_lon_grid();
		
    	string type_out_=grid_out.lat_grid_type();
		int nlat_out_=grid_out.num_lat_grid();
		int nlon_out_=grid_out.num_lon_grid();
		
        initialize(type_in_, nlat_in_, nlon_in_, type_out_, nlat_out_, nlon_out_);
    }    

    ~realLatGridTrans(){}

    void reset(string type_in_="0",int nlat_in_=0,int nlon_in_=0, string type_out_="0",int nlat_out_=0,int nlon_out_=0)
    {
    	if(type_in_!=type_in||type_out_!=type_out||nlat_in_!=nlat_in||nlat_out_!=nlat_out||nlon_in_!=nlon_in||nlon_out_!=nlon_out)
        initialize(type_in_, nlat_in_, nlon_in_, type_out_, nlat_out_, nlon_out_);
    }
    
    void reset(grid &grid_in, grid &grid_out)
    {
    	string type_in_=grid_in.lat_grid_type();
		int nlat_in_=grid_in.num_lat_grid();
		int nlon_in_=grid_in.num_lon_grid();
		
    	string type_out_=grid_out.lat_grid_type();
		int nlat_out_=grid_out.num_lat_grid();
		int nlon_out_=grid_out.num_lon_grid();
		
        reset(type_in_, nlat_in_, nlon_in_, type_out_, nlat_out_, nlon_out_);
    }    	
 	
 	void transform(mat<double> &data_in, mat<double> &data_out)
 	{
 		check_error(data_in.numRows()!=nlat_in||data_in.numCols()!=nlon_in, "input matrix size mismatch");
 		check_error(data_out.numRows()!=nlat_out||data_out.numCols()!=nlon_out, "output matrix size mismatch");
 		
 		int j,k,itmp;
		vec<double> dtmp_in(nlat_in),dtmp_out(nlat_out);
 		
 		for(k=0;k<nlon_in;k++)
 		{
 			for(j=0;j<nlat_in;j++)dtmp_in[j]=data_in[j][k];
 			
 			if(type_in=="Gauss")g_trans_in.forward(dtmp_in);
			else l_trans_in.forward(dtmp_in);
			
			itmp=min(nlat_in,nlat_out);
			for(j=0;j<itmp;j++)dtmp_out[j]=dtmp_in[j];
			for(j=itmp;j<nlat_out;j++)dtmp_out[j]=0.0;
			
 			if(type_out=="Gauss")g_trans_out.inverse(dtmp_out);
			else l_trans_out.inverse(dtmp_out);		
			
			for(j=0;j<nlat_out;j++)data_out[j][k]=dtmp_out[j];	
		}
	}
};

class realLonGridTrans
{
    private:
	
	rfs trans_in;
	rfs trans_out;
	
	int nlat_in,nlon_in;
	string shift_in;
	
	int nlat_out,nlon_out;
	string shift_out;

	double dlon_in;
	trig_one_lambda_real trig_dlon_in;
	
	double dlon_out;
	trig_one_lambda_real trig_dlon_out;
	
    void initialize(string shift_in_="0",int nlat_in_=0,int nlon_in_=0,string shift_out_="0",int nlat_out_=0,int nlon_out_=0)
    {
    	if(shift_in_=="0")return;
    	check_error(shift_in_!="no_lon_shift"&&shift_in_!="with_lon_shift",
			"data_lon_shift_type must be no_lon_shift or with_lon_shift");
		check_error(shift_out_!="no_lon_shift"&&shift_out_!="with_lon_shift",
			"data_lon_shift_type must be no_lon_shift or with_lon_shift");
			
		check_error(nlat_in_!=nlat_out_, "In and out latitude grid size must be equal.");
    	
		shift_in=shift_in_;
		nlat_in=nlat_in_;
		nlon_in=nlon_in_;

		shift_out=shift_out_;
		nlat_out=nlat_out_;
		nlon_out=nlon_out_;

		trans_in.resize(nlon_in);
		trans_out.resize(nlon_out);

		if(shift_in=="with_lon_shift")
		{	
			dlon_in=0.5*(360.0/nlon_in)*(4.0*atan(1.0)/180.0);	
			trig_dlon_in.reset(nlon_in/2);
			trig_dlon_in.evaluate(dlon_in);
			
		}
		if(shift_out=="with_lon_shift")
		{
			dlon_out=0.5*(360.0/nlon_out)*(4.0*atan(1.0)/180.0);
			trig_dlon_out.reset(nlon_out/2);
			trig_dlon_out.evaluate(dlon_out);
		}
    }

    public:

    realLonGridTrans(string shift_in_="0",int nlat_in_=0,int nlon_in_=0, string shift_out_="0",int nlat_out_=0,int nlon_out_=0)
    {
        initialize(shift_in_, nlat_in_, nlon_in_, shift_out_, nlat_out_, nlon_out_);
    }
    
    realLonGridTrans(grid &grid_in, grid &grid_out)
    {
    	string shift_in_=grid_in.lon_grid_shift();
		int nlat_in_=grid_in.num_lat_grid();
		int nlon_in_=grid_in.num_lon_grid();
		
    	string shift_out_=grid_out.lon_grid_shift();
		int nlat_out_=grid_out.num_lat_grid();
		int nlon_out_=grid_out.num_lon_grid();
		
        initialize(shift_in_, nlat_in_, nlon_in_, shift_out_, nlat_out_, nlon_out_);
    }    

    ~realLonGridTrans(){}

    void reset(string shift_in_="0",int nlat_in_=0,int nlon_in_=0, string shift_out_="0",int nlat_out_=0,int nlon_out_=0)
    {
    	if(shift_in_!=shift_in||shift_out_!=shift_out||nlat_in_!=nlat_in||nlat_out_!=nlat_out||nlon_in_!=nlon_in||nlon_out_!=nlon_out)
        initialize(shift_in_, nlat_in_, nlon_in_, shift_out_, nlat_out_, nlon_out_);
    }
    
    void reset(grid &grid_in, grid &grid_out)
    {
    	string shift_in_=grid_in.lon_grid_shift();
		int nlat_in_=grid_in.num_lat_grid();
		int nlon_in_=grid_in.num_lon_grid();
		
    	string shift_out_=grid_out.lon_grid_shift();
		int nlat_out_=grid_out.num_lat_grid();
		int nlon_out_=grid_out.num_lon_grid();
		
        reset(shift_in_, nlat_in_, nlon_in_, shift_out_, nlat_out_, nlon_out_);
    }    	
 	
 	void transform(mat<double> &data_in, mat<double> &data_out)
 	{
 		check_error(data_in.numRows()!=nlat_in||data_in.numCols()!=nlon_in, "input matrix size mismatch");
 		check_error(data_out.numRows()!=nlat_out||data_out.numCols()!=nlon_out, "output matrix size mismatch");
		
 		int i,j,k,m,itmp;
		vec<double> dtmp_in(nlon_in),dtmp_out(nlon_out);
		vec<double> dtmp_in_inter(nlon_in+1),dtmp_out_inter(nlon_out+1);
	
 		for(j=0;j<nlat_in;j++)
 		{
 			for(k=0;k<nlon_in;k++)dtmp_in[k]=data_in[j][k];			
 			trans_in.forward(dtmp_in);

 			if(shift_in=="no_lon_shift")
			{
			 	for(k=0;k<nlon_in;k++)dtmp_in_inter[k]=dtmp_in[k];
			 	dtmp_in_inter[nlon_in]=0.0;
			}
 			else
 			{
 				dtmp_in_inter[0]=dtmp_in[0];
 				for(m=1;m<=(nlon_in-1)/2;m++)
 				{
 					dtmp_in_inter[2*m-1]=dtmp_in[2*m-1]*trig_dlon_in.cm[m]-dtmp_in[2*m]*trig_dlon_in.sm[m];
 					dtmp_in_inter[2*m]  =dtmp_in[2*m-1]*trig_dlon_in.sm[m]+dtmp_in[2*m]*trig_dlon_in.cm[m];
				}
				if(nlon_in%2==0)
				{
					dtmp_in_inter[nlon_in-1]=dtmp_in[nlon_in-1]*trig_dlon_in.cm[nlon_in/2];
					dtmp_in_inter[nlon_in]  =dtmp_in[nlon_in-1]*trig_dlon_in.sm[nlon_in/2];
				}
			}

 			itmp=min(nlon_in+1,nlon_out+1);	
			for(k=0;k<itmp;k++)dtmp_out_inter[k]=dtmp_in_inter[k];
			for(k=itmp;k<nlon_out+1;k++)dtmp_out_inter[k]=0.0;
			
 			if(shift_out=="no_lon_shift")
			{
			 	for(k=0;k<nlon_out;k++)dtmp_out[k]=dtmp_out_inter[k];
			}
 			else
 			{
 				dtmp_out[0]=dtmp_out_inter[0];
  				for(m=1;m<=(nlon_out-1)/2;m++)
 				{
 					dtmp_out[2*m-1]=dtmp_out_inter[2*m-1]*trig_dlon_out.cm[m]+dtmp_out_inter[2*m]*trig_dlon_out.sm[m];
 					dtmp_out[2*m] =-dtmp_out_inter[2*m-1]*trig_dlon_out.sm[m]+dtmp_out_inter[2*m]*trig_dlon_out.cm[m];
				}
				if(nlon_out%2==0)
				{
					dtmp_out[nlon_out-1]= dtmp_out_inter[nlon_out-1]*trig_dlon_out.cm[nlon_out/2]
										 +dtmp_out_inter[nlon_out]  *trig_dlon_out.sm[nlon_out/2];								
				}
			}			
 			trans_out.inverse(dtmp_out);
			for(k=0;k<nlon_out;k++)data_out[j][k]=dtmp_out[k];
		}
	}
};

class realGridTrans
{
	private:
		
	int nlat_in,nlon_in;
	string type_in,shift_in;
	
	int nlat_out,nlon_out;
	string type_out,shift_out;
	
	mat<double> data_inter;

	realLatGridTrans lat_trans;
	realLonGridTrans lon_trans;
	
	void initialize(string type_in_="0",string shift_in_="0",int nlat_in_=0,int nlon_in_=0,
						string type_out_="0",string shift_out_="0",int nlat_out_=0,int nlon_out_=0)
    {
    	type_in=type_in_;
		shift_in=shift_in_;
		nlat_in=nlat_in_;
		nlon_in=nlon_in_;
		
		type_out=type_out_;
		shift_out=shift_out_;
		nlat_out=nlat_out_;
		nlon_out=nlon_out_;
		
		data_inter.resize(nlat_out,nlon_in);
	
		lat_trans.reset( type_in, nlat_in,nlon_in, type_out,nlat_out,nlon_in);
		lon_trans.reset(shift_in,nlat_out,nlon_in,shift_out,nlat_out,nlon_out);
    }

    public:

    realGridTrans(string type_in_="0",string shift_in_="0",int nlat_in_=0,int nlon_in_=0,
						string type_out_="0",string shift_out_="0",int nlat_out_=0,int nlon_out_=0)
    {
        initialize(type_in_,shift_in_,nlat_in_,nlon_in_,type_out_,shift_out_,nlat_out_,nlon_out_);
    }

    realGridTrans(grid &grid_in, grid &grid_out)
    {
    	string type_in_=grid_in.lat_grid_type();
		string shift_in_=grid_in.lon_grid_shift();
		int nlat_in_=grid_in.num_lat_grid();
		int nlon_in_=grid_in.num_lon_grid();
		
		string type_out_=grid_out.lat_grid_type();
    	string shift_out_=grid_out.lon_grid_shift();
		int nlat_out_=grid_out.num_lat_grid();
		int nlon_out_=grid_out.num_lon_grid();

        initialize(type_in_,shift_in_,nlat_in_,nlon_in_,type_out_,shift_out_,nlat_out_,nlon_out_);
    }    

    ~realGridTrans(){}

    void reset(string type_in_="0",string shift_in_="0",int nlat_in_=0,int nlon_in_=0,
						string type_out_="0",string shift_out_="0",int nlat_out_=0,int nlon_out_=0)
    {
    	if(type_in_!=type_in||type_out_!=type_out||shift_in_!=shift_in||shift_out_!=shift_out
				||nlat_in_!=nlat_in||nlat_out_!=nlat_out||nlon_in_!=nlon_in||nlon_out_!=nlon_out)
        initialize(type_in_,shift_in_,nlat_in_,nlon_in_,type_out_,shift_out_,nlat_out_,nlon_out_);
    }
    
    void reset(grid &grid_in, grid &grid_out)
    {
    	string type_in_=grid_in.lat_grid_type();
		string shift_in_=grid_in.lon_grid_shift();
		int nlat_in_=grid_in.num_lat_grid();
		int nlon_in_=grid_in.num_lon_grid();
		
		string type_out_=grid_out.lat_grid_type();
    	string shift_out_=grid_out.lon_grid_shift();
		int nlat_out_=grid_out.num_lat_grid();
		int nlon_out_=grid_out.num_lon_grid();
		
        reset(type_in_,shift_in_,nlat_in_,nlon_in_,type_out_,shift_out_,nlat_out_,nlon_out_);
    }
    
    void transform(mat<double> &data_in, mat<double> &data_out)
 	{
 		check_error(data_in.numRows()!=nlat_in||data_in.numCols()!=nlon_in, "input matrix size mismatch");
 		check_error(data_out.numRows()!=nlat_out||data_out.numCols()!=nlon_out, "output matrix size mismatch");

 		lat_trans.transform(data_in,data_inter);
 		lon_trans.transform(data_inter,data_out); 		
 	}
};

#endif
