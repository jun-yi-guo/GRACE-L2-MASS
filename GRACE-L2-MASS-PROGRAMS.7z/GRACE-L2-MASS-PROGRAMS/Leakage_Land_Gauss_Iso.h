//Copyright: Jun-Yi Guo

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

#include "grid.h"

using namespace std;

class leakage_land_gauss
{
  private:
  
    double r;
    int NLAT,NLON;
    int mulat,mulon;

    double s;

    int NNLAT,NNLON;

    vec<double>cost;
    vec<double>sint;
    vec<double>cosl;

    mat<double>fd;

    string of_file;
    mat<int>of;

    grid grid_;

    void initialize()
    {
        int i,j,k;
        double pi=4.0*atan(1.0);
        double tmp;

        tmp=1.0/sqrt(2.0*log(2.0));
        s=r*tmp;

        NNLAT=NLAT*mulat;
        NNLON=NLON*mulon;
        
        double dlat,dlon;

        dlat=pi/NNLAT;
        dlon=2.0*pi/NNLON;

        cost.resize(NNLAT);
        sint.resize(NNLAT);
        cosl.resize(NNLON);
        
        for(i=0;i<NNLAT;i++)
        {
            tmp=(i+0.5)*dlat;
            cost[i]=cos(tmp);
            sint[i]=sin(tmp);
        }

        for(i=0;i<NNLON;i++)
        {
            tmp=i*dlon;
            cosl[i]=cos(tmp);     
        }

        fd.resize(NLAT,NLON);

        grid_.reset("Gauss",NLAT,NLON);
      
        mat<int> ofo(NLAT,NLON);
        grid_.input(of_file,ofo);

        of.resize(NNLAT,NNLON);
        int J,K,JJ,KK,MNLAT,MNLON;
        
        MNLAT=(mulat-1)/2;
        MNLON=(mulon-1)/2;
        
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            J=j*mulat+(mulat-1)/2;
            K=k*mulon;
            
            for(JJ=J-MNLAT;JJ<=J+MNLAT;JJ++)
            for(KK=K-MNLON;KK<=K+MNLON;KK++)
            {
                if(KK>=0&&KK<NNLON)
                {
                    of[JJ][KK]=ofo[j][k];
                }

                else if(KK<0)
                {
                    of[JJ][NNLON+KK]=ofo[j][k];
                }
                else
                {
                    of[JJ][KK-NNLON]=ofo[j][k];
                }                                             
            }
        }
    }
    
    double psi(int J,int K,int JJ,int KK)
    {
        double p;
        p=cost[J]*cost[JJ]+sint[J]*sint[JJ]*cosl[abs(KK-K)];
        if(p<-1.0)p=-1.0;
        if(p>1.0)p=1.0;
        return acos(p);
    }

    double G(double x)
    {
        return exp(-(x*x)/(2.0*s*s));
    }

    void leakage()
    {
        cout<<"removing leakage..."<<endl;

        int j,k,J,K,JJ,KK,ofjk;
        
        double p,YL,YO,range,tmp;

        range=3.0*s;

		int counter=0;
		
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            J=j*mulat+(mulat-1)/2;
            K=k*mulon;
            
            ofjk=of[J][K];
            
            YL=0.0;
            YO=0.0;

            if(ofjk==0)
            {
                for(JJ=0;JJ<NNLAT;JJ++)
                for(KK=0;KK<NNLON;KK++)
                {
                    p=psi(J,K,JJ,KK);
                    
                    if(p<range)
                    {
                        if(of[JJ][KK]==ofjk)
                        {
                            YL+=G(p)*sint[JJ];
                        }
                        else
                        {
                            YO+=G(p)*sint[JJ];
                        }
                    }
                }
                
// if(YL<1.0e-20)cout<<YL<<"   ";

//cout<<fd[j][k]<<"   ";
                
                fd[j][k]*=((YL+YO)/YL);
                
//cout<<(YL+YO)/YL<<endl;
            }
            else
            {
                fd[j][k]=0.0;
            }
            
            counter++;
            if(counter%50==0)cout<<counter<<" out of "<<NLAT*NLON<<" done."<<endl;
        }
    }

  public:

    leakage_land_gauss(string of_file_,double r_,int NLAT_,int NLON_,int mulat_,int mulon_)
    {
        reset(of_file_,r_,NLAT_,NLON_,mulat_,mulon_);
    }
    
    ~leakage_land_gauss(){}

    void reset(string of_file_,double r_,int NLAT_,int NLON_,int mulat_,int mulon_)
    {
        cout<<"Initializing for leakage removing"<<endl;
        
        double pi=4.0*atan(1.0);
        
        check_error(mulat_%2==0||mulon_%2==0,"mu must be odd");

        of_file=of_file_;

        r=r_*pi/180.0;
//        r=r_;

        NLAT=NLAT_;
        NLON=NLON_;
        mulat=mulat_;
        mulon=mulon_;
        initialize();
    }
    
    void solve(mat<double> &A,mat<double> &B)
    {   
        cout<<"Filtering"<<endl;

        check_error(A.numRows()!=NLAT&&A.numCols()!=NLON,"Matrix size mismatch");
        check_error(A.numRows()!=NLAT&&A.numCols()!=NLON,"Matrix size mismatch");
        fd=A;
        leakage();
        B=fd;
    }

    void solve(string ifile,string ofile)
    {   
        ifstream in(ifile.c_str());
        ofstream out(ofile.c_str());
        out.precision(15);
        
        grid_.input(in,fd);
        leakage();
        grid_.output(out,fd);
        
        in.close();
        out.close();
    }  

    void solve(ifstream &in,ofstream &out)
    {   
        grid_.input(in,fd);
        leakage();
        grid_.output(out,fd);
    }                 
};
