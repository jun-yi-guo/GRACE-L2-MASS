//Copyright: Jun-Yi Guo

#ifndef rshsyn_h
#define rshsyn_h

#include <fstream>
#include <string>
#include <sstream>

#include <algorithm>

#include "fftpack++.h"
#include "rshc.h"
#include "mat.h"

using namespace std;

class rshsyn
{
  private:

    int bw_;
    int ngrid_;

    void create(int bw)
    {
        bw_=bw;
        if(bw_==0)return;
        
        ngrid_=2*bw_;       
    }
   
    void destroy()
    {
        if(bw_!=0)
        {
            bw_=0;
        }                
    }

  public:

    /**
     *  Constructor
     */
     
    explicit rshsyn(int bw=0)
    {
        create(bw);
    }

    /**
     *  Denstructor
     */

    ~rshsyn()
    {
        destroy();
    }

    void resize(int bw=0)
    {
        if(bw_!=bw)
        {
            destroy();
            create(bw);
        }   
    }

	//use precomputed ALF or its derivatives (using legendre transform grid)
    void synthesis(mat<double>& data, rfft &rfft_, legendre_multi_theta &p_, rshc &coef)
    {
    	check_error(coef.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
    	check_error(p_.maxDeg()!=bw_-1, "ALF max degree mismatch");
    	check_error(p_.lower_theta_index()!=0||p_.higher_theta_index()!=bw_-1,"ALF theta array mismatch");
        check_error(data.numRows()!=ngrid_||data.numCols()!=ngrid_,"error in grid size");
        check_error(data.LowerRowIndex()!=0||data.LowerColumnIndex()!=0,"grid lower index must be 0"); 
        check_error(rfft_.size()!=ngrid_,"fft object size mismatch");

        int i,j,k,l,m;
        double tmp,tmp1,tmp2;

        int N=ngrid_-1;

        vec<double> r1(ngrid_);
        vec<double> r2(ngrid_);

        for(j=0;j<bw_;j++)
        {
       		// m=0
            r1[0]=0.0;
            r2[0]=0.0;

            for(l=0;l<bw_;l++)
            {
                tmp=coef.c(0,l)*p_[j][0][l];
                r1[0]+=tmp;
                if(l%2==0)
                {
                    r2[0]+=tmp;
                }
                else
                {
                    r2[0]-=tmp;
                }
            }

            // m=1,...
            for(m=1;m<bw_;m++)
            {
                r1[2*m-1]=0.0;
                r1[2*m]=0.0;
                
                r2[2*m-1]=0.0;
                r2[2*m]=0.0;
                           
                for(l=m;l<bw_;l++)
                {
                    tmp1=coef.c(m,l)*p_[j][m][l];
                    tmp2=coef.s(m,l)*p_[j][m][l];
                    r1[2*m-1]+=tmp1;
                    r1[2*m]+=tmp2;

                    if((l-m)%2==0)
                    {
                        r2[2*m-1]+=tmp1;
                        r2[2*m]+=tmp2;
                    }else
                    {
                        r2[2*m-1]-=tmp1;
                        r2[2*m]-=tmp2;
                    }
                }

                r1[2*m-1]/=2.0;
                r1[2*m]/=-2.0;
                
                r2[2*m-1]/=2.0;
                r2[2*m]/=-2.0; 
            }

            r1[ngrid_-1]=0.0;
            r2[ngrid_-1]=0.0;    

            rfft_.inverse(r1);
            rfft_.inverse(r2);

            for(k=0;k<ngrid_;k++)
            {
                 data[j][k]=r1[k];
                 data[N-j][k]=r2[k];
            }
        }
    }

    // compute ALF in the fly (using legendre transform grid)
    void synthesis(mat<double>& data, rfft &rfft_, legendre &lgdr, trig_multi_theta &trig_t, rshc &coef, int d=0)
    {
    	check_error(d>3, "Derivatives are implimented only up to order 3"); 
    	check_error(coef.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
    	check_error(lgdr.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
        check_error(data.numRows()!=ngrid_||data.numCols()!=ngrid_,"error in grid size");
        check_error(data.LowerRowIndex()!=0||data.LowerColumnIndex()!=0,"grid lower index must be 0"); 
		check_error(rfft_.size()!=ngrid_,"fft object size mismatch");    
		check_error(trig_t.len!=bw_,"trig object size mismatch"); 
		
		legendre_one_theta p_(bw_-1);
		legendre_one_theta pa_(bw_-1);

        int i,j,k,l,m;
        double tmp,tmp1,tmp2;

        int N=ngrid_-1;

        vec<double> r1(ngrid_);
        vec<double> r2(ngrid_);

        for(j=0;j<bw_;j++)
        {
            if(d==0)
			{
				lgdr.evaluate(p_,trig_t,j);
			}
			else if (d==1)
			{
				lgdr.evaluate(pa_,trig_t,j);
				lgdr.evaluate_div(p_,pa_);
			}
			else if(d==2)
			{
				lgdr.evaluate(p_,trig_t,j);
				lgdr.evaluate_div(pa_,p_);
				lgdr.evaluate_div(p_,pa_);				
			}
			else
			{
				lgdr.evaluate(pa_,trig_t,j);
				lgdr.evaluate_div(p_,pa_);
				lgdr.evaluate_div(pa_,p_);
				lgdr.evaluate_div(p_,pa_);					
			}

            // m=0
            
            r1[0]=0.0;
            r2[0]=0.0;

            for(l=0;l<bw_;l++)
            {
                tmp=coef.c(0,l)*p_[0][l];
                r1[0]+=tmp;
                if(l%2==0)
                {
                    r2[0]+=tmp;
                }
                else
                {
                    r2[0]-=tmp;
                }
            }

            // m=1,...
            for(m=1;m<bw_;m++)
            {
                r1[2*m-1]=0.0;
                r1[2*m]=0.0;
                
                r2[2*m-1]=0.0;
                r2[2*m]=0.0;
                           
                for(l=m;l<bw_;l++)
                {
                    tmp1=coef.c(m,l)*p_[m][l];
                    tmp2=coef.s(m,l)*p_[m][l];
                    r1[2*m-1]+=tmp1;
                    r1[2*m]+=tmp2;

                    if((l-m)%2==0)
                    {
                        r2[2*m-1]+=tmp1;
                        r2[2*m]+=tmp2;
                    }else
                    {
                        r2[2*m-1]-=tmp1;
                        r2[2*m]-=tmp2;
                    }
                }

                r1[2*m-1]/=2.0;
                r1[2*m]/=-2.0;
                
                r2[2*m-1]/=2.0;
                r2[2*m]/=-2.0; 
            }

            r1[ngrid_-1]=0.0;
            r2[ngrid_-1]=0.0;    

            rfft_.inverse(r1);
            rfft_.inverse(r2);

            for(k=0;k<ngrid_;k++)
            {
                 data[j][k]=r1[k];
                 data[N-j][k]=r2[k];
            }
        }
    }

//  synthesis for a single value of theta, precomputed ALF
    void synthesis(vec<double>& data, rfft &rfft_, legendre_one_theta &p_, rshc &coef)
    {
    	check_error(coef.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
    	check_error(p_.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
        check_error(data.size()!=ngrid_,"Error in longitude grid size");
        check_error(data.lower_index()!=0,"lower ongitude grid index must be 0");
        check_error(rfft_.size()!=ngrid_,"fft object size mismatch");

        int i,j,k,l,m;

        vec<double> r1(ngrid_);
 
        r1[0]=0.0;
        for(l=0;l<bw_;l++)r1[0]+=coef.c(0,l)*p_[0][l];

        for(m=1;m<bw_;m++)
        {
            r1[2*m-1]=0.0;
            r1[2*m]=0.0;
                       
            for(l=m;l<bw_;l++)
            {
                r1[2*m-1]+=coef.c(m,l)*p_[m][l];
                r1[2*m]+=coef.s(m,l)*p_[m][l];
            }

            r1[2*m-1]/=2.0;
            r1[2*m]/=-2.0;
        }

        r1[ngrid_-1]=0.0;

        rfft_.inverse(r1);

        for(k=0;k<ngrid_;k++)data[k]=r1[k];
    }

    //  synthesis for a single point with theta and lambda, precomputed ALF
    void synthesis(double& data, legendre_one_theta &p_, trig_one_lambda_real& trig_lmd, rshc &coef)
    {
    	check_error(coef.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
    	check_error(p_.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");

        int l,m;
        double dtmp_c,dtmp_s;
        
		data=0.0;
		for(l=0;l<=bw_-1;l++)
		{ 
			//for the case of m=0;
			data+=coef.c(0,l)*p_[0][l];
		}	
		for(m=1;m<=bw_-1;m++)
		{
			dtmp_c=0.0;
			dtmp_s=0.0;
			for(l=m;l<=bw_-1;l++)
			{
				dtmp_c+=coef.c(m,l)*p_[m][l];
				dtmp_s+=coef.s(m,l)*p_[m][l];		
			}
			data+=dtmp_c*trig_lmd.cm[m]+dtmp_s*trig_lmd.sm[m];
		}
				
//		cout<<data<<endl;
//		data=0.0;
//		for(l=0;l<bw_-1;l++)
//		{
//			data+=coef.c(0,l)*p_[0][l];
//			for(m=1;m<=l;m++)
//			{
//				data+=(coef.c(m,l)*trig_lmd.cm[m]+coef.s(m,l)*trig_lmd.sm[m])*p_[m][l];
//			}
//		}
//		cout<<data<<endl;
//		system("pause");
    }   
    
    //  synthesis for a single point with theta and lambda, compute ALF in the ply
    void synthesis(double& data, legendre &lgdr, double &theta, double& lambda, rshc &coef, int d=0)
    {
    	check_error(coef.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");

		trig_one_theta trig_t;
		trig_t.evaluate(theta);	
		
		trig_one_lambda_real trig_lmd;
		trig_lmd.reset(bw_-1);
		trig_lmd.evaluate(lambda);
		
		legendre_one_theta p_(bw_-1);
		legendre_one_theta pa_(bw_-1);

        if(d==0)
		{
			lgdr.evaluate(p_,trig_t);
		}
		else if (d==1)
		{
			lgdr.evaluate(pa_,trig_t);
			lgdr.evaluate_div(p_,pa_);
		}
		else if(d==2)
		{
			lgdr.evaluate(p_,trig_t);
			lgdr.evaluate_div(pa_,p_);
			lgdr.evaluate_div(p_,pa_);				
		}
		else
		{
			lgdr.evaluate(pa_,trig_t);
			lgdr.evaluate_div(p_,pa_);
			lgdr.evaluate_div(pa_,p_);
			lgdr.evaluate_div(p_,pa_);					
		}

        synthesis(data, p_, trig_lmd, coef);
    }   

	// sum of seires in the same form as sphrical harmonic series, precomputed ALF
    void sum_sh_like_series(mat<double>& data, rfft &rfft_, legendre_multi_theta &p_, rshc &coef)
    {
    	check_error(coef.maxDeg()!=bw_-1, "Legendre coefficinet max degree mismatch");
    	check_error(p_.maxDeg()!=bw_-1, "ALF max degree mismatch");
        check_error(rfft_.size()!=ngrid_,"fft object size mismatch");

    	check_error(p_.lower_theta_index()!=data.LowerRowIndex()||p_.higher_theta_index()!=data.HigherRowIndex(),
					"input and output theta array index mismatch mismatch");
        check_error(data.numCols()!=ngrid_,"error in longitude grid size (must be 2 times bw)");
		check_error(data.LowerColumnIndex()!=0,"error in longitude grid size (lower column index must be 0)");

        int i,j,k,l,m;
		
        vec<double> r1(ngrid_);

		int j_low=data.LowerRowIndex();
		int j_high=data.HigherRowIndex();

        for(j=j_low;j<=j_high;j++)
        {
       		// m=0
            r1[0]=0.0;

            for(l=0;l<bw_;l++)
            {
                r1[0]+=coef.c(0,l)*p_[j][0][l];
            }

            // m=1,...
            for(m=1;m<bw_;m++)
            {
                r1[2*m-1]=0.0;
                r1[2*m]=0.0;

                for(l=m;l<bw_;l++)
                {
                    r1[2*m-1]+=coef.c(m,l)*p_[j][m][l];
                    r1[2*m]+=coef.s(m,l)*p_[j][m][l];
                }

                r1[2*m-1]/=2.0;
                r1[2*m]/=-2.0; 
            }

            r1[ngrid_-1]=0.0;

            rfft_.inverse(r1);

            for(k=0;k<ngrid_;k++)
            {
                 data[j][k]=r1[k];
            }
        }
    }
};

#endif
