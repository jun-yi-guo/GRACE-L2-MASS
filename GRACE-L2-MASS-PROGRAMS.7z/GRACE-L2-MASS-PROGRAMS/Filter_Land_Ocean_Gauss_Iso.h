//Copyright: Jun-Yi Guo

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

#include "grid.h"
#include "grid_conv.h"

using namespace std;

class filter_cont_ocean_gauss
{
  private:

    double r;
    int NLAT,NLON;
    int mu;

    double s;

    int NNLAT,NNLON;

    vec<double>cost;
    vec<double>sint;
    vec<double>cosl;

    mat<double>fd;
    mat<double>fdr;

    string of_file;
    mat<int>of;

    grid grid_;

    gridConv gr;

    void initialize()
    {
        int i,j,k;
        double pi=4.0*atan(1.0);
        double tmp;

        tmp=1.0/sqrt(2.0*log(2.0));
        s=r*tmp;

        NNLAT=NLAT*mu;
        NNLON=NLON*mu;
        
        double dlat,dlon;

        dlat=pi/NNLAT;
        dlon=2.0*pi/NNLON;

        cost.resize(NNLAT);
        sint.resize(NNLAT);
        cosl.resize(NNLON);
        
        for(i=0;i<NNLAT;i++)
        {
            tmp=(i+0.5)*dlat;
            cost[i]=cos(tmp);
            sint[i]=sin(tmp);
        }

        for(i=0;i<NNLON;i++)
        {
            tmp=i*dlon;
            cosl[i]=cos(tmp);     
        }

        fd.resize(NLAT,NLON);
        fdr.resize(NNLAT,NNLON);

        grid_.reset("Gauss",NLAT,NLON);

        gr.setDataType("floating");
        gr.setOriginalGrid("Gauss",NLAT,NLON);
        gr.setResultGrid("Gauss",NNLAT,NNLON);  
        
        mat<int> ofo(NLAT,NLON);
        grid_.input(of_file,ofo);

        of.resize(NNLAT,NNLON);
        int J,K,JJ,KK,MN;
        
        MN=(mu-1)/2;
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            J=j*mu+(mu-1)/2;
            K=k*mu;
            
            for(JJ=J-MN;JJ<=J+MN;JJ++)
            for(KK=K-MN;KK<=K+MN;KK++)
            {
                if(KK>=0&&KK<NNLON)
                {
                    of[JJ][KK]=ofo[j][k];
                }

                else if(KK<0)
                {
                    of[JJ][NNLON+KK]=ofo[j][k];
                }
                else
                {
                    of[JJ][KK-NNLON]=ofo[j][k];
                }                                             
            }
        }
    }

    double psi(int J,int K,int JJ,int KK)
    {
        double p;
        p=cost[J]*cost[JJ]+sint[J]*sint[JJ]*cosl[abs(KK-K)];
        if(p>1)p=1-1.0e-15;
        if(p<-1)p=-1+1.0e-15;
        return acos(p);
    }

    double G(double x)
    {
        return exp(-(x*x)/(2.0*s*s));
    }

    void filtering()
    {
        cout<<"Filtering..."<<endl;
        gr.perform(fd,fdr);

        int j,k,J,K,JJ,KK,ofjk;
        
        double p,F,Y,range,tmp;

        range=3.0*s;

        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            J=j*mu+(mu-1)/2;
            K=k*mu;
            
            ofjk=of[J][K];
            
            F=0.0;
            Y=0.0;
            
            for(JJ=0;JJ<NNLAT;JJ++)
            for(KK=0;KK<NNLON;KK++)
            if(of[JJ][KK]==ofjk)
            {
                p=psi(J,K,JJ,KK);
            
                if(p<range)
                {
                    tmp=G(p)*sint[JJ];
                    F+=fdr[JJ][KK]*tmp;
                    Y+=tmp;
                }
            }
            fd[j][k]=F/Y;
        }
    }

  public:

    filter_cont_ocean_gauss(string of_file_,double r_,int NLAT_,int NLON_,int mu_)
    {
        reset(of_file_,r_,NLAT_,NLON_,mu_);
    }
    
    ~filter_cont_ocean_gauss(){}

    void reset(string of_file_,double r_,int NLAT_,int NLON_,int mu_)
    {
        cout<<"Initializing for filtering"<<endl;
        
        double pi=4.0*atan(1.0);
        
        check_error(mu_%2==0,"mu must be odd");

        of_file=of_file_;
        r=r_*pi/180.0;
        NLAT=NLAT_;
        NLON=NLON_;
        mu=mu_;
        initialize();
    }
    
    void solve(mat<double> &A,mat<double> &B)
    {   
        cout<<"Filtering"<<endl;

        check_error(A.numRows()!=NLAT&&A.numCols()!=NLON,"Matrix size mismatch");
        check_error(A.numRows()!=NLAT&&A.numCols()!=NLON,"Matrix size mismatch");
        fd=A;
        filtering();
        B=fd;
    }

    void solve(string ifile,string ofile)
    {   
        ifstream in(ifile.c_str());
        ofstream out(ofile.c_str());
        
        grid_.input(in,fd);
        filtering();
        grid_.output(out,fd);
        
        in.close();
        out.close();
    }  

    void solve(ifstream &in,ofstream &out)
    {   
        grid_.input(in,fd);
        filtering();
        grid_.output(out,fd);
    }                 
};
