//Copyright: Jun-Yi Guo

#ifndef polyfit_h
#define polyfit_h

void polyfit_sub(int n, double *t, double *f,int m,double *r,
             double *c,double *std,double &rmsf,double &rmsr);

void plnml_sub(int m,double *r,double *c,int n,double *t,double *f);

#endif
