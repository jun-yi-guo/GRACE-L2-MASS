//Copyright: Jun-Yi Guo

#include <iostream>
#include <cstdlib>
#include <cmath>

#include "linalg.h"

using namespace std;

int *iVector(long n)
// n: length of the vector
{
    int *vec;
    vec=new int[n];
    return vec;
}

void iFreeVector(int *vec)
{
    delete[]vec;
}

int **iMatrix(int m,int n)
// m: number of rows
// n: number of columns
{
    int **mat,*vec;
    mat=new int *[m];
    vec=new int[m*n];
    mat[0]=vec;
    for(int i=1;i<m;i++)mat[i]=mat[i-1]+n;
    return mat;
}

void iFreeMatrix(int **mat)
{
    delete[]mat[0];
    delete[]mat;
}

double *Vector(long n)
// n: length of the vector
{
    double *vec;
    vec=new double[n];
    return vec;
}

void FreeVector(double *vec)
{
    delete[]vec;
}

double **Matrix(int m,int n)
// m: number of rows
// n: number of columns
{
    double **mat,*vec;
    mat=new double *[m];
    vec=new double[m*n];
    mat[0]=vec;
    for(int i=1;i<m;i++)mat[i]=mat[i-1]+n;
    return mat;
}

void FreeMatrix(double **mat)
{
    delete[]mat[0];
    delete[]mat;
}

void MatTrans(int m,int n,double **A,double **AT)
// A: a matrix with m rows and n columns
// AT: a matrix with n rows and m columns
{
	int i,j;
	for(i=0;i<m;i++)for(j=0;j<n;j++)AT[j][i]=A[i][j];
}

void MatMulVec(int m,int n,double **A,double *V,double *AV)
// A: a matrix with m rows and n columns
// v: a vecotr of length n
// AV: a vector of length m
{
	int i,j;
	for(i=0;i<m;i++)
    {
        AV[i]=0.0;
    	for(j=0;j<n;j++)AV[i]+=A[i][j]*V[j];
   	}
}

void MatMulMat(int l,int m,int n,double **A,double **B,double **AB)
// A: a matrix with l rows and m columns
// B: a matrix with m rows and n columns
// AB: a matrix with l rows and n columns
{
	int i,j,k;
	for(i=0;i<l;i++)for(k=0;k<n;k++)
	{
		AB[i][k]=0.0;
		for(j=0;j<m;j++)AB[i][k]+=A[i][j]*B[j][k];
	}
}

void VecAddVec(int n,double *X,double *Y,double *XAY)
// X: a vector of length n
// Y: a vector of length n
// XY: a vector of length n
{
	for(int i=0;i<n;i++)XAY[i]=X[i]+Y[i];
}

void VecSubVec(int n,double *X,double *Y,double *XSY)
// X: a vector of length n
// Y: a vector of length n
// XY: a vector of length n
{
	for(int i=0;i<n;i++)XSY[i]=X[i]-Y[i];
}

void MatAddMat(int m,int n,double **A,double **B,double **AAB)
// A: a matrix of m rows and n columns
// B: a matrix of m rows and n columns
// AB: a matrix of m rows and n columns
{	
	int i,j;
	for(i=0;i<n;i++)for(j=0;j<n;j++)AAB[i][j]=A[i][j]+B[i][j];
}

void MatSubMat(int m,int n,double **A,double **B,double **ASB)
// A: a matrix of m rows and n columns
// B: a matrix of m rows and n columns
// AB: a matrix of m rows and n columns
{	
	int i,j;
	for(i=0;i<n;i++)for(j=0;j<n;j++)ASB[i][j]=A[i][j]-B[i][j];
}

void VecMulSca(int n,double *V,double S,double *VMS)
// V: a vector of length n
// VMS: a vector of length n
{
	for(int i=0;i<n;i++)VMS[i]=V[i]*S;
}

void MatMulSca(int m,int n,double **A,double S,double **AMS)
// A: a matrix of m rows and n columns
// AMS: a matrix of m rows and n columns
{	
	int i,j;
	for(i=0;i<n;i++)for(j=0;j<n;j++)AMS[i][j]=A[i][j]*S;
}

double rms(int n,double *x)
// returns the rms value of the vector x
{
   double vv=0.0;
   for(int i=0;i<n;i++)vv+=x[i]*x[i];
   return sqrt(vv/n);           
}

int gauss(int n,double **a,double *b)
// solution of ax=b
// result returned in b
// a destroyed
{
    int i,j,k,irow;
    double big,temp;
    for(i=0;i<n;i++)
    {
        big=0.0; 
        for(j=i;j<n;j++)
        {
            if((temp=ABS(a[j][i]))>big)
            {
                big=temp;
                irow=j;
            }
	    }
        if(big==0.0)return 0;
        if(irow!=i)
        {
            for(j=i;j<n;j++)SWAP(a[i][j],a[irow][j]);
            SWAP(b[i],b[irow]);
	    }   
        for(j=i+1;j<n;j++)if(a[j][i]!=0.0)
        {
            temp=a[j][i]/a[i][i];
            for(k=i;k<n;k++)if(a[i][k]!=0.0)a[j][k]-=temp*a[i][k];
            if(b[i]!=0.0)b[j]-=temp*b[i];
	    }
    }
    for(i=n-1;i>=0;i--)
    {
        for(j=i+1;j<n;j++)if(a[i][j]!=0.0)b[i]-=a[i][j]*b[j];
        b[i]/=a[i][i];
    }
    return 1;
}

int gauss(int n,double **a,int m,double **b)
// solution of ax=b
// result returned in b
// a destroyed
{
    int i,j,k,irow;
    double big,temp;

    for(i=0;i<n;i++)
    {
        big=0.0;
        for(j=i;j<n;j++)
        {
            if((temp=ABS(a[j][i]))>big)
            {
                big=temp;
                irow=j;
            }
        }
        if(big==0.0)return 0;
        if(irow!=i)
        {
            for(j=i;j<n;j++)SWAP(a[i][j],a[irow][j]);
            for(j=0;j<m;j++)SWAP(b[i][j],b[irow][j]);
        }   
        for(j=i+1;j<n;j++)if(a[j][i]!=0.0)
        {
            temp=a[j][i]/a[i][i];
            for(k=i;k<n;k++)if(a[i][k]!=0.0)a[j][k]-=temp*a[i][k];
            for(k=0;k<m;k++)if(b[i][k]!=0.0)b[j][k]-=temp*b[i][k];
        }
    }
    for(i=n-1;i>=0;i--)
    {
        for(j=i+1;j<n;j++)if(a[i][j]!=0.0)for(k=0;k<m;k++)b[i][k]-=a[i][j]*b[j][k];
        for(k=0;k<m;k++)b[i][k]/=a[i][i];
    }
    return 1;
}

int gauss(int n,double **a,double **b)
// inversion of a
// result returned in b
// a destroyed
{
    int i,j,flag;
    for(i=0;i<n;i++)for(j=0;j<n;j++)b[i][j]=0.0;
    for(i=0;i<n;i++)b[i][i]=1.0;
    flag=gauss(n,a,n,b);
    return flag;
}

int chol_decomp(int n,double **a,double *p)
{
    int i,j,k;
    double sum;
    for(i=0;i<n;i++)
    {
        for(j=i;j<n;j++) 
        {
            for(sum=a[i][j],k=i-1;k>=0;k--)sum-=a[i][k]*a[j][k];
            if(i==j)
            {
                if(sum<=0.0)
                {
                    cerr<<"cholesky secomposition failed"<<endl;
                    return 0;
                }
                p[i]=sqrt(sum);
            } 
            else 
            {
                a[j][i]=sum/p[i];
            }
        }
    }
    return 1;
}

void chol_solve(int n,double **a,double *p,double *b,double *x)
{
    int i,k;
    float sum;
    for(i=0;i<n;i++)
    {
        for(sum=b[i],k=i-1;k>=0;k--)sum-=a[i][k]*x[k];
        x[i]=sum/p[i];
    }
    for(i=n-1;i>=0;i--) 
    {
        for(sum=x[i],k=i+1;k<n;k++)sum-=a[k][i]*x[k];
        x[i]=sum/p[i];
    }
}

void chol_solve(int n,double **a,double *p,int m,double **b,double **x)
{
    int i,j,k;
    float sum;
    for(j=0;j<m;j++)
    {
        for(i=0;i<n;i++)
        {
            for(sum=b[j][i],k=i-1;k>=0;k--)sum-=a[i][k]*x[j][k];
            x[j][i]=sum/p[i];
        }
        for(i=n-1;i>=0;i--) 
        {
            for(sum=x[j][i],k=i+1;k<n;k++)sum-=a[k][i]*x[j][k];
            x[j][i]=sum/p[i];
        }
    }
}

void chol_inv(int n,double **a,double **b)
{
    int i,j,k;
    double *p,sum;
    
    p=Vector(n);
    
    chol_decomp(n,a,p);
    
    for(i=0;i<n;i++) 
    {
        a[i][i]=1.0/p[i];
        for(j=i+1;j<n;j++) 
        {
            sum=0.0;
            for(k=i;k<j;k++)sum-=a[j][k]*a[k][i];
            a[j][i]=sum/p[j];
        }
    }

    for(i=0;i<n;i++)
    for(j=i;j<n;j++)
    {
        b[i][j]=0.0;
        for(k=j;k<n;k++)b[i][j]+=a[k][i]*a[k][j];
    }
    
    for(i=0;i<n;i++)
    for(j=0;j<i;j++)
    {
        b[i][j]=b[j][i];
    }
    
    FreeVector(p);
}
