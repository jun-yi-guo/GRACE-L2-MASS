//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <fstream>
#include <string>
#include <cmath>

#include "rsht.h"
#include "grid_conv.h"

using namespace std;

class filter_gauss
{
  private:

    string ioGridType;

    grid iogrid;
    gridConv tgridconv;
    gridConv bgridconv;
    rsht_memo sphTrans;

    mat<double> source;
    mat<double> result;
    mat<double> A;
    rshc S;

    int NLAT,NLON;
    int bw;
    double r; 
    
    vec<double> W;

    void initialize()
    {
        int i;

        double tmp;

        bw=NLON/2;
        W.resize(bw);

        r*=(4.0*atan(1.0))/180.0;
        
        tmp=log(2.0)/(1.0-cos(r));
        W[0]=1.0;
        W[1]=(1.0+exp(-2.0*tmp))/(1.0-exp(-2.0*tmp))-1.0/tmp;
        for(i=2;i<bw;i++)
        {
            if(W[i-1]>1.0e-5) W[i]=-((2.0*i-1.0)/tmp)*W[i-1]+W[i-2];
            else W[i]=0.0;
        }

        iogrid.reset(ioGridType,NLAT,NLON);

        tgridconv.setDataType("floating");
        tgridconv.setOriginalGrid(ioGridType,NLAT,NLON);
        tgridconv.setResultGrid("Gauss",2*bw,2*bw);
        
        bgridconv.setDataType("floating");
        bgridconv.setOriginalGrid("Gauss",2*bw,2*bw);
        bgridconv.setResultGrid(ioGridType,NLAT,NLON);

        source.resize(NLAT,NLON);
        result.resize(NLAT,NLON);
        A.resize(2*bw,2*bw);
        S.resize(bw-1);
        sphTrans.resize(bw);
    }

    void filtering()
    {
        int l,m;
         
        if(ioGridType!="Gauss"||NLAT!=2*bw||NLON!=2*bw) tgridconv.perform(source,A);
        else A=source;

        sphTrans.forward(S,A);

        for(l=0;l<bw;l++)
        {
            S.c(0,l)*=W[l];
            for(m=1;m<=l;m++)
            {
                S.c(m,l)*=W[l];
                S.s(m,l)*=W[l];
            }
        }

        sphTrans.inverse(A,S);
        
        if(ioGridType!="Gauss"||NLAT!=2*bw||NLON!=2*bw)bgridconv.perform(A,result);
        else result=A;
    }

  public:
         
    filter_gauss(){}

    filter_gauss(string gtype_,double r_,int NLAT_,int NLON_)
    {
        reset(gtype_,r_,NLAT_,NLON_);
    }
    
    ~filter_gauss(){}

    void reset(string gtype_,double r_,int NLAT_,int NLON_)
    {
        cout<<"Initializing for filtering"<<endl;

        if(NLAT_!=0&&NLON_!=0)
            check_error(gtype_!="Gauss"&&gtype_!="Lobbato",
                        "should be Gauss or Lobbato for grid type");
        ioGridType=gtype_;
        r=r_;
        NLAT=NLAT_;
        NLON=NLON_;
        
        initialize();
    }
    
    void solve(mat<double> &A_,mat<double> &B_)
    {   
        cout<<"Filtering"<<endl;

        check_error(A.numRows()!=NLAT&&A.numCols()!=NLON,"Matrix size mismatch");
        check_error(A.numRows()!=NLAT&&A.numCols()!=NLON,"Matrix size mismatch");
        source=A_;
        filtering();
        B_=result;
    }
    
    void solve(string ifile,string ofile)
    {   
        ifstream in(ifile.c_str());
        ofstream out(ofile.c_str());
        out.precision(16);
        
        iogrid.input(in,source);
        filtering();
        iogrid.output(out,result);
        
        in.close();
        out.close();
    }      
};
