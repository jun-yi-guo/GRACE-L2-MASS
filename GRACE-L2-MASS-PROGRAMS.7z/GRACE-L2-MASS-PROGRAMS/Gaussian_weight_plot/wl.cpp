#include <cstdlib>
#include <fstream>
#include <string>
#include <cmath>

using namespace std;

void w(long double rr,long double Deg,long double *W)
{
    long double tmp=log(2.0)/(1.0-cos(rr));
    W[0]=1.0;
    W[1]=(1.0+exp(-2.0*tmp))/(1.0-exp(-2.0*tmp))-1.0/tmp;
    for(int i=2;i<=Deg;i++)
    {
        if(W[i-1]>1.0e-9) W[i]=-((2.0*i-1.0)/tmp)*W[i-1]+W[i-2];
        else W[i]=0.0;
    }
}

int main()
{    
    int i,j;
    long double tmp, rr, W[121];
    
    long double R=6371.0;
    long double r[]={200,250,300,350,400,450,500,600,800};
    
    ofstream out;
    for(i=0;i<9;i++)
    {
        rr=r[i]/R;
        w(rr,120,W);
        
        if(r[i]==200)out.open("w_200km.txt");
        if(r[i]==250)out.open("w_250km.txt");
        if(r[i]==300)out.open("w_300km.txt");
        if(r[i]==350)out.open("w_350km.txt");
        if(r[i]==400)out.open("w_400km.txt");
        if(r[i]==450)out.open("w_450km.txt");
        if(r[i]==500)out.open("w_500km.txt");
        if(r[i]==600)out.open("w_600km.txt");
        if(r[i]==800)out.open("w_800km.txt");

        for(j=0;j<=120;j++)out<<j<<"  "<<W[j]<<endl;
        out.close();
    }
    
    return 1;
}
    
    
