gmt psbasemap -R0/120/0/1 -JX15/10 -Ba10f10g5/a0.1f0.1g0.05WS -K -V -Xc -Yc > gaussian.ps
gmt psxy w_200km.txt -R -J -B -W1.0p -O -V -K >> gaussian.ps
gmt psxy w_250km.txt -R -J -B -W1.0p -O -V -K >> gaussian.ps
gmt psxy w_300km.txt -R -J -B -W1.0p -O -V -K  >> gaussian.ps
gmt psxy w_350km.txt -R -J -B -W1.0p -O -V -K  >> gaussian.ps
gmt psxy w_400km.txt -R -J -B -W1.0p -O -V -K  >> gaussian.ps
gmt psxy w_450km.txt -R -J -B -W1.0p -O -V -K  >> gaussian.ps
gmt psxy w_500km.txt -R -J -B -W1.0p -O -V -K  >> gaussian.ps
gmt psxy w_600km.txt -R -J -B -W1.0p -O -V -K  >> gaussian.ps
gmt psxy w_800km.txt -R -J -B -W1.0p -O -V  >> gaussian.ps

gmt ps2raster gaussian.ps -A 
