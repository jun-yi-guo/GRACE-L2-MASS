//Copyright: Jun-Yi Guo

#include <cmath>
#include <cstdlib> 
#include <iostream> 
#include <fstream>

#include "rsht.h"                 

using namespace std;

int main()    
{    
    int i,j,k,bw,numFile;
    double R;
    string ifile,ofile;
    
    ifstream input("SHCs2Geoid.txt");
    
    input>>R;
    input>>bw;
    input>>numFile;

    rsht_memo sht(bw);
    rshc shc(bw-1);
    mat<double>geoid(2*bw,2*bw);

    ofstream out;

    for(i=0;i<numFile;i++)
    {
        input>>ifile;
        input>>ofile;
        out.open(ofile.c_str());
        out.precision(16);

        shc.input_s0(ifile.c_str());
        
        shc.setNormType(rshc::RealFull);

        shc.toCplxFull();
        
        sht.inverse(geoid,shc);
        for(j=0;j<2*bw;j++)
        for(k=0;k<2*bw;k++)
        {
            out<<90.0-(j+0.5)*(180.0/(2*bw))<<"   "
               <<k*360.0/(2*bw)<<"  "
               <<R*geoid[j][k]<<endl;
        }
        out.close();
		
		cout<<i+1<<" out of "<<numFile<<" done..."<<endl;        
    }

//   system("pause");

    return 0;   
}
