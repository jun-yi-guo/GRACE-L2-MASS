//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;

int str2int(string s)
{
    return atoi(s.c_str());
}

string int2str(int i,int N)
{
     int j,M;
     string value,prev;
     char c[10],tmp[10];
     
//     prev=itoa(i,tmp,10);
     
     ostringstream ss;
     ss<<i;
     prev=ss.str();
     
     M=prev.size();
     
     if(M>N)
     {
         cout<<"String length too short to accormodate the integer"<<endl;
         return 0;
     }
     
     value="";
     for(j=0;j<N-M;j++)value+="0";
     value+=prev;
     return value;  
}

int main()
{
    int i,N,iy,idm,id1,id2;
    int y0,yl,d10,d1l,d20,d2l;
    string sy,sdm,sd1,sd2;
    string oriname,newname,copyfile,copy,suffix;
    
    ifstream input("Rename_l2_Files.txt");

    input>>copy;
    input>>y0;
    input>>yl;
    input>>d10;
    input>>d1l;
    input>>d20;
    input>>d2l;
    input>>suffix;
    input>>N;

    for(i=0;i<N;i++)
    {
         input>>oriname;
         
         sy=oriname.substr(y0,yl);
         sd1=oriname.substr(d10,d1l);
         sd2=oriname.substr(d20,d2l);
         
         iy=str2int(sy);
         id1=str2int(sd1);
         id2=str2int(sd2);
         
         if(id2<id1)id2+=365;
         if(iy%4==0)id2++;

         idm=(id1+id2)/2;
          
         if(iy%4==0)
         {
            if(idm>366)
            {
                iy++;
                idm-=366;
            }
         }
         else
         {      
            if(idm>365)
            {
                iy++; 
                idm-=365; 
            }              
         }
         
         sy=int2str(iy,4);
         sdm=int2str(idm,3);
         
         newname=sy+"_"+sdm+suffix+".txt";
         
         cout<<oriname<<" -> "<<newname<<endl;
         
         copyfile=copy+" "+oriname+" "+newname;

         system(copyfile.c_str());
    }

    return 0;
}
