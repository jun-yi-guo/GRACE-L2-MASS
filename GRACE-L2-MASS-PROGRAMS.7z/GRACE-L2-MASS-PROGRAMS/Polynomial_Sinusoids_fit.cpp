//Copyright: Jun-Yi Guo

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <cmath>

#include "linalg.h"

#define PI 3.141592653589793238

using namespace std;

void fit_sub(int numTim, double *Tim, double *Data,double iniTim,
             int numMon,double *degMon,double *coeMon,
             int numHar,double *perHar,double *coeCos, double *coeSin,
             double *stdMon, double *stdCos,double *stdSin,
             double &rmsData, double &rmsResi,
             double **A,double **AT,double **N,double **NINV,
             double *x,double *b,double *h,double *v,double *v0);
             
int main()
{
    int i,j,k,numTim,numGri,numMon,numHar,numAttr;

    double iniTim,*degMon,*perHar,yyyy,ddd,*Tim;
    
    string *Attr;
    
    double *Data,*coeMon,*coeCos,*coeSin;
    double *stdMon,*stdCos,*stdSin,rmsData,rmsResi;
    
    double **A,**AT,**N,**NINV,*x,*h,*v,*b,*v0;
  
    string ifile,ofile;
  
    ifstream input("Polynomial_Sinusoids_fit.txt");
    
    input>>iniTim;

    input>>numMon;
    degMon=Vector(numMon);
    for(i=0;i<numMon;i++)input>>degMon[i];
  
    input>>numHar;
    perHar=Vector(numHar);
    for(i=0;i<numHar;i++)input>>perHar[i];
  
    input>>ifile;
    input>>ofile;

    ifstream in(ifile.c_str());
    ofstream out(ofile.c_str());
    out.precision(16);
  
    input.close();
    
    in>>numTim;
    Tim=Vector(numTim);
    for(i=0;i<numTim;i++)
    {
        in>>yyyy;
        in>>ddd;
        Tim[i]=yyyy+ddd/365.25;
        cout<<Tim[i]<<endl;
    }
        
    in>>numGri;
    in>>numAttr;

    Attr=new string[numAttr];
 
    Data=Vector(numTim);
    coeMon=Vector(numMon);
    stdMon=Vector(numMon);
    coeCos=Vector(numHar);
    stdCos=Vector(numHar);
    coeSin=Vector(numHar);
    stdSin=Vector(numHar);
    
    int numVar=numMon+2*numHar;
    A=Matrix(numTim,numVar);
    AT=Matrix(numVar,numTim);
    N=Matrix(numVar,numVar);
    NINV=Matrix(numVar,numVar);
    b=Vector(numVar);
    x=Vector(numVar);
    h=Vector(numTim);
    v=Vector(numTim);
    v0=Vector(numTim);
    
    out<<"Description of data"<<endl;
    out<<"-------------------"<<endl<<endl;
    
    out<<"At each grid point, the data are fitted in the form of"<<endl<<endl;
    
    out<<"\\sum_{i=0}^m a_i(t-t0)^{k_i} + \\sum_{i=0}^n ";
    out<<"{b_i\\cos[(2*PI/T_i)*(t-t0)]+c_i\\sin[(2*PI/T_t)*(t-t0)]}"<<endl<<endl;
    out<<"where the degrees of monomials, k_i, and the periods, T_i, are prescribed as input"<<endl<<endl;
    
    out<<"****************************************************************"<<endl<<endl;

    out<<"Column 1-"<<numAttr<<": Index/Attributes of the data sequences"<<endl;

    out<<"Column "<<numAttr+1<<"-"<<numAttr+numMon<<": Polynomial coefficients of degree ";
    for(i=0;i<numMon;i++)out<<degMon[i]<<", ";
    out<<endl;

    out<<"Column "<<numAttr+numMon+1<<"-"<<numAttr+numMon+2*numHar
       <<": Coefficients of Cosine and Sine successively of periods ";
    for(i=0;i<numHar;i++)out<<perHar[i]<<", ";
    out<<endl;

    out<<"Column "<<numAttr+numMon+2*numHar+1<<"-"<<numAttr+2*numMon+2*numHar
       <<": std of the polynomial coefficients of degrees ";
    for(i=0;i<numMon;i++)out<<degMon[i]<<", ";
    out<<endl; 
     
    out<<"Column "<<numAttr+2*numMon+2*numHar+1<<"-"<<numAttr+2*numMon+4*numHar
       <<": std of the coefficients of Cosine and Sine successively of periods ";
    for(i=0;i<numHar;i++)out<<perHar[i]<<", ";
    out<<endl;    
  
    out<<"Column "<<numAttr+2*numMon+4*numHar+1<<": RMS of the original data"<<endl;
    out<<"Column "<<numAttr+2*numMon+4*numHar+2<<": RMS of the residual"<<endl<<endl;
         
    out<<"****************************************************************"<<endl;
    out<<numGri<<"    "<<numAttr<<endl;

    for(k=0;k<numGri;k++)
    {
        for(i=0;i<numAttr;i++)in>>Attr[i];
        for(i=0;i<numTim;i++)in>>Data[i];

        fit_sub(numTim,Tim,Data,iniTim,
             numMon,degMon,coeMon,numHar,perHar,coeCos,coeSin,
             stdMon,stdCos,stdSin,rmsData,rmsResi,
             A,AT,N,NINV,x,b,h,v,v0);
        
        for(i=0;i<numAttr;i++)out<<Attr[i]<<"  ";
        for(i=0;i<numMon;i++)out<<coeMon[i]<<"   ";
        for(i=0;i<numHar;i++)out<<coeCos[i]<<"   "<<coeSin[i]<<"   ";
        for(i=0;i<numMon;i++)out<<stdMon[i]<<"   ";
        for(i=0;i<numHar;i++)out<<stdCos[i]<<"   "<<stdSin[i]<<"   "; 
        out<<rmsData<<"   "<<rmsResi<<endl;
        
        if(k%100==0)cout<<k+1<<" over "<<numGri<<" done"<<endl<<flush;
    }
  
    FreeVector(Data);
    FreeVector(coeMon);
    FreeVector(coeCos);
    FreeVector(coeSin);
    FreeVector(stdMon);
    FreeVector(stdCos);
    FreeVector(stdSin);
    FreeMatrix(A);
    FreeMatrix(AT);
    FreeMatrix(N);
    FreeMatrix(NINV);
    FreeVector(x);
    FreeVector(b);
    FreeVector(h);
    FreeVector(v);
    FreeVector(v0);
        
    delete[]Attr;
    
    in.close();
    out.close();
    FreeVector(Tim);
    FreeVector(degMon);

//    system("PAUSE");	
    return 0;
}

void fit_sub(int numTim, double *Tim, double *Data,double iniTim,
             int numMon,double *degMon,double *coeMon,
             int numHar,double *perHar,double *coeCos, double *coeSin,
             double *stdMon, double *stdCos,double *stdSin,
             double &rmsData, double &rmsResi,
             double **A,double **AT,double **N,double **NINV,double *x,
             double *b,double *h,double *v,double *v0)
{
    static int count=0;
    
    int i,j,k;
    double phi;
    
    int numVar=numMon+2*numHar;

    if(count==0)
    {
        for(k=0;k<numTim;k++)
        for(i=0;i<numMon;i++)
        {
            A[k][i]=pow((Tim[k]-iniTim),degMon[i]);
        }
        for(k=0;k<numTim;k++)
        for(i=0;i<numHar;i++)
        {
            phi=(2.0*PI/perHar[i])*(Tim[k]-iniTim);
            A[k][numMon+2*i]=cos(phi);
            A[k][numMon+2*i+1]=sin(phi);            
        }
//    for(k=0;k<numTim;k++){for(i=0;i<numVar;i++)cout<<A[k][i]<<"  ";cout<<endl;}

    	MatTrans(numTim,numVar,A,AT);
    	MatMulMat(numVar,numTim,numVar,AT,A,N);	
    	
    	gauss(numVar,N,NINV);	    
    }
    
    for(k=0;k<numTim;k++)h[k]=Data[k];
   	
    MatMulVec(numVar,numTim,AT,h,b);
   	MatMulVec(numVar,numVar,NINV,b,x);
	
	MatMulVec(numTim,numVar,A,x,v0);
	VecSubVec(numTim,v0,h,v);
    
// for(i=0;i<numTim;i++)cout<<Data[i]<<"  "<<h[i]<<"  "<<v0[i]<<"  "<<-v[i]<<endl;    
// cout<<endl;    
    
    for(i=0;i<numMon;i++)coeMon[i]=x[i];
    for(i=0;i<numHar;i++)
    {
        coeCos[i]=x[numMon+2*i];
        coeSin[i]=x[numMon+2*i+1];       
    }    
    
    double eu=0.0;
    
   	for(i=0,eu=0.0;i<numTim;i++)eu+=v[i]*v[i];
   	eu/=(numTim-numVar); 
   	
   	for(i=0;i<numVar;i++)x[i]=sqrt(NINV[i][i]*eu);
    
    for(i=0;i<numMon;i++)stdMon[i]=x[i];
    for(i=0;i<numHar;i++)
    {
        stdCos[i]=x[numMon+2*i];
        stdSin[i]=x[numMon+2*i+1];       
    }        
    
    rmsData=rms(numTim, Data);
    rmsResi=rms(numTim, v);
    
//    cout<<count<<endl;
    count++;         
}
