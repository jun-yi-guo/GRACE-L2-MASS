//Copyright: Jun-Yi Guo

#ifndef _LINALG_H_
#define _LINALG_H_

#define SIGN(a,b) ((b)>=0.0? fabs(a):-fabs(a))

template<class T> 
inline T ABS(T a){return (a>=0)? a:-a;}

template<class T> 
inline T SQR(T a){return a*a;}

template<class T> 
inline T CUB(T a){return a*a*a;}

template<class T> 
inline T MAX(T a,T b){return (a>b)? a:b;}

template<class T> 
inline T MIN(T a,T b){return (a<b)? a:b;}

template<class T>
inline void SWAP(T &a,T &b) {T temp;temp=a;a=b;b=temp;}

int *iVector(long n);

void iFreeVector(int *vec);

int **iMatrix(int m,int n);

void iFreeMatrix(int **mat);

double *Vector(long n);

void FreeVector(double *vec);

double **Matrix(int m,int n);

void FreeMatrix(double **mat);

void MatTrans(int m,int n,double **A,double **AT);

void MatMulVec(int m,int n,double **A,double *V,double *AV);

void MatMulMat(int l,int m,int n,double **A,double **B,double **AB);

void VecAddVec(int n,double *X,double *Y,double *XAY);

void VecSubVec(int n,double *X,double *Y,double *XSY);

void MatAddMat(int m,int n,double **A,double **B,double **AAB);

void MatSubMat(int m,int n,double **A,double **B,double **ASB);

void VecMulSca(int n,double *V,double S,double *VMS);

void MatMulSca(int m,int n,double **A,double S,double **AMS);

double rms(int n,double *x);

int gauss(int n,double **a,double *b);

int gauss(int n,double **a,int m,double **b);

int gauss(int n,double **a,double **b);

int chol_decomp(int n,double **a,double *p);

void chol_solve(int n,double **a,double *p,double *b,double *x);

void chol_solve(int n,double **a,double *p,int m,double **b,double **x);

void chol_inv(int n,double **a,double **b);

#endif
