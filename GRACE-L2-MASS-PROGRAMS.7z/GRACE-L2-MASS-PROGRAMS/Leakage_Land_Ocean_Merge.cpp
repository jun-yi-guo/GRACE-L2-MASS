//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <iostream>
#include <cmath>    
#include <fstream>   
 
#include "check_error.h"
#include "mat.h"
#include "grid.h"
  
using namespace std;

int main(int argc, char *argv[])
{
    int i,j,k,NLAT,NLON,NFILE;

    string ifile_s,ifile_l,ifile_ls,ofile,of_file;

    ifstream input("Leakage_Land_Ocean_Merge.txt");
    
    input>>of_file;
    input>>NLAT;
    input>>NLON;
    input>>NFILE;
   
    grid gr("Gauss",NLAT,NLON);
    
    mat<int> of(NLAT,NLON);
    
    gr.input(of_file,of);
    
    mat<double> so(NLAT,NLON),dl(NLAT,NLON),dls(NLAT,NLON),rst(NLAT,NLON);
    
    cout<<"doing ..."<<endl;
    
    for(i=0;i<NFILE;i++)
    {
        input>>ifile_s;
        input>>ifile_l;
        input>>ifile_ls;
        input>>ofile;

        gr.input(ifile_s,so);
        gr.input(ifile_l,dl);
        gr.input(ifile_ls,dls);
        
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            if(of[j][k]==1)
            {
                rst[j][k]=so[j][k]-dls[j][k];
            }
            else
            {
                rst[j][k]=dl[j][k];
            }                
        }
        
        gr.output(ofile,rst);
        
        cout<<i+1<<" over "<<NFILE<<" done"<<endl;
    }

    system("PAUSE");
    return 1;
}
