//Copyright: Jun-Yi Guo

#include <iostream>
#include <string>

#include "rfss.h"
#include "grid.h"
#include "Filter_Global_Gauss_Iso.h"

using namespace std;

class filter_global_grid_gauss
{
  private:
  
    double rl,rt;
    bool isW;
    int NLAT,NLON;
    
    bool even;
    int M;
    double sl,st;
    vec<double>fcl;
    mat<double>gamma;

    vec<double>x;
    mat<double>fd;
    mat<double>fdr;
    
    rfssg rfssg_;
    rcosg rcosg_;
    rfs rfs_;

    grid grid_;
    
    filter_gauss gauss;
    mat<double>fdrg;

    double W(double x,bool isW)
    {
        if(isW)return sin(x);
        else return 1.0;
    }
    
    double G(double x,double sigma)
    {
        return exp(-(x*x)/(2.0*sigma*sigma));
    }

    void initialize()
    {
        int i,j,k,m,n;
        double tmp;
     
        if(NLON%2==0)
        {
            even=true;
            M=NLON/2;
        }
        else
        {
            even=false;
            M=(NLON-1)/2;    
        }
        
        tmp=1.0/sqrt(2.0*log(2.0));
        st=rt*tmp;
        sl=rl*tmp;
        
        fcl.resize(M+1);
        tmp=exp(-0.5*sl*sl);
        for(m=0;m<=M;m++)fcl[m]=pow(tmp,m*m);
        
        gamma.resize(NLAT,NLAT);
        
        double pi=4.0*atan(1.0);

        vec<double>theta(NLAT);
        for(j=0;j<NLAT;j++)theta[j]=pi*(j+0.5)/NLAT;
        
        rcosg_.resize(NLAT);
        vec<double>GW(NLAT);
        for(j=0;j<NLAT;j++)
        {
            for(i=0;i<NLAT;i++)GW[i]=G(theta[i]-theta[j],st)*W(theta[i],isW);
            rcosg_.forward(GW);
            tmp=(1.0/(pi*GW[0]))*(pi*0.5);
            gamma[0][j]=tmp*2.0*GW[0];
            for(n=1;n<NLAT;n++)gamma[n][j]=tmp*GW[n];
        }
        
        x.resize(NLON);
        fd.resize(NLAT,NLON);
        fdr.resize(NLAT,NLON);
        rfssg_.resize(NLAT,NLON);
        rfs_.resize(NLON);
      
//        double R=6.371e+6;
//        double r=R*rt;

        gauss.reset("Gauss",rt*(180.0/pi),NLAT,NLON);
        fdrg.resize(NLAT,NLON);
    }

    void filtering()
    {
        cout<<"Filtering ..."<<endl;

        gauss.solve(fd,fdrg);
        
        rfssg_.forward(fd);
        
        int j,k,m,n;
        double tmp;
        
        for(n=0;n<NLAT;n++)
        {
            if(even)
            {
                for(m=1;m<M;m++)
                {
                    fd[n][2*m-1]*=fcl[m]; 
                    fd[n][2*m]*=fcl[m]; 
                }
                fd[n][2*M-1]*=fcl[M];
            }
            else
            {
                for(m=1;m<=M;m++)
                {
                    fd[n][2*m-1]*=fcl[m]; 
                    fd[n][2*m]*=fcl[m]; 
                }
            }
        }

        for(n=0;n<NLAT;n++)
        {
            for(k=0;k<NLON;k++)x[k]=fd[n][k];
            rfs_.inverse(x);
            for(k=0;k<NLON;k++)fd[n][k]=x[k];
        }
                           
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            fdr[j][k]=0.0; 
            for(n=0;n<NLAT;n++)fdr[j][k]+=fd[n][k]*gamma[n][j];                  
        }
        
        double pi=4.0*atan(1.0);
        double LatC=asin(rt/rl);
        LatC=(pi/2.0-LatC)*180.0/pi;
       
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            if(fabs(grid_.latitude(j))>LatC)fdr[j][k]=fdrg[j][k];
        }
    }

  public:
    
    filter_global_grid_gauss(){}
    
    filter_global_grid_gauss(double rt_,double rl_,string isW_,int NLAT_,int NLON_)
    {
        reset(rt_,rl_,isW_,NLAT_,NLON_);
    }
    
    ~filter_global_grid_gauss(){}

    void reset(double rt_,double rl_,string isW_,int NLAT_,int NLON_)
    {
        cout<<"Initializing for filtering"<<endl;
        
        double pi=4.0*atan(1.0);
        
        check_error(isW_!="wW"&&isW_!="nW","should be wW or nW for weighting selection");
        
        if(isW_=="wW")isW=true;
        else isW=false;
        
        rt=rt_*pi/180.0;
        rl=rl_*pi/180.0;
        NLAT=NLAT_;
        NLON=NLON_;
        initialize();
        
        grid_.reset("Gauss",NLAT,NLON);
    }

    void solve(mat<double> &A,mat<double> &B)
    {   
        cout<<"Filtering"<<endl;

        check_error(A.numRows()!=NLAT&&A.numCols()!=NLON,"Matrix size mismatch");
        check_error(A.numRows()!=NLAT&&A.numCols()!=NLON,"Matrix size mismatch");
        fd=A;
        filtering();
        B=fdr;
    }
    
    void solve(string ifile,string ofile)
    {   
        ifstream in(ifile.c_str());
        ofstream out(ofile.c_str());
        
        out.precision(16);
        
        grid_.input(in,fd);
        filtering();
        grid_.output(out,fdr);
        
        in.close();
        out.close();
    }           
    
    void solve(ifstream &in,ofstream &out)
    {   
        grid_.input(in,fd);
        filtering();
        grid_.output(out,fdr);
    }      
};
