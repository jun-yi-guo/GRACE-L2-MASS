#ifndef fftpackplusplus_h
#define fftpackplusplus_h

#ifndef __cplusplus
    #error fftpackplusplus is for cplusplus only
#endif

#include <complex>

#include "check_error.h"
#include "fftpack.h"
#include "vec.h"

using namespace std;

class cfft
{
  private:

    int n_;
    int *ifac_;
    double *wsave_;

    void initialize(int n)
    {
        n_=n;
        if(n_!=0)
        {
            ifac_=new(nothrow)int[8*sizeof(int)-1]; //number of bit of an int minus 1
            check_error(ifac_==NULL, "not enough menory");
            wsave_=new(nothrow)double[4*n_];
            check_error(wsave_==NULL, "not enough menory");
            
            cffti(&n_,wsave_,ifac_);
        }
    }
       
    void destroy()
    {
       if(n_!=0)
       {
           delete[]ifac_;
           delete[]wsave_;         
       }
    }
          
  public:      
    /**
     *  Constructor
     */
     
    explicit cfft(int n=0)
    {
        initialize(n);
    }    
    
    /**
     *  Denstructor
     */
     
    ~cfft()
    {
        destroy();
    }      
	
	int size()
    {
    	return n_;
    }
        
    void resize(int n=0)
    {
        if(n!=n_)
        {
            destroy();                       
            initialize(n);
        }
    }
        
	// 	as a real array of double lentgh
		  
    /**
     *  Forward Complex Discrete Fourier Transform.
     */

    void forward(vec<double>&x)
    {
        int n=x.size()/2;
        check_error(n!=n_, "length is different");
        cfftf(&n,x.ptr(),wsave_,ifac_);        
    }  

    /**
     *  Inverse Complex Discrete Fourier Transform.
     */

    void inverse(vec<double>&x)
    {
        int n=x.size()/2;
        check_error(n!=n_, "length is different");
        cfftb(&n,x.ptr(),wsave_,ifac_);
    }
    
    // as a complex array

    void forward(vec<complex<double> > &x)
    {
        int n=x.size();
        check_error(n!=n_, "length is different");
        
        int j;

        vec<double>y(2*n);
        for(j=0;j<n;j++)
        {
        	y[2*j]=x.ptr()[j].real();
        	y[2*j+1]=x.ptr()[j].imag();
        }
        
        cfftf(&n,y.ptr(),wsave_,ifac_);    
        for(j=0;j<n;j++)
        {
        	x.ptr()[j].real(y[2*j]);
        	x.ptr()[j].imag(y[2*j+1]);
        }		
		    
    }  

    void inverse(vec<complex<double> > &x)
    {
        int n=x.size();
        check_error(n!=n_, "length is different");
        
        int j;

        vec<double>y(2*n);
        for(j=0;j<n;j++)
        {
        	y[2*j]=x.ptr()[j].real();
        	y[2*j+1]=x.ptr()[j].imag();
        }        
        
        cfftb(&n,y.ptr(),wsave_,ifac_);
        for(j=0;j<n;j++)
        {
        	x.ptr()[j].real(y[2*j]);
        	x.ptr()[j].imag(y[2*j+1]);
        }
    }
};

class rfft
{
  private:

    int n_;
    int *ifac_;
    double *wsave_;

    void initialize(int n)
    {
        n_=n;
        if(n_!=0)
        {
            ifac_=new(nothrow)int[8*sizeof(int)-1];
            check_error(ifac_==NULL, "not enough menory");
            wsave_=new(nothrow)double[2*n_];
            check_error(wsave_==NULL, "not enough menory");
            
            rffti(&n_,wsave_,ifac_);
        }
    }

    void destroy()
    {
       if(n_!=0)
       {
           delete[]ifac_;
           delete[]wsave_;         
       }
    }

  public:      
    /**
     *  Constructor
     */
     
    explicit rfft(int n=0)
    {
        initialize(n);
    }    
    
    /**
     *  Denstructor
     */
     
    ~rfft()
    {
        destroy();
    }  
    
    int size()
    {
    	return n_;
    }
    
    void resize(int n=0)
    {
        if(n!=n_)
        {
            destroy();                       
            initialize(n);
        }
    }

    /**
     *  Forward double Discrete Fourier Transform.
     */

    void forward(vec<double>&x)
    {
        int n=x.size();
        check_error(n!=n_, "length is different");
        rfftf(&n,x.ptr(),wsave_,ifac_);        
    }  

    /**
     *  Inverse double Discrete Fourier Transform.
     */

    void inverse(vec<double>&x)
    {
        int n=x.size();
        check_error(n!=n_, "length is different");
        rfftb(&n,x.ptr(),wsave_,ifac_);
    }
};

class rcosq
{
  private:

    int n_;
    int *ifac_;
    double *wsave_;

    void initialize(int n)
    {
        n_=n;
        if(n_!=0)
        {
            ifac_=new(nothrow)int[8*sizeof(int)-1];
            check_error(ifac_==NULL, "not enough menory");
            wsave_=new(nothrow)double[3*n_];
            check_error(wsave_==NULL, "not enough menory");

            cosqi(&n_,wsave_,ifac_);
        }
    }

    void destroy()
    {
       if(n_!=0)
       {
           delete[]ifac_;
           delete[]wsave_;         
       }
    }

  public:      
    /**
     *  Constructor
     */
     
    explicit rcosq(int n=0)
    {
        initialize(n);
    }    
    
    /**
     *  Denstructor
     */
     
    ~rcosq()
    {
        destroy();
    }  
    
    void resize(int n=0)
    {
        if(n!=n_)
        {
            destroy();                       
            initialize(n);
        }
    }
          
    /**
     *  Forward double Discrete Fourier Transform.
     */

    void forward(vec<double>&x)
    {
        int n=x.size();
        check_error(n!=n_, "length is different");
        cosqf(&n,x.ptr(),wsave_,ifac_);        
    }  

    /**
     *  Inverse double Discrete Fourier Transform.
     */

    void inverse(vec<double>&x)
    {
        int n=x.size();
        check_error(n!=n_, "length is different");
        cosqb(&n,x.ptr(),wsave_,ifac_);
    }
};

class rcost
{
  private:

    int n_;
    int *ifac_;
    double *wsave_;

    void initialize(int n)
    {
        n_=n;
        if(n_!=0)
        {
            ifac_=new(nothrow)int[8*sizeof(int)-1];
            check_error(ifac_==NULL, "not enough menory");
            wsave_=new(nothrow)double[3*n_];
            check_error(wsave_==NULL, "not enough menory");

            costi(&n_,wsave_,ifac_);
        }
    }

    void destroy()
    {
       if(n_!=0)
       {
           delete[]ifac_;
           delete[]wsave_;         
       }
    }

  public:      
    /**
     *  Constructor
     */
     
    explicit rcost(int n=0)
    {
        initialize(n);
    }    
    
    /**
     *  Denstructor
     */
     
    ~rcost()
    {
        destroy();
    }  
    
    void resize(int n=0)
    {
        if(n!=n_)
        {
            destroy();                       
            initialize(n);
        }
    }
          
    /**
     *  Forward double Discrete Fourier Transform.
     */

    void trans(vec<double>&x)
    {
        int n=x.size();
        check_error(n!=n_, "length is different");
        cost(&n,x.ptr(),wsave_,ifac_);        
    }  
};

class rsinq
{
  private:

    int n_;
    int *ifac_;
    double *wsave_;

    void initialize(int n)
    {
        n_=n;
        if(n_!=0)
        {
            ifac_=new(nothrow)int[8*sizeof(int)-1];
            check_error(ifac_==NULL, "not enough menory");
            wsave_=new(nothrow)double[3*n_];
            check_error(wsave_==NULL, "not enough menory");

            sinqi(&n_,wsave_,ifac_);
        }
    }

    void destroy()
    {
       if(n_!=0)
       {
           delete[]ifac_;
           delete[]wsave_;         
       }
    }

  public:      
    /**
     *  Constructor
     */
     
    explicit rsinq(int n=0)
    {
        initialize(n);
    }    
    
    /**
     *  Denstructor
     */
     
    ~rsinq()
    {
        destroy();
    }  
    
    void resize(int n=0)
    {
        if(n!=n_)
        {
            destroy();                       
            initialize(n);
        }
    }
          
    /**
     *  Forward double Discrete Fourier Transform.
     */

    void forward(vec<double>&x)
    {
        int n=x.size();
        check_error(n!=n_, "length is different");
        sinqf(&n,x.ptr(),wsave_,ifac_);        
    }  

    /**
     *  Inverse double Discrete Fourier Transform.
     */

    void inverse(vec<double>&x)
    {
        int n=x.size();
        check_error(n!=n_, "length is different");
        sinqb(&n,x.ptr(),wsave_,ifac_);
    }
};

class rsint
{
  private:

    int n_;
    int *ifac_;
    double *wsave_;

    void initialize(int n)
    {
        n_=n;
        if(n_!=0)
        {
            ifac_=new(nothrow)int[8*sizeof(int)-1];
            check_error(ifac_==NULL, "not enough menory");
            wsave_=new(nothrow)double[5*n_/2+2];
            check_error(wsave_==NULL, "not enough menory");

            sinti(&n_,wsave_,ifac_);
        }
    }

    void destroy()
    {
       if(n_!=0)
       {
           delete[]ifac_;
           delete[]wsave_;         
       }
    }

  public:      
    /**
     *  Constructor
     */
     
    explicit rsint(int n=0)
    {
        initialize(n);
    }    
    
    /**
     *  Denstructor
     */
     
    ~rsint()
    {
        destroy();
    }  
    
    void resize(int n=0)
    {
        if(n!=n_)
        {
            destroy();                       
            initialize(n);
        }
    }
          
    /**
     *  Forward double Discrete Fourier Transform.
     */

    void trans(vec<double>&x)
    {
        int n=x.size();
        check_error(n!=n_, "length is different");
        sint(&n,x.ptr(),wsave_,ifac_);        
    }  
};

class rcosg
{
    private:
            
    int n_;
    
    rcosq trans;
    
    public:
           
    explicit rcosg(int n=0)
    {
        n_=n;
        trans.resize(n);
    }
    
    ~rcosg(){}
    
    void resize(int n=0)
    {
        if(n!=n_)
        {
            n_=n;
            trans.resize(n);
        }
    }
               
    void forward(vec<double> &x)
    {
        trans.inverse(x);
        
        double tmp=1.0/(2.0*n_);
        
        x[0]*=tmp/2.0;
        for(int i=1;i<n_;i++)
        {
            x[i]*=tmp;
        }
    }
               
    void inverse(vec<double> &x)
    {
       for(int i=1;i<n_;i++)
        {
            x[i]*=0.5;
        }
        
        trans.forward(x);
    }
};

class rcosl
{
    private:
            
    int n_;
    
    rcost trans;
    
    public:
           
    explicit rcosl(int n=0)
    {
        n_=n;
        trans.resize(n);
    }
    
    ~rcosl(){}
    
    void resize(int n=0)
    {
        if(n!=n_)
        {
            n_=n;
            trans.resize(n);
        }
    }

    void forward(vec<double> &x)
    {
        trans.trans(x);
        
        double tmp=1.0/(n_-1);
        
        x[0]*=tmp/2.0;
        x[n_-1]*=tmp/2.0;
        
        for(int i=1;i<n_-1;i++)
        {
            x[i]*=tmp;
        }
    }

    void inverse(vec<double> &x)
    {
        for(int i=1;i<n_-1;i++)
        {
            x[i]*=0.5;
        }

        trans.trans(x);
    }
};

class rfs
{
    private:
            
    int n_;
    
    rfft trans;
    
    public:
           
    explicit rfs(int n=0)
    {
        n_=n;
        trans.resize(n);
    }
    
    ~rfs(){}
    
    void resize(int n=0)
    {
        if(n!=n_)
        {
            n_=n;
            trans.resize(n);
        }
    }

    void forward(vec<double> &x)
    {
        trans.forward(x);
        
        int i;

        double tmp=2.0/n_;

        if(n_%2==0)
        {
            x[0]*=1.0/n_;
            for(i=1;i<n_/2;i++)
            {
                x[2*i-1]*=tmp;
                x[2*i]*=-tmp;
                
            }
            x[n_-1]*=1.0/n_;
        }
        else
        {
            x[0]*=1.0/n_;
            for(i=1;i<=(n_-1)/2;i++)
            {
                x[2*i-1]*=tmp;
                x[2*i]*=-tmp;
            }
        }
    }
               
    void inverse(vec<double> &x)
    {
        int i;

        double tmp=0.5;

        if(n_%2==0)
        {
            for(i=1;i<n_/2;i++)
            {
                x[2*i-1]*=tmp;
                x[2*i]*=-tmp;
            }
        }
        else
        {
            for(i=1;i<=(n_-1)/2;i++)
            {
                x[2*i-1]*=tmp;
                x[2*i]*=-tmp;
            }
        }

        trans.inverse(x);
    }
};

#endif
