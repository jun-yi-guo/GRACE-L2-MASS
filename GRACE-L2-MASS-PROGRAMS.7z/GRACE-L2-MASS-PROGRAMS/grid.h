//Copyright: Jun-Yi Guo

#ifndef grid_h
#define grid_h

#include <iostream>
#include <fstream>
#include <cmath>
#include <string>

#include "vec.h"
#include "mat.h"

using namespace std;

class grid
{  
  public:
  	
    string Type;
    string lon_shift;
    
    int NLAT,NLON;
    double dlat,dlon;
    vec<double>lat,lon;

    grid(string type_="0",int NLAT_=0,int NLON_=0,string lon_shift_="no_lon_shift")
    {
        reset(type_,NLAT_,NLON_,lon_shift_);
    }

    ~grid(){}

    void reset(string type_="0",int NLAT_=0,int NLON_=0,string lon_shift_="no_lon_shift")
    {  	
        if(type_=="0")return;      
        check_error(NLAT_==0||NLAT_==0, "Size can not be zero");
        check_error(type_!="Gauss"&&type_!="Lobbato"&&type_!="Other", 
			"Wrong grid type definition: must be Gauss, Lobbato or Other");
        check_error(lon_shift_!="no_lon_shift"&&lon_shift_!="with_lon_shift", 
			"Wrong lon_shift type definition: Must be no_lon_shift or with_lon_shift");

        int j,k;

        NLON=NLON_;
        lon.resize(NLON);
        dlon=360.0/NLON;        
        for(k=0;k<NLON;k++)lon[k]=k*dlon;
		
		lon_shift=lon_shift_;
		if(lon_shift=="with_lon_shift")lon+=dlon/2.0;
			     
        NLAT=NLAT_;
        lat.resize(NLAT);
        
        if(type_=="Gauss")
        {
            Type="Gauss";
            dlat=180.0/NLAT;
            for(j=0;j<NLAT;j++)lat[j]=90.0-(j+0.5)*dlat;               
        }
        else if(type_=="Lobbato")
        {
            Type="Lobbato";    
            dlat=180.0/(NLAT-1);
            for(j=0;j<NLAT-1;j++)lat[j]=90.0-j*dlat;
            lat[NLAT-1]=-90.0;
        }
        else
        {
        	Type="Other";
        }
	}

	void set_latitude(vec<double> &latv)
	{
		check_error(Type!="Other", "Only type 'Other' requires to set latitude");
		check_error(latv.size()!=NLAT, "Latitude vector size mismatch grid latitude number");
		int nlow=latv.lower_index();
		for(int i=0;i<NLAT;i++)lat[i]=latv[nlow+i];
	}
	
    string lat_grid_type()
    {
        return Type;
    }

    string lon_grid_shift()
    {
        return lon_shift;
    }	

    double latitude_internal()
    {
        return dlat;
    }

    double longitude_interval()
    {
        return dlon;
    }
    
    int num_lat_grid()
    {
        return NLAT;
    }

    int num_lon_grid()
    {
        return NLON;
    }
    
    double latitude(int j)
    {
        return lat[j];
    }

    double longitude(int k)
    {
        return lon[k];
    }
    
    void latitude_ALL_to_theta_RAD(vec<double> &theta)
    {
    	check_error(theta.size()!=NLAT, "Size of theta different from number of latitude");
    	
		double d2r=4.0*atan(1.0)/180.0;
		
		int ilow=theta.lower_index();
    	for(int i=0;i<NLAT;i++)theta[i+ilow]=(90.0-lat[i])*d2r;
    }

    // GE0 means great or equal to 0 if grid is regular 
    void latitude_GE0_to_theta_RAD(vec<double> &theta)
    {
    	int num;
    	
    	if(NLAT%2==0)num=NLAT/2;
    	else num=(NLAT+1)/2;
    	
    	check_error(num!=theta.size(), "Size of theta mismatch the number of latitude");
    	
		double d2r=4.0*atan(1.0)/180.0;
		
		int ilow=theta.lower_index();
    	for(int i=0;i<num;i++)theta[i+ilow]=(90.0-lat[i])*d2r;
    }
  
    void longitude_to_lambda_RAD(vec<double> &lambda)
    {
//    	cout<<lambda.size()<<"  "<<NLON<<endl;
    	check_error(lambda.size()!=NLON, "Size of theta different from number of longitude");
    	
		double d2r=4.0*atan(1.0)/180.0;
		
		int ilow=lambda.lower_index();
    	for(int i=0;i<NLON;i++)lambda[i+ilow]=lon[i]*d2r;
    } 
   
    template<class T>
    void input(ifstream &in,mat<T> &A)
    {
        int j,k;
        double tlat,tlon,tol=1.0e-2;
                
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            in>>tlat;
            in>>tlon;
            check_error(fabs((tlat-lat[j])/dlat)>tol,"Error in source data file"); 
            check_error(fabs((tlon-lon[k])/dlon)>tol,"Error in source data file"); 
            in>>A[j][k];
        }
    }

    template<class T>
    void input(string ifile,mat<T> &A)
    {
        int j,k;
        double tlat,tlon,tol=1.0e-2;

        ifstream in(ifile.c_str());
        check_error(!in,"file not opened");
        
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            in>>tlat;
            in>>tlon;
                                      	
//			cout<<tlat<<"  "<<lat[j]<<endl;
//			cout<<tlon<<"  "<<lon[k]<<endl;
//			system("pause");
            
            check_error(fabs((tlat-lat[j])/dlat)>tol,"Error in source data file"); 
            check_error(fabs((tlon-lon[k])/dlon)>tol,"Error in source data file"); 
            in>>A[j][k];
        }
        
//        cout<<"HERE"<<endl;
//        system("pause");
        
        in.close();
    }

    template<class T>
    void output(ofstream &out, mat<T> &A)
    {
        int j,k;
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            out<<lat[j]<<"  "<<lon[k]<<"  "<<A[j][k]<<endl;
        }         
    }

    template<class T>
    void output(string ofile, mat<T> &A,int digits=15)
    {
        int j,k;
        
        ofstream out(ofile.c_str());
        out.precision(digits);
        
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            out<<lat[j]<<"  "<<lon[k]<<"  "<<A[j][k]<<endl;
        } 
        out.close();        
    }
    
    // longitude from -180 t0 180
    
    template<class T>
    void input_180(ifstream &in,mat<T> &A)
    {
        int j,k;
        double tlat,tlon,tol=1.0e-2;
        
        int NLON_180;
        if(NLON%2==0)NLON_180=NLON/2;
        else NLON_180=(NLON-1)/2;
        
        for(j=0;j<NLAT;j++)
        {      	
	        for(k=NLON_180+1;k<NLON;k++)
	        {
	        	in>>tlat;
	        	in>>tlon;
	        	in>>A[j][k];
	        	
//	        	cout<<tlat<<"  "<<tlon+360.0<<"  "<<lon[k]<<endl;

	            check_error(fabs((tlat-lat[j])/dlat)>tol,"Error in source data file"); 
	            check_error(fabs((tlon+360.0-lon[k])/dlon)>tol,"Error in source data file");
	        }
	        for(k=0;k<NLON_180+1;k++)
	        {
	        	in>>tlat;
	        	in>>tlon;
	        	in>>A[j][k];
//	        	cout<<tlat<<"  "<<tlon<<"  "<<lon[k]<<endl;

	            check_error(fabs((tlat-lat[j])/dlat)>tol,"Error in source data file"); 
	            check_error(fabs((tlon-lon[k])/dlon)>tol,"Error in source data file");
	    	}
        }
    }

    template<class T>
    void input_180(string ifile,mat<T> &A)
    {
        int j,k;
        double tlat,tlon,tol=1.0e-2;
        
        ifstream in(ifile.c_str());
        check_error(!in,"file not opened");
        
        int NLON_180;
        if(NLON%2==0)NLON_180=NLON/2;
        else NLON_180=(NLON-1)/2;
        
        for(j=0;j<NLAT;j++)
        {      	
	        for(k=NLON_180+1;k<NLON;k++)
	        {
	        	in>>tlat;
	        	in>>tlon;
	        	in>>A[j][k];
	        	
//	        	cout<<tlat<<"  "<<tlon+360.0<<"  "<<lon[k]<<endl;

	            check_error(fabs((tlat-lat[j])/dlat)>tol,"Error in source data file"); 
	            check_error(fabs((tlon+360.0-lon[k])/dlon)>tol,"Error in source data file");
	        }
	        for(k=0;k<NLON_180+1;k++)
	        {
	        	in>>tlat;
	        	in>>tlon;
	        	in>>A[j][k];
//	        	cout<<tlat<<"  "<<tlon<<"  "<<lon[k]<<endl;

	            check_error(fabs((tlat-lat[j])/dlat)>tol,"Error in source data file"); 
	            check_error(fabs((tlon-lon[k])/dlon)>tol,"Error in source data file");
	    	}
        }

        in.close();
    }

    template<class T>
    void output_180(ofstream &out, mat<T> &A)
    {    	        
        int NLON_180;
        if(NLON%2==0)NLON_180=NLON/2;
        else NLON_180=(NLON-1)/2;

        int j,k;
        
        for(j=0;j<NLAT;j++)
        {
	        for(k=NLON_180+1;k<NLON;k++)
	        {
	        	out<<lat[j]<<"  "<<lon[k]-360.0<<"  "<<A[j][k]<<endl;
	        }
	        for(k=0;k<NLON_180+1;k++)
	        {
	        	out<<lat[j]<<"  "<<lon[k]<<"  "<<A[j][k]<<endl;
	        }          	
		}  
    }

    template<class T>
    void output_180(string ofile, mat<T> &A,int digits=15)
    {
        int j,k;
        
        ofstream out(ofile.c_str());
        out.precision(digits);
        
        int NLON_180;
        if(NLON%2==0)NLON_180=NLON/2;
        else NLON_180=(NLON-1)/2;

        for(j=0;j<NLAT;j++)
        {
	        for(k=NLON_180+1;k<NLON;k++)
	        {
	        	out<<lat[j]<<"  "<<lon[k]-360.0<<"  "<<A[j][k]<<endl;
	        }
	        for(k=0;k<NLON_180+1;k++)
	        {
	        	out<<lat[j]<<"  "<<lon[k]<<"  "<<A[j][k]<<endl;
	        }
		}

        out.close();        
    }
};

#endif
