//Copyright: Jun-Yi Guo

#ifndef check_error_h
#define check_error_h

#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

class check_error
{
  public:
  	
    check_error(bool b,string c)
    {
        if(b)
        {
            cerr<<c;
            exit(1);
        }
    }  
    
    check_error(string c)
    {
        cerr<<c;
        exit(1);
    }          
};

#endif
