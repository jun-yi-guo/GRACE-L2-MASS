//copyright: Jun-Yi Guo

#include <cstdlib>
#include <fstream>
#include <string>
#include <cmath>

#include "rshc.h"
#include "vec.h"

using namespace std;

int main()
{
    int i,j,k,l,m,Deg,bw,numFile;   
    double R,r,tmp;
    string ifile,ofile;
    
    ifstream input("Isotropic_Gaussian_SHCs.txt");

    input>>R;
    input>>r;
    input>>Deg;
    bw=Deg+1;
    
    vec<double>W(bw);

    tmp=log(2.0)/(1.0-cos(r/R));
    W[0]=1.0;
    W[1]=(1.0+exp(-2.0*tmp))/(1.0-exp(-2.0*tmp))-1.0/tmp;
    for(i=2;i<bw;i++)
    {
        if(W[i-1]>1.0e-7) W[i]=-((2.0*i-1.0)/tmp)*W[i-1]+W[i-2];
        else W[i]=0.0;
    }

    rshc filtered(Deg),unfiltered(Deg);
   
    input>>numFile;

    for(i=0;i<numFile;i++)
    {
        input>>ifile;
        input>>ofile;
        
        unfiltered.input_s0(ifile.c_str());

        for(l=0;l<bw;l++)
        {
            filtered.c(0,l)=unfiltered.c(0,l)*W[l];
            for(m=1;m<=l;m++)
            {
                filtered.c(m,l)=unfiltered.c(m,l)*W[l];
                filtered.s(m,l)=unfiltered.s(m,l)*W[l];
            }
        }

        filtered.output_s0(ofile.c_str(),16);    
        
        cout<<i+1<<" over "<<numFile<<" done."<<endl;          
    }
    
    input.close();

 //   system("pause");
    return 0;
}
