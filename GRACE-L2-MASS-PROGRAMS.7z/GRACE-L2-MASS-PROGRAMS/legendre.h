//Copyright: Jun-Yi Guo

#ifndef legendre_h
#define legendre_h

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <cmath>

#include "check_error.h"
#include "vec.h"
#include "mat.h"
#include "trig.h"

using namespace std;

/**
 *  Associate Legendre function
 */

class legendre_order_one_theta
{
  friend class legendre;

  public:
         
    enum nmTypes{CplxFull,RealFull,CplxSemi,RealSemi,UnNorm};
    enum dfTypes{FERRER,HOBSON};
  
    nmTypes nmType;
    dfTypes dfType;
  	  
  private:

  	int L;
  	int m;
  	
  	double *pl;
  	int dim;

  	void initialize(int order, int maxDeg)
  	{
    	check_error(maxDeg!=-1&&order>maxDeg, 
			"Order larger then maximum degree");

  		L=maxDeg;
  		m=order;
  		
  		if(L==-1)return;
  				
  		dim=L-m+1;
  		pl=new(std::nothrow) double[dim];
        check_error(pl==NULL,"Not enough memory");
        pl-=m;
  	}
  	
  	void destroy()
  	{
  		if(L!=-1)delete[](pl+m);
    }

    void convFromCplxFullTo(nmTypes nm)
    {
        int k,n;
        double coef,tmp;
				    
        switch(nm)
        {
            case CplxFull:
                 
                break;

            case RealFull:

				if(m!=0)
				{ 
					coef=sqrt(2.0);
	                for(n=m;n<=L;n++)pl[n]*=coef;
				}

                break;
                
            case CplxSemi:
            	
 				for(n=m;n<=L;n++)pl[n]*=sqrt(1.0/(2.0*n+1.0));
				
                break;
                
            case RealSemi:
            	
 				if(m!=0)
				{
				 	for(n=m;n<=L;n++)pl[n]*=sqrt(2.0/(2.0*n+1.0)); 
				}
				else
				{
					for(n=m;n<=L;n++)pl[n]*=sqrt(1.0/(2.0*n+1.0)); 
				}
				
                break;
                
            case UnNorm:

                for(n=m;n<=L;n++)
                {
                    coef=sqrt(1.0/(2.0*n+1.0)); 
					for(k=1;k<=m;k++)coef*=sqrt((n-k+1.0)*(n+k));
					pl[n]*=coef;  
                } 
                
                break;
        }
                
        nmType=nm;  
    }

    void convToCplxFull()
    {
        int n,k;
        double tmp,coef;
				        
        switch(nmType)
        {
            case CplxFull:
                 
                break;

            case RealFull:
                
                if(m!=0)
				{
					coef=1.0/sqrt(2.0);
					for(n=m;n<=L;n++)pl[n]*=coef;	
				}

                break;
                
            case CplxSemi:
            	
            	for(n=m;n<=L;n++)pl[n]*=sqrt(2.0*n+1.0);
            	
            	break;
                
            case RealSemi:

                if(m!=0)
                {
                	for(n=m;n<=L;n++)pl[n]*=sqrt((2.0*n+1.0)/2.0);
                }
                else 
				{
					for(n=m;n<=L;n++)pl[n]*=sqrt(2.0*n+1.0);
				}

                break;
                
            case UnNorm:
                
                for(n=m;n<=L;n++)
                {
                	coef=sqrt(2.0*n+1.0);
                    for(k=1;k<=m;k++)coef/=sqrt((n-k+1.0)*(n+k)); 
					pl[n]*=coef;              	
				}
				
                break;
        }

        nmType=CplxFull;  
    }

    void swapType()
    {
        int n;
        if(m%2==1)for(n=m;n<=L;n++)pl[n]=-pl[n];     
    }

  public:
  	
    explicit legendre_order_one_theta(int order=0, int maxDeg=-1,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
    	nmType=nm;
        dfType=df;
         
    	initialize(order,maxDeg);
    }
    
    ~legendre_order_one_theta()
    {
		destroy();
	}
    
    void reset(int order=0, int maxDeg=-1,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
    	nmType=nm;
        dfType=df;
        if(L!=maxDeg||m!=order)
        {
            destroy();
            initialize(order,maxDeg);
        }
    }

    int maxDeg()
    {
    	return L;
    }
    
    int order()
    {
    	return m;
    }    

    double& operator[](int i)
    {
        return pl[i];
    }

    /** 
     * Element accessing using [].	No bound check is made. 
     */

    double& operator[](int i) const
    {
        return pl[i];
    }
    
    void setNormType(nmTypes nm)
    {
        nmType=nm;
    }
 
    void setDefType(dfTypes df)
    {
        dfType=df;
    }   
    
    void toCplxFull()
    {
        convToCplxFull();
    }

    void toRealFull()
    {
        convToCplxFull();
        convFromCplxFullTo(RealFull);
    }

    void toCplxSemi()
    {
        convToCplxFull();
        convFromCplxFullTo(CplxSemi);
    }
    
    void toRealSemi()
    {
        convToCplxFull();
        convFromCplxFullTo(RealSemi);
    }

    void toUnNorm()
    {
        convToCplxFull();
        convFromCplxFullTo(UnNorm);
    }

    void toHOBSON()
    {
        if(dfType==HOBSON)return;
        swapType();
        dfType=HOBSON;
    }

    void toFERRER()
    {
        if(dfType==FERRER)return;
        swapType();
        dfType=FERRER;
    } 
};
// end legendre_order_one_theta

class legendre_order_multi_theta
{
  friend class legendre;

  public:
         
    enum nmTypes{CplxFull,RealFull,CplxSemi,RealSemi,UnNorm};
    enum dfTypes{FERRER,HOBSON};
    
    nmTypes nmType;
    dfTypes dfType;
  	  
  private:

	
  	int ntl,nth,lt;

  	int L;
  	int m;
  	
   	double **ptl;
  	double *data_;	 
	
	void create(int order, int maxDeg)
	{
  		m=order;  		
  		L=maxDeg;
  		lt=0;
	}
  	
  	void destroy()
  	{
  		if(lt<=0||L==-1)return;
  		delete[](ptl+ntl);
  		delete[](data_+m);
    }

    void convFromCplxFullTo(nmTypes nm)
    {
        int i,k,n;
        double coef,tmp;
				    
        switch(nm)
        {
            case CplxFull:
                 
                break;

            case RealFull:

				if(m!=0)
				{
					coef=sqrt(2.0);
                	for(i=ntl;i<=nth;i++)for(n=m;n<=L;n++)ptl[i][n]*=coef;
				}

                break;
                
            case CplxSemi:
            	
            	for(n=m;n<=L;n++)
				{
					coef=sqrt(1.0/(2.0*n+1.0));
					for(i=ntl;i<=nth;i++)ptl[i][n]*=coef;
				}
            	
            	break;
                
            case RealSemi:
            	
 				if(m!=0)
				{
				 	for(n=m;n<=L;n++)
					 {
					 	coef=sqrt(2.0/(2.0*n+1.0));
					 	for(i=ntl;i<=nth;i++)ptl[i][n]*=coef;
					 }
				}
				else
				{
					for(n=m;n<=L;n++)
					{
						coef=sqrt(1.0/(2.0*n+1.0));
						for(i=ntl;i<=nth;i++)ptl[i][n]*=coef;
					}
				}
				
                break;
                
            case UnNorm:

                for(n=m;n<=L;n++)
                {
                    coef=sqrt(1.0/(2.0*n+1.0)); 
					for(k=1;k<=m;k++)coef*=sqrt((n-k+1.0)*(n+k));
					for(i=ntl;i<=nth;i++)ptl[i][n]*=coef;  
                } 
                
                break;
        }
                
        nmType=nm;  
    }

    void convToCplxFull()
    {
        int i,n,k;
        double tmp,coef0,coef;
				          
        switch(nmType)
        {
            case CplxFull:
                 
                break;

            case RealFull:
                
                if(m!=0)
				{
					coef=1.0/sqrt(2.0);
					for(i=ntl;i<=nth;i++)for(n=m;n<=L;n++)ptl[i][n]*=coef;
				}

                break;
                
            case CplxSemi:

				for(n=m;n<=L;n++)
				{
					coef=sqrt(2.0*n+1.0);
					for(i=ntl;i<=nth;i++)ptl[i][n]*=coef;	
				}

                break;

            case RealSemi:

                if(m!=0)
                {
                	for(n=m;n<=L;n++)
					{
						coef=sqrt((2.0*n+1.0)/2.0);
						for(i=ntl;i<=nth;i++)ptl[i][n]*=coef;
					}
                }
                else 
				{
					for(n=m;n<=L;n++)
					{
						coef=sqrt(2.0*n+1.0);
						for(i=ntl;i<=nth;i++)ptl[i][n]*=coef;	
					}
				}

                break;
                
            case UnNorm:
                
                for(n=m;n<=L;n++)
                {
                	coef=sqrt(2.0*n+1.0);
                    for(k=1;k<=m;k++)coef/=sqrt((n-k+1.0)*(n+k)); 
					for(i=ntl;i<=nth;i++)ptl[i][n]*=coef;              	
				}
				
                break;
        }

        nmType=CplxFull;  
    }

    void swapType()
    {
        int i,n;
        if(m%2==1)for(i=ntl;i<=nth;i++)for(n=m;n<=L;n++)ptl[i][n]=-ptl[i][n];     
    }
    
  public:
  	
  	void initialize(vec<double>& theta)
  	{
  		ntl=theta.lower_index();
  		nth=theta.higher_index();
  		lt=theta.size();
  		
  		if(lt<=0||L==-1)return;
  		
 		int dim;
  	
  		dim=L-m+1;
  		
  		ptl=new(std::nothrow) double*[lt];
        check_error(ptl==NULL,"Not enough memory");
        ptl-=ntl;
        
  		data_=new(std::nothrow) double[dim*lt];
        check_error(data_==NULL,"Not enough memory");
        data_-=m;

        ptl[ntl]=data_;
        for(int i=ntl+1;i<=nth;i++)ptl[i]=ptl[i-1]+dim;
  	}
  	
    explicit legendre_order_multi_theta(int order=0, int maxDeg=-1,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
    	nmType=nm;
        dfType=df;
    	create(order,maxDeg);
    } 	
  	
    explicit legendre_order_multi_theta(vec<double>& theta, 
								int order=0, int maxDeg=-1,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
    	nmType=nm;
        dfType=df;
    	create(order,maxDeg);
    	initialize(theta);
    }
    
    ~legendre_order_multi_theta()
    {
		destroy();
	}
    
    int maxDeg()
    {
    	return L;
    }
    
    int order()
    {
    	return m;
    }    
    
    void resize(int order=0, int maxDeg=0)
    {
        destroy();
        create(order,maxDeg);
    }
    
    void reset(vec<double>& t, int order=0, int maxDeg=0,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
    	nmType=nm;
        dfType=df;
        destroy();
        create(order,maxDeg);
        initialize(t);
    }

    double* operator[](int i)
    {
        return ptl[i];
    }

    double* operator[](int i) const
    {
        return ptl[i];
    }
    
    void setNormType(nmTypes nm)
    {
        nmType=nm;
    }
 
    void setDefType(dfTypes df)
    {
        dfType=df;
    }   
    
    void toCplxFull()
    {
        convToCplxFull();
    }

    void toRealFull()
    {
        convToCplxFull();
        convFromCplxFullTo(RealFull);
    }

    void toCplxSemi()
    {
        convToCplxFull();
        convFromCplxFullTo(CplxSemi);
    }

    void toRealSemi()
    {
        convToCplxFull();
        convFromCplxFullTo(RealSemi);
    }

    void toUnNorm()
    {
        convToCplxFull();
        convFromCplxFullTo(UnNorm);
    }

    void toHOBSON()
    {
        if(dfType==HOBSON)return;
        swapType();
        dfType=HOBSON;
    }

    void toFERRER()
    {
        if(dfType==FERRER)return;
        swapType();
        dfType=FERRER;
    } 	
};

class legendre_one_theta
{
  friend class legendre;

  public:
         
    enum nmTypes{CplxFull,RealFull,CplxSemi,RealSemi,UnNorm};
    enum dfTypes{FERRER,HOBSON};
    
    nmTypes nmType;
    dfTypes dfType;
  	    
  private:

  	int L;
  	
  	double **pml;
  	double *data;
  	int dim;

  	void initialize(int maxDeg)
  	{
    	L=maxDeg;
  		
  		if(L==-1)return;
  				
        int m;  //Legendre function is odered in [order][degree]

        dim=(L+1)*(L+2)/2;

        data=new(std::nothrow) double[dim];
        check_error(data==NULL,"Not enough memory");
         
        pml=new(std::nothrow) double*[L+1];
        check_error(pml==NULL,"Not enough memory");
                  
        pml[0]=data;
        for(m=1;m<=L;m++)
		{
			pml[m] =pml[m-1] +(L-m+2); //L-(m-1)+1
		}
		for(m=1;m<=L;m++)
		{
		 	pml[m] -=m;
		}
  	}
  	
  	void destroy()
  	{
  		if(L!=-1)
		{
		  	delete[]pml;
		  	delete[]data;
		}
    }
    
    void convFromCplxFullTo(nmTypes nm)
    {
        int k,n;
        double coef,tmp;
				          
        switch(nm)
        {
            case CplxFull:
                 
                break;

            case RealFull:

                coef=sqrt(2.0);
                for(n=0;n<=L;n++)
                {
                    for(k=1;k<=n;k++)pml[k][n]*=coef;
                } 

                break;
            
            case CplxSemi:
            	                  
                for(n=0;n<=L;n++)
                {
                	coef=sqrt(1.0/(2.0*n+1.0));
                    pml[0][n]*=coef;                	
                    for(k=1;k<=n;k++)pml[k][n]*=coef;
                } 
                
                break;
                
            case RealSemi:
            	                  
                for(n=0;n<=L;n++)
                {
                	coef=sqrt(2.0/(2.0*n+1.0));
                    pml[0][n]*=coef/sqrt(2.0);                	
                    for(k=1;k<=n;k++)pml[k][n]*=coef;
                } 
                
                break;
                
            case UnNorm:

                for(n=0;n<=L;n++)
                {
                    coef=sqrt(1.0/(2.0*n+1.0));
                    pml[0][n]*=coef;
                    tmp=1.0;
                    for(k=1;k<=n;k++)
                    {
                        tmp*=sqrt((n-k+1.0)*(n+k));
                        pml[k][n]*=coef*tmp;
                    }
                } 
                
                break;
        }
                
        nmType=nm;  
    }

    void convToCplxFull()
    {
        int k,n;
        double tmp,coef;
				              
        switch(nmType)
        {
            case CplxFull:
                 
                break;

            case RealFull:
                 
                coef=1.0/sqrt(2.0);
                for(n=0;n<=L;n++)
                {
                    for(k=1;k<=n;k++)pml[k][n]*=coef;
                }         
                 
                break;
                
            case CplxSemi:
                
                for(n=0;n<=L;n++)
                {
                    coef=sqrt(2.0*n+1.0);
                    pml[0][n]*=coef;
                    for(k=1;k<=n;k++)pml[k][n]*=coef;
                } 
                
                break;

            case RealSemi:
                
                for(n=0;n<=L;n++)
                {
                    coef=sqrt((2.0*n+1.0)/2.0);
                    pml[0][n]*=coef*sqrt(2.0);
                    for(k=1;k<=n;k++)pml[k][n]*=coef;
                } 
                
                break;
                
            case UnNorm:
                
                for(n=0;n<=L;n++)
                {
                	coef=sqrt(2.0*n+1.0);
                    pml[0][n]*=coef;
                    tmp=1.0;
                    for(k=1;k<=n;k++)
                    {
                        tmp/=sqrt((n-k+1.0)*(n+k));
                        pml[k][n]*=coef*tmp;
                    }
                } 
            
                break;
        }

        nmType=CplxFull;  
    }

    void swapType()
    {
        int k,n;
        for(k=0;k<=L;k++)if(k%2==1)
        {
        	for(n=k;n<=L;n++)pml[k][n]=-pml[k][n];
    	}
    }
	    
  public:
  	
    explicit legendre_one_theta(int maxDeg=-1,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
    	nmType=nm;
        dfType=df;
    	initialize(maxDeg);
    }
    
    ~legendre_one_theta()
    {
		destroy();
	}
    
    void reset(int maxDeg=-1,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
    	nmType=nm;
        dfType=df;
        if(L!=maxDeg)
        {
            destroy();
            initialize(maxDeg);
        }
    }

    int maxDeg()
    {
    	return L;
    }
    
    double* operator[](int i)
    {
        return pml[i];
    }

    double* operator[](int i) const
    {
        return pml[i];
    }
	
    void setNormType(nmTypes nm)
    {
        nmType=nm;
    }
 
    void setDefType(dfTypes df)
    {
        dfType=df;
    }   
    
    void toCplxFull()
    {
        convToCplxFull();
    }

    void toRealFull()
    {
        convToCplxFull();
        convFromCplxFullTo(RealFull);
    }
    
    
    void toCplxSemi()
    {
        convToCplxFull();
        convFromCplxFullTo(CplxSemi);
    }

    void toRealSemi()
    {
        convToCplxFull();
        convFromCplxFullTo(RealSemi);
    }

    void toUnNorm()
    {
        convToCplxFull();
        convFromCplxFullTo(UnNorm);
    }

    void toHOBSON()
    {
        if(dfType==HOBSON)return;
        swapType();
        dfType=HOBSON;
    }

    void toFERRER()
    {
        if(dfType==FERRER)return;
        swapType();
        dfType=FERRER;
    } 		
};

class legendre_multi_theta
{
  friend class legendre;

  public:
         
    enum nmTypes{CplxFull,RealFull,CplxSemi,RealSemi,UnNorm};
    enum dfTypes{FERRER,HOBSON};
    
    nmTypes nmType;
    dfTypes dfType;
    
  private:

  	int ntl,nth,lt;

  	int L;
  	
  	int dimm;
  	int dimp;
  	
  	double ***ptml;
  	double **pt;
  	double *data;	
	  
	void create(int maxDeg)
	{
		L=maxDeg;
		lt=0;	
	}
  	
  	void destroy()
  	{
  		if(lt<=0||L==-1)return;
  		delete[](ptml+ntl);
  		delete[]pt;
  		delete[]data;
    }
    
    void convFromCplxFullTo(nmTypes nm)
    {
        int i,k,n;
        double coef,coef0,tmp;
				          
        switch(nm)
        {
            case CplxFull:
                 
                break;

            case RealFull:

                coef=sqrt(2.0);
                for(i=ntl;i<=nth;i++)
                for(n=0;n<=L;n++)
                {
                    for(k=1;k<=n;k++)ptml[i][k][n]*=coef;
                } 

                break;
                
            case CplxSemi:
            	                  
                for(n=0;n<=L;n++)
                {
                	coef=sqrt(1.0/(2.0*n+1.0));
                	for(i=ntl;i<=nth;i++)
                	{
                    	ptml[i][0][n]*=coef;                	
                    	for(k=1;k<=n;k++)ptml[i][k][n]*=coef;
                	}
                } 
                
                break;
                
            case RealSemi:
            	                  
                for(n=0;n<=L;n++)
                {
                	coef=sqrt(2.0/(2.0*n+1.0));
                	coef0=coef/sqrt(2.0);
                	for(i=ntl;i<=nth;i++)
                	{
                    	ptml[i][0][n]*=coef0;                	
                    	for(k=1;k<=n;k++)ptml[i][k][n]*=coef;
                	}
                } 
                
                break;
                
            case UnNorm:

                for(n=0;n<=L;n++)
                {
                    coef0=sqrt(1.0/(2.0*n+1.0));
                    for(i=ntl;i<=nth;i++)ptml[i][0][n]*=coef0;
                    tmp=1.0;
                    for(k=1;k<=n;k++)
                    {
                        tmp*=sqrt((n-k+1.0)*(n+k));
                        coef=coef0*tmp;
                        for(i=ntl;i<=nth;i++)ptml[i][k][n]*=coef;
                    }
                } 
                
                break;
        }
                
        nmType=nm;  
    }

    void convToCplxFull()
    {
        int i,k,n;
        double tmp,coef0,coef;
				              
        switch(nmType)
        {
            case CplxFull:
                 
                break;

            case RealFull:
                 
                coef=1.0/sqrt(2.0);
                for(i=ntl;i<=nth;i++)
                for(n=0;n<=L;n++)
                {
                    for(k=1;k<=n;k++)ptml[i][k][n]*=coef;
                }         
                 
                break;
                
            case CplxSemi:
                
                for(n=0;n<=L;n++)
                {
                    coef=sqrt((2.0*n+1.0)/1.0);
                    for(i=ntl;i<=nth;i++)
                    {
                    	ptml[i][0][n]*=coef;
                    	for(k=1;k<=n;k++)ptml[i][k][n]*=coef;
                	}
                } 
                
                break;
                
            case RealSemi:
                
                for(n=0;n<=L;n++)
                {
                    coef=sqrt((2.0*n+1.0)/2.0);
                    coef0=coef*sqrt(2.0);
                    for(i=ntl;i<=nth;i++)
                    {
                    	ptml[i][0][n]*=coef0;
                    	for(k=1;k<=n;k++)ptml[i][k][n]*=coef;
                	}
                } 
                
                break;
                
            case UnNorm:
                
                for(n=0;n<=L;n++)
                {
                	coef0=sqrt((2.0*n+1.0)/1.0);
                    for(i=ntl;i<=nth;i++)ptml[i][0][n]*=coef0;
                    tmp=1.0;
                    for(k=1;k<=n;k++)
                    {
                        tmp/=sqrt((n-k+1.0)*(n+k));
                        coef=coef0*tmp;
                        for(i=ntl;i<=nth;i++)ptml[i][k][n]*=coef;
                    }
                } 
            
                break;
        }

        nmType=CplxFull;  
    }

    void swapType()
    {
        int i,k,n;
        for(k=0;k<=L;k++)if(k%2==1)
        {
        	for(n=k;n<=L;n++)for(i=ntl;i<=nth;i++)ptml[i][k][n]=-ptml[i][k][n];
    	}
    }
	    
  public:

	void initialize(vec<double>& theta)
	{
		ntl=theta.lower_index();
		nth=theta.higher_index();
		lt=theta.size();
		
		if(lt<=0||L==-1)return;
	
		ptml=new(std::nothrow) double**[lt];
	    check_error(ptml==NULL,"Not enough memory");
	    ptml-=ntl;
	    
	    dimm=L+1;
	    pt=new(std::nothrow) double*[lt*dimm];
	    check_error(ptml==NULL,"Not enough memory");
	    ptml[ntl]=pt;
	    
	    dimp=(L+1)*(L+2)/2;
		data=new(std::nothrow) double[lt*dimp];
	    check_error(data==NULL,"Not enough memory");
	
		ptml[ntl][0]=data;
	
		int i,m;
		
		for(m=1;m<=L;m++)ptml[ntl][m]=ptml[ntl][m-1]+(L-m+2); //L-(m-1)+1
	
		for(i=ntl+1;i<=nth;i++)
		{
			ptml[i]=ptml[i-1]+dimm;
			ptml[i][0]=ptml[i-1][0]+dimp;
			for(m=1;m<=L;m++)
			{
				ptml[i][m]=ptml[i][m-1]+(L-m+2); //L-(m-1)+1
			}
		}
	
		for(i=ntl;i<=nth;i++)
	    for(m=0;m<=L;m++)
	    {
	    	ptml[i][m]-=m;
		}
	}  	
  	
    explicit legendre_multi_theta(int maxDeg=0,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
    	nmType=nm;
        dfType=df;
    	create(maxDeg);
    }
    
    explicit legendre_multi_theta(vec<double>& theta, int maxDeg=0,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
    	nmType=nm;
        dfType=df;
    	create(maxDeg);
    	initialize(theta);
    }
    
    ~legendre_multi_theta()
    {
		destroy();
	}
    
    int maxDeg()
    {
    	return L;
    }
    
    int lower_theta_index()
    {
    	return ntl;
    }
    
    int higher_theta_index()
    {
    	return nth;
    }
    
    int num_theta()
    {
    	return lt;
    }

    void reset(vec<double>& t, int maxDeg=0,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
    	nmType=nm;
        dfType=df;
        destroy();
        create(maxDeg);
        initialize(t);
    }

    double** operator[](int i)
    {
        return ptml[i];
    }

    double** operator[](int i) const
    {
        return ptml[i];
    }
	
    void setNormType(nmTypes nm)
    {
        nmType=nm;
    }
 
    void setDefType(dfTypes df)
    {
        dfType=df;
    }   
    
    void toCplxFull()
    {
        convToCplxFull();
    }

    void toRealFull()
    {
        convToCplxFull();
        convFromCplxFullTo(RealFull);
    }

    void toCplxSemi()
    {
        convToCplxFull();
        convFromCplxFullTo(CplxSemi);
    }

    void toRealSemi()
    {
        convToCplxFull();
        convFromCplxFullTo(RealSemi);
    }

    void toUnNorm()
    {
        convToCplxFull();
        convFromCplxFullTo(UnNorm);
    }

    void toHOBSON()
    {
        if(dfType==HOBSON)return;
        swapType();
        dfType=HOBSON;
    }

    void toFERRER()
    {
        if(dfType==FERRER)return;
        swapType();
        dfType=FERRER;
    } 			
};

class legendre
{
  private:

    int L;  //maxmum degree
    
    mat<double> ps;
    mat<int>ips;
    bool is_one_theta;
    bool is_pmm;
	
	// prepr
	
	double *r;
	double *ri;
	double *d;
	
	// prepab
	
	double **aml;
	double **bml;
	
	double *daml;
	double *dbml;
	
	// parameters
	
	int IND;
	double BIG;
	double BIGI;
	double BIGS;
	double BIGSI;
	double ROOT3;
	
	// added parameters

	double P00;
	
	// tmp variables
	
	int itmp;
	double dtmp;
	
	// added for computing derivatives
	
	double **cml;
	double **dml;
		
	double *dcml;
	double *ddml;
	
	double *dd;
	double *ddinv;
	double *msqr;
	double *ddsqrt;

	void initialize(int maxDeg)
    {
        L=maxDeg;
   	
        if(L==-1)return;

		int i,m,l;
		
		// prepr

		itmp=2*L+3+1;
		
		r=new(std::nothrow) double[itmp];
        check_error(r==NULL,"Not enough memory");
        
		ri=new(std::nothrow) double[itmp];
        check_error(ri==NULL,"Not enough memory");
        
        r[0]=0.0;
        ri[0]=0.0;
 		for(i=1;i<itmp;i++)
		{
			dtmp=sqrt((double)(i));
			r[i]=dtmp;
			ri[i]=1.0/dtmp;
		}
        
		d=new(std::nothrow) double[L];
        check_error(d==NULL,"Not enough memory");

        for(m=0;m<L;m++)
        {
        	d[m]=r[2*m+3]*ri[2*m+2];
        }
     
        // prepab

		itmp=(L+1)*(L+2)/2;
		
		daml=new(std::nothrow) double[itmp];
        check_error(daml==NULL,"Not enough memory");

		dbml=new(std::nothrow) double[itmp];
        check_error(dbml==NULL,"Not enough memory");

		aml=new(std::nothrow) double*[L+1];
        check_error(aml==NULL,"Not enough memory");

		bml=new(std::nothrow) double*[L+1];
        check_error(bml==NULL,"Not enough memory");

		aml[0]=daml;
		bml[0]=dbml;

        for(m=1;m<=L;m++)
		{
			aml[m] =aml[m-1] +(L-m+2); //L-(m-1)+1
			bml[m] =bml[m-1] +(L-m+2); //L-(m-1)+1
		}

		for(m=1;m<=L;m++)
		{
		 	aml[m] -=m;
		 	bml[m] -=m;
		}

		for(m=0;m<L;m++)
		{
			aml[m][m+1]=r[2*m+3];
		}
		for(m=0;m<=L;m++)
		for(l=m+2;l<=L;l++)
		{
			dtmp=r[2*l+1]*ri[l-m]*ri[l+m];
			aml[m][l]=r[2*l-1]*dtmp;
			bml[m][l]=r[l-m-1]*r[l+m-1]*ri[2*l-3]*dtmp;
		}

		// parameters

		IND=960;
		BIG=pow(2.0,IND);
		BIGI=pow(2.0,-IND);
		BIGS=pow(2.0,IND/2);
		BIGSI=pow(2.0,-IND/2);

		ROOT3=sqrt(3.0);

//		double PI=4.0*atan(1.0);		
//		P00=1.0/sqrt(4.0*PI);
		P00=1.0;  //modified: change of definition

		is_pmm=false;
		
		// added for computing derivatives
		
		itmp=(L+1)*(L+2)/2;
		
		dcml=new(std::nothrow) double[itmp];
        check_error(dcml==NULL,"Not enough memory");

		ddml=new(std::nothrow) double[itmp];
        check_error(ddml==NULL,"Not enough memory");

		cml=new(std::nothrow) double*[L+1];
        check_error(cml==NULL,"Not enough memory");

		dml=new(std::nothrow) double*[L+1];
        check_error(dml==NULL,"Not enough memory");

		cml[0]=dcml;
		dml[0]=ddml;
		
        for(m=1;m<=L;m++)
		{
			cml[m] =cml[m-1] +(L-m+2); //L-(m-1)+1
			dml[m] =dml[m-1] +(L-m+2); //L-(m-1)+1
		}
		for(m=0;m<=L;m++)
		{
		 	cml[m] -=m;
		 	dml[m] -=m;
		}

		dd=new(std::nothrow) double[L+1];
        check_error(dd==NULL,"Not enough memory");	
			
		ddinv=new(std::nothrow) double[L+1];
        check_error(ddinv==NULL,"Not enough memory");	
        
        msqr=new(std::nothrow) double[L+1];
        check_error(msqr==NULL,"Not enough memory");
				
		ddsqrt=new(std::nothrow) double[L+1];
        check_error(ddsqrt==NULL,"Not enough memory");
		
		dd[0]=0.0;
		msqr[0]=0.0;
		for(l=1;l<=L;l++)
		{
			dtmp=1.0*l*l;
			msqr[l]=dtmp;
			dtmp+=l;			
			dd[l]=dtmp;
			ddinv[l]=1.0/dtmp;
			ddsqrt[l]=sqrt(dtmp);
		}
	
		for(m=0;m<=L;m++)
		for(l=m;l<=L;l++)
		{
			cml[m][l]=r[2*l+1]*r[l-m]*r[l+m]*ri[2*l-1];
			dml[m][l]=r[l+m]*r[l-m+1]*0.5;
		}
  	}

    void destroy()
    {
    	if(L==-1)return;
    	
		delete[]r;
		delete[]ri;
		delete[]d;

		delete[]daml;
		delete[]dbml;
		
		delete[]aml;
		delete[]bml;
		
		delete[]dcml;
		delete[]ddml;
				
		delete[]cml;
		delete[]dml;

        delete[]dd;  
		delete[]ddinv;
		delete[]msqr;  
		delete[]ddsqrt;
	}
    
  public:
  	
  	explicit legendre(int maxDeg=-1)
  	{
  		initialize(maxDeg);
  	}
    
    ~legendre()
    {
    	destroy();
    }
    
    int maxDeg()
    {
    	return L;
    }
    
    void resize(int maxDeg=-1)
    {
    	destroy();
    	initialize(maxDeg);
    }
    
	void evaluate_pmm(trig_one_theta &t)
	{
		ps.resize(1,L+1);
		ips.resize(1,L+1);
		
		double x,y;
		int ix;
		
		ix=0;
		ips[0][0]=ix;
				
		x=P00;		
		ps[0][0]=x;

		for(int m=1;m<=L;m++)
		{
			x*=d[m-1]*t.s;
			y=fabs(x);
			if(y>=BIGS)
			{
				x=x*BIGI;
				ix++;
			}
			else if(y<BIGSI)
			{
				x*BIG;
				ix--;
			}
			ps[0][m]=x;
			ips[0][m]=ix;
		}
		is_one_theta=true;
		is_pmm=true;
	}

	void evaluate_pmm(trig_multi_theta &t)
	{
		ps.resize(t.nl,t.nh,0,L);
		ips.resize(t.nl,t.nh,0,L);
		
		double x,y;
		int ix;
		
		int i,m;
		
		for(i=t.nl;i<=t.nh;i++)
		{
			ix=0;
			ips[i][0]=ix;
					
			x=P00;		
			ps[i][0]=x;

			for(int m=1;m<=L;m++)
			{
				x*=d[m-1]*t.s[i];
				y=fabs(x);
				if(y>=BIGS)
				{
					x*=BIGI;
					ix++;
				}
				else if(y<BIGSI)
				{
					x*=BIG;
					ix--;
				}
				ps[i][m]=x;
				ips[i][m]=ix;
			}
		}
		is_one_theta=false;
		is_pmm=true;
	}	

    void evaluate(legendre_order_one_theta &pl, trig_one_theta &t)
    {
    	check_error(pl.nmType!=legendre_order_one_theta::CplxFull, "Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_one_theta::FERRER, "Definition type must be FERRER for evaluation");

    	check_error(pl.maxDeg()!=L, "Degree mismatch");
    	check_error(is_pmm==false, "Pmm not yet evaluated");
    	check_error(is_one_theta==false, "Pmm is for multiple theta values");
    	
    	int m,ipsm,ix,iy,l,id,iz;
    	double psm,x,y,w,z;
    	
    	m=pl.order();
    	x=ps[0][m];
    	ix=ips[0][m];
    	
    	if(ix==0)
		{
			pl[m]=x;
		}
		else if(ix<-1)
		{
			pl[m]=0;
		}
		else if(ix<0)
		{
			pl[m]=x*BIGI;
		}
		else
		{
			pl[m]=x*BIG;
		}
		if(m==L)return;
		
		y=x;
		iy=ix;
		x=aml[m][m+1]*t.c*y;
		ix=iy;
		w=abs(x);
		
		if(w>=BIGS)
		{
			x*=BIGI;
			ix++;
		}
		else if(w<BIGSI)
		{
			x*=BIG;
			ix--;
		}
		
		if(ix==0)
		{
			pl[m+1]=x;
		}
		else if(ix<-1)
		{
			pl[m+1]=0.0;
		}
		else if(ix<0)
		{
			pl[m+1]=x*BIGI;
		}
		else
		{
			pl[m+1]=x*BIG;
		}
		if(m==L-1)return;
		
		for(l=m+2;l<=L;l++)
		{
			id=ix-iy;
			if(id==0)
			{
				z=aml[m][l]*t.c*x-bml[m][l]*y;
				iz=ix;
			}
			else if(id==1)
			{
				z=aml[m][l]*t.c*x-bml[m][l]*y*BIGI;
				iz=ix;				
			}
			else if(id==-1)
			{
				z=aml[m][l]*t.c*x*BIGI-bml[m][l]*y;
				iz=iy;					
			}
			else if(id>1)
			{
				z=aml[m][l]*t.c*x;
				iz=ix;				
			}
			else 
			{
				z=-bml[m][l]*y;
				iz=iy;
			}
			
			w=abs(z);
			if(w>=BIGS)
			{
				z*=BIGI;
				iz++;
			}
			else if(w<BIGSI)
			{
				z*=BIG;
				iz--;
			}
			else
			{
				check_error(false, "Error if this happen");
			}
			
			if(iz==0)
			{
				pl[l]=z;
			}
			else if(iz<-1)
			{
				pl[l]=0;				
			}
			else if(iz<0)
			{
				pl[l]=z*BIGI;			
			}
			else
			{
				pl[l]=z*BIG;				
			}
			y=x;
			iy=ix;
			x=z;
			ix=iz;			
		}
    }

    void evaluate(legendre_order_multi_theta &ptl, trig_multi_theta &t)
    {
    	check_error(ptl.nmType!=legendre_order_multi_theta::CplxFull, "Normalization type must be CplxFull for evaluation");
		check_error(ptl.dfType!=legendre_order_multi_theta::FERRER, "Definition type must be FERRER for evaluation");
    	
    	check_error(ptl.maxDeg()!=L, "Degree mismatch");
    	check_error(is_pmm==false, "Pmm not yet evaluated");
    	check_error(is_one_theta==true, "Pmm is for only one theta value");
    	
    	int m,ipsm,ix,iy,l,id,iz;
    	double psm,x,y,w,z;
    	
    	m=ptl.order();
    	
    	int i_low=ptl.ntl;
    	int i_high=ptl.nth;
    	
    	for(int i=i_low;i<=i_high;i++)
    	{
	    	x=ps[i][m];
	    	ix=ips[i][m];
	    	
	    	if(ix==0)
			{
				ptl[i][m]=x;
			}
			else if(ix<-1)
			{
				ptl[i][m]=0;
			}
			else if(ix<0)
			{
				ptl[i][m]=x*BIGI;
			}
			else
			{
				ptl[i][m]=x*BIG;
			}
			if(m==L)continue;
			
			y=x;
			iy=ix;
			x=aml[m][m+1]*t.c[i]*y;
			ix=iy;
			w=abs(x);
			
			if(w>=BIGS)
			{
				x*=BIGI;
				ix++;
			}
			else if(w<BIGSI)
			{
				x*=BIG;
				ix--;
			}
			
			if(ix==0)
			{
				ptl[i][m+1]=x;
			}
			else if(ix<-1)
			{
				ptl[i][m+1]=0.0;
			}
			else if(ix<0)
			{
				ptl[i][m+1]=x*BIGI;
			}
			else
			{
				ptl[i][m+1]=x*BIG;
			}
			if(m==L-1)continue;
		
			for(l=m+2;l<=L;l++)
			{
				id=ix-iy;
				if(id==0)
				{
					z=aml[m][l]*t.c[i]*x-bml[m][l]*y;
					iz=ix;
				}
				else if(id==1)
				{
					z=aml[m][l]*t.c[i]*x-bml[m][l]*y*BIGI;
					iz=ix;				
				}
				else if(id==-1)
				{
					z=aml[m][l]*t.c[i]*x*BIGI-bml[m][l]*y;
					iz=iy;					
				}
				else if(id>1)
				{
					z=aml[m][l]*t.c[i]*x;
					iz=ix;				
				}
				else 
				{
					z=-bml[m][l]*y;
					iz=iy;
				}
				
				w=abs(z);
				if(w>=BIGS)
				{
					z*=BIGI;
					iz++;
				}
				else if(w<BIGSI)
				{
					z*=BIG;
					iz--;
				}
				else
				{
					check_error(false, "Error if this happen");
				}
				
				if(iz==0)
				{
					ptl[i][l]=z;
				}
				else if(iz<-1)
				{
					ptl[i][l]=0;				
				}
				else if(iz<0)
				{
					ptl[i][l]=z*BIGI;			
				}
				else
				{
					ptl[i][l]=z*BIG;				
				}
				y=x;
				iy=ix;
				x=z;
				ix=iz;	
			} 
		}
    }

    void evaluate(legendre_order_one_theta &pl, trig_multi_theta &t, int i)
    {
    	check_error(pl.nmType!=legendre_order_one_theta::CplxFull, "Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_one_theta::FERRER, "Definition type must be FERRER for evaluation");    	
    	
    	check_error(pl.maxDeg()!=L, "Degree mismatch");
    	check_error(is_pmm==false, "Pmm not yet evaluated");
    	check_error(is_one_theta==true, "Pmm is for only one theta value");
    	
    	int m,ipsm,ix,iy,l,id,iz;
    	double psm,x,y,w,z;
    	
    	m=pl.order();
    	x=ps[i][m];
    	ix=ips[i][m];
    	
    	if(ix==0)
		{
			pl[m]=x;
		}
		else if(ix<-1)
		{
			pl[m]=0;
		}
		else if(ix<0)
		{
			pl[m]=x*BIGI;
		}
		else
		{
			pl[m]=x*BIG;
		}
		if(m==L)return;
		
		y=x;
		iy=ix;
		x=aml[m][m+1]*t.c[i]*y;
		ix=iy;
		w=abs(x);
		
		if(w>=BIGS)
		{
			x*=BIGI;
			ix++;
		}
		else if(w<BIGSI)
		{
			x*=BIG;
			ix--;
		}
		
		if(ix==0)
		{
			pl[m+1]=x;
		}
		else if(ix<-1)
		{
			pl[m+1]=0.0;
		}
		else if(ix<0)
		{
			pl[m+1]=x*BIGI;
		}
		else
		{
			pl[m+1]=x*BIG;
		}
		if(m==L-1)return;
		
		for(l=m+2;l<=L;l++)
		{
			id=ix-iy;
			if(id==0)
			{
				z=aml[m][l]*t.c[i]*x-bml[m][l]*y;
				iz=ix;
			}
			else if(id==1)
			{
				z=aml[m][l]*t.c[i]*x-bml[m][l]*y*BIGI;
				iz=ix;				
			}
			else if(id==-1)
			{
				z=aml[m][l]*t.c[i]*x*BIGI-bml[m][l]*y;
				iz=iy;					
			}
			else if(id>1)
			{
				z=aml[m][l]*t.c[i]*x;
				iz=ix;				
			}
			else 
			{
				z=-bml[m][l]*y;
				iz=iy;
			}
			
			w=abs(z);
			if(w>=BIGS)
			{
				z*=BIGI;
				iz++;
			}
			else if(w<BIGSI)
			{
				z*=BIG;
				iz--;
			}
			else
			{
				check_error(false, "Error if this happen");
			}
			
			if(iz==0)
			{
				pl[l]=z;
			}
			else if(iz<-1)
			{
				pl[l]=0;				
			}
			else if(iz<0)
			{
				pl[l]=z*BIGI;			
			}
			else
			{
				pl[l]=z*BIG;				
			}
			y=x;
			iy=ix;
			x=z;
			ix=iz;			
		}
    }

    void evaluate(legendre_one_theta &pml, trig_one_theta &t)
    {
    	check_error(pml.nmType!=legendre_one_theta::CplxFull, "Normalization type must be CplxFull for evaluation");
		check_error(pml.dfType!=legendre_one_theta::FERRER, "Definition type must be FERRER for evaluation");   
		
    	check_error(pml.maxDeg()!=L, "Degree mismatch");
    	check_error(is_pmm==false, "Pmm not yet evaluated");
    	check_error(is_one_theta==false, "Pmm is for multiple theta values");
    	int l,m,ipsm,ix,iy,id,iz;
    	double psm,x,y,w,z;
    	
    	for(m=0;m<=L;m++)
    	{
	    	x=ps[0][m];
	    	ix=ips[0][m];
	    	
	    	if(ix==0)
			{
				pml[m][m]=x;
			}
			else if(ix<-1)
			{
				pml[m][m]=0;
			}
			else if(ix<0)
			{
				pml[m][m]=x*BIGI;
			}
			else
			{
				pml[m][m]=x*BIG;
			}
			if(m==L)continue;
			
			y=x;
			iy=ix;
			x=aml[m][m+1]*t.c*y;
			ix=iy;
			w=abs(x);
			
			if(w>=BIGS)
			{
				x*=BIGI;
				ix++;
			}
			else if(w<BIGSI)
			{
				x*=BIG;
				ix--;
			}
			
			if(ix==0)
			{
				pml[m][m+1]=x;
			}
			else if(ix<-1)
			{
				pml[m][m+1]=0.0;
			}
			else if(ix<0)
			{
				pml[m][m+1]=x*BIGI;
			}
			else
			{
				pml[m][m+1]=x*BIG;
			}
			if(m==L-1)continue;
			
			for(l=m+2;l<=L;l++)
			{
				id=ix-iy;
				if(id==0)
				{
					z=aml[m][l]*t.c*x-bml[m][l]*y;
					iz=ix;
				}
				else if(id==1)
				{
					z=aml[m][l]*t.c*x-bml[m][l]*y*BIGI;
					iz=ix;				
				}
				else if(id==-1)
				{
					z=aml[m][l]*t.c*x*BIGI-bml[m][l]*y;
					iz=iy;					
				}
				else if(id>1)
				{
					z=aml[m][l]*t.c*x;
					iz=ix;				
				}
				else 
				{
					z=-bml[m][l]*y;
					iz=iy;
				}
				
				w=abs(z);
				if(w>=BIGS)
				{
					z*=BIGI;
					iz++;
				}
				else if(w<BIGSI)
				{
					z*=BIG;
					iz--;
				}
				else
				{
					check_error(false, "Error if this happen");
				}
				
				if(iz==0)
				{
					pml[m][l]=z;
				}
				else if(iz<-1)
				{
					pml[m][l]=0;				
				}
				else if(iz<0)
				{
					pml[m][l]=z*BIGI;			
				}
				else
				{
					pml[m][l]=z*BIG;				
				}
				y=x;
				iy=ix;
				x=z;
				ix=iz;			
			}
		}
    }
    
    void evaluate(legendre_multi_theta &ptml, trig_multi_theta &t)
    {
    	check_error(ptml.nmType!=legendre_multi_theta::CplxFull, "Normalization type must be CplxFull for evaluation");
		check_error(ptml.dfType!=legendre_multi_theta::FERRER, "Definition type must be FERRER for evaluation");  
		
    	check_error(ptml.maxDeg()!=L, "Degree mismatch");
    	check_error(is_pmm==false, "Pmm not yet evaluated");
    	check_error(is_one_theta==true, "Pmm is for only one theta values");
    	
    	int i,l,m,ipsm,ix,iy,id,iz;
    	double psm,x,y,w,z;
    	
    	int i_low=ptml.ntl;
    	int i_high=ptml.nth;
    	check_error(t.len!=ptml.num_theta(),"Size of legendre function and theta mismatch");
  	
    	for(i=i_low;i<=i_high;i++)
    	{
	    	for(m=0;m<=L;m++)
	    	{
		    	x=ps[i][m];
		    	ix=ips[i][m];
		    	
		    	if(ix==0)
				{
					ptml[i][m][m]=x;
				}
				else if(ix<-1)
				{
					ptml[i][m][m]=0;
				}
				else if(ix<0)
				{
					ptml[i][m][m]=x*BIGI;
				}
				else
				{
					ptml[i][m][m]=x*BIG;
				}
				if(m==L)continue;
				
				y=x;
				iy=ix;
				x=aml[m][m+1]*t.c[i]*y;
				ix=iy;
				w=abs(x);
				
				if(w>=BIGS)
				{
					x*=BIGI;
					ix++;
				}
				else if(w<BIGSI)
				{
					x*=BIG;
					ix--;
				}
				
				if(ix==0)
				{
					ptml[i][m][m+1]=x;
				}
				else if(ix<-1)
				{
					ptml[i][m][m+1]=0.0;
				}
				else if(ix<0)
				{
					ptml[i][m][m+1]=x*BIGI;
				}
				else
				{
					ptml[i][m][m+1]=x*BIG;
				}
				if(m==L-1)continue;
				
				for(l=m+2;l<=L;l++)
				{
					id=ix-iy;
					if(id==0)
					{
						z=aml[m][l]*t.c[i]*x-bml[m][l]*y;
						iz=ix;
					}
					else if(id==1)
					{
						z=aml[m][l]*t.c[i]*x-bml[m][l]*y*BIGI;
						iz=ix;				
					}
					else if(id==-1)
					{
						z=aml[m][l]*t.c[i]*x*BIGI-bml[m][l]*y;
						iz=iy;					
					}
					else if(id>1)
					{
						z=aml[m][l]*t.c[i]*x;
						iz=ix;				
					}
					else 
					{
						z=-bml[m][l]*y;
						iz=iy;
					}
					
					w=abs(z);
					if(w>=BIGS)
					{
						z*=BIGI;
						iz++;
					}
					else if(w<BIGSI)
					{
						z*=BIG;
						iz--;
					}
					else
					{
						check_error(false, "Error if this happen");
					}
					
					if(iz==0)
					{
						ptml[i][m][l]=z;
					}
					else if(iz<-1)
					{
						ptml[i][m][l]=0;				
					}
					else if(iz<0)
					{
						ptml[i][m][l]=z*BIGI;			
					}
					else
					{
						ptml[i][m][l]=z*BIG;				
					}
					y=x;
					iy=ix;
					x=z;
					ix=iz;			
				}
			} 
		}
    }

    void evaluate(legendre_one_theta &pml, trig_multi_theta &t, int i)
    {
    	check_error(pml.nmType!=legendre_one_theta::CplxFull, "Normalization type must be CplxFull for evaluation");
		check_error(pml.dfType!=legendre_one_theta::FERRER, "Definition type must be FERRER for evaluation");  
		
    	check_error(pml.maxDeg()!=L, "Degree mismatch");
    	check_error(is_pmm==false, "Pmm not yet evaluated");
    	check_error(is_one_theta==true, "Pmm is for single theta values");
    	int l,m,ipsm,ix,iy,id,iz;
    	double psm,x,y,w,z;
    	
    	for(m=0;m<=L;m++)
    	{
	    	x=ps[i][m];
	    	ix=ips[i][m];
	    	
	    	if(ix==0)
			{
				pml[m][m]=x;
			}
			else if(ix<-1)
			{
				pml[m][m]=0;
			}
			else if(ix<0)
			{
				pml[m][m]=x*BIGI;
			}
			else
			{
				pml[m][m]=x*BIG;
			}
			if(m==L)continue;
			
			y=x;
			iy=ix;
			x=aml[m][m+1]*t.c[i]*y;
			ix=iy;
			w=abs(x);
			
			if(w>=BIGS)
			{
				x*=BIGI;
				ix++;
			}
			else if(w<BIGSI)
			{
				x*=BIG;
				ix--;
			}
			
			if(ix==0)
			{
				pml[m][m+1]=x;
			}
			else if(ix<-1)
			{
				pml[m][m+1]=0.0;
			}
			else if(ix<0)
			{
				pml[m][m+1]=x*BIGI;
			}
			else
			{
				pml[m][m+1]=x*BIG;
			}
			if(m==L-1)continue;
			
			for(l=m+2;l<=L;l++)
			{
				id=ix-iy;
				if(id==0)
				{
					z=aml[m][l]*t.c[i]*x-bml[m][l]*y;
					iz=ix;
				}
				else if(id==1)
				{
					z=aml[m][l]*t.c[i]*x-bml[m][l]*y*BIGI;
					iz=ix;				
				}
				else if(id==-1)
				{
					z=aml[m][l]*t.c[i]*x*BIGI-bml[m][l]*y;
					iz=iy;					
				}
				else if(id>1)
				{
					z=aml[m][l]*t.c[i]*x;
					iz=ix;				
				}
				else 
				{
					z=-bml[m][l]*y;
					iz=iy;
				}
				
				w=abs(z);
				if(w>=BIGS)
				{
					z*=BIGI;
					iz++;
				}
				else if(w<BIGSI)
				{
					z*=BIG;
					iz--;
				}
				else
				{
					check_error(false, "Error if this happen");
				}
				
				if(iz==0)
				{
					pml[m][l]=z;
				}
				else if(iz<-1)
				{
					pml[m][l]=0;				
				}
				else if(iz<0)
				{
					pml[m][l]=z*BIGI;			
				}
				else
				{
					pml[m][l]=z*BIG;				
				}
				y=x;
				iy=ix;
				x=z;
				ix=iz;			
			}
		}
    }
    
	void evaluate_1stDiv(legendre_order_one_theta &pl_1stDiv, 
							legendre_order_one_theta &pl, trig_one_theta &t)
    {
    	check_error(pl.nmType!=legendre_order_one_theta::CplxFull||pl.nmType!=pl_1stDiv.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_one_theta::FERRER||pl.dfType!=pl_1stDiv.dfType, 
			"Definition type must be FERRER for evaluation");  
		
    	check_error(pl.maxDeg()!=L||pl_1stDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl.order()!=pl_1stDiv.order(), "Order mismatch");
    	
    	int l,m;
    	m=pl.order();
    	
    	pl_1stDiv[m]=m*t.ct*pl[m];	
    	
    	for(l=m+1;l<=L;l++)
    	{
    		pl_1stDiv[l]=t.sinv*(l*t.c*pl[l]-cml[m][l]*pl[l-1]);
    	}
    }
     
	void evaluate_2ndDiv(legendre_order_one_theta &pl_2ndDiv, 
	                        legendre_order_one_theta &pl_1stDiv, 
							legendre_order_one_theta &pl, trig_one_theta &t)
    {
      	check_error(pl.nmType!=legendre_order_one_theta::CplxFull||pl.nmType!=pl_1stDiv.nmType
		  						||pl.nmType!=pl_2ndDiv.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_one_theta::FERRER||pl.dfType!=pl_1stDiv.dfType
								||pl.dfType!=pl_2ndDiv.dfType, 
			"Definition type must be FERRER for evaluation");   	
    	
    	check_error(pl.maxDeg()!=L||pl_1stDiv.maxDeg()!=L||pl_2ndDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl.order()!=pl_1stDiv.order(), "Order mismatch");
    	check_error(pl.order()!=pl_2ndDiv.order(), "Order mismatch");
    	
    	int l,m;
    	m=pl.order();
    	
    	if(m==0)
		{
			pl_2ndDiv[0]=0.0;
			for(l=1;l<=L;l++)
			{
				pl_2ndDiv[l]=-dd[l]*(ddinv[l]*t.ct*pl_1stDiv[l]+pl[l]);
			}
		}
		else
		{
			for(l=m;l<=L;l++)
			{
				pl_2ndDiv[l]=-dd[l]*(ddinv[l]*t.ct*pl_1stDiv[l]-(msqr[m]*ddinv[l]*t.sinvsqr-1.0)*pl[l]);
			}			
		}
    }
        
    void evaluate_3rdDiv(legendre_order_one_theta &pl_3rdDiv, 
    						legendre_order_one_theta &pl_2ndDiv,        
	                        legendre_order_one_theta &pl_1stDiv, 
							legendre_order_one_theta &pl, trig_one_theta &t)
    {
      	check_error(pl.nmType!=legendre_order_one_theta::CplxFull||pl.nmType!=pl_1stDiv.nmType
		  						||pl.nmType!=pl_2ndDiv.nmType||pl.nmType!=pl_3rdDiv.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_one_theta::FERRER||pl.dfType!=pl_1stDiv.dfType
								||pl.dfType!=pl_2ndDiv.dfType||pl.dfType!=pl_3rdDiv.dfType, 
			"Definition type must be FERRER for evaluation");     	
    	
    	check_error(pl.maxDeg()!=L||pl_1stDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl_2ndDiv.maxDeg()!=L||pl_3rdDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl.order()!=pl_1stDiv.order(), "Order mismatch");
    	check_error(pl.order()!=pl_2ndDiv.order(), "Order mismatch");
    	check_error(pl.order()!=pl_3rdDiv.order(), "Order mismatch");
    	
    	int l,m;
    	m=pl.order();
    	
    	if(m==0)
		{
			pl_3rdDiv[0]=0.0;
			for(l=1;l<=L;l++)
			{
				pl_3rdDiv[l]=dd[l]*(-ddinv[l]*t.ct*pl_2ndDiv[l]
				    +(ddinv[l]*t.sinvsqr-1.0)*pl_1stDiv[l]);
			}
		}
		else
		{
			for(l=m;l<=L;l++)
			{
				pl_3rdDiv[l]=dd[l]*(-ddinv[l]*t.ct*pl_2ndDiv[l]
				    +((1.0+msqr[m])*ddinv[l]*t.sinvsqr-1.0)*pl_1stDiv[l]
					-2.0*msqr[m]*ddinv[l]*t.sinvsqr*t.ct*pl[l]);
			}			
		}
    }        
        
	void evaluate_1stDiv(legendre_order_multi_theta &pl_1stDiv, 
							legendre_order_multi_theta &pl, trig_multi_theta &t)
    {
    	check_error(pl.nmType!=legendre_order_multi_theta::CplxFull||pl.nmType!=pl_1stDiv.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_multi_theta::FERRER||pl.dfType!=pl_1stDiv.dfType, 
			"Definition type must be FERRER for evaluation");  
			
    	check_error(pl.maxDeg()!=L||pl_1stDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl.order()!=pl_1stDiv.order(), "Order mismatch");
    	
    	int i_low=pl_1stDiv.ntl;
    	int i_high=pl_1stDiv.nth;
    	
    	check_error(pl.ntl!=i_low||pl.nth!=i_high, "Theta array mismatch");
    	
    	int l,m;
    	m=pl.order();
    	
    	for(int i=i_low;i<=i_high;i++)
    	{
	    	pl_1stDiv[i][m]=m*t.ct[i]*pl[i][m];	
	    	
	    	for(l=m+1;l<=L;l++)
	    	{
	    		pl_1stDiv[i][l]=t.sinv[i]*(l*t.c[i]*pl[i][l]-cml[m][l]*pl[i][l-1]);
	    	}
	    }
    }

	void evaluate_2ndDiv(legendre_order_multi_theta &pl_2ndDiv,
	                        legendre_order_multi_theta &pl_1stDiv, 
							legendre_order_multi_theta &pl, trig_multi_theta &t)
    {
      	check_error(pl.nmType!=legendre_order_multi_theta::CplxFull||pl.nmType!=pl_1stDiv.nmType
		  						||pl.nmType!=pl_2ndDiv.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_multi_theta::FERRER||pl.dfType!=pl_1stDiv.dfType
								||pl.dfType!=pl_2ndDiv.dfType, 
			"Definition type must be FERRER for evaluation");   	
    	
    	check_error(pl.maxDeg()!=L||pl_1stDiv.maxDeg()!=L||pl_2ndDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl.order()!=pl_1stDiv.order(), "Order mismatch");
    	check_error(pl.order()!=pl_2ndDiv.order(), "Order mismatch");
    	
    	int i_low=pl_1stDiv.ntl;
    	int i_high=pl_1stDiv.nth;
    	
    	check_error(pl.ntl!=i_low||pl.nth!=i_high, "Theta array mismatch");
    	check_error(pl_2ndDiv.ntl!=i_low||pl_2ndDiv.nth!=i_high, "Theta array mismatch");
    	
    	int i,l,m;
    	m=pl.order();
    	
    	if(m==0)
		{
			for(i=i_low;i<=i_high;i++)
			{
				pl_2ndDiv[i][0]=0.0;
				for(l=1;l<=L;l++)
				{
					pl_2ndDiv[i][l]=-dd[l]*(ddinv[l]*t.ct[i]*pl_1stDiv[i][l]+pl[i][l]);
				}
			}
		}
		else
		{
			for(i=i_low;i<=i_high;i++)
			for(l=m;l<=L;l++)
			{
				pl_2ndDiv[i][l]=-dd[l]*(ddinv[l]*t.ct[i]*pl_1stDiv[i][l]-(msqr[m]*ddinv[l]*t.sinvsqr[i]-1.0)*pl[i][l]);
			}			
		}  
	}

    void evaluate_3rdDiv(legendre_order_multi_theta &pl_3rdDiv, 
    						legendre_order_multi_theta &pl_2ndDiv,        
	                        legendre_order_multi_theta &pl_1stDiv, 
							legendre_order_multi_theta &pl, trig_multi_theta &t)
    {
      	check_error(pl.nmType!=legendre_order_multi_theta::CplxFull||pl.nmType!=pl_1stDiv.nmType
		  						||pl.nmType!=pl_2ndDiv.nmType||pl.nmType!=pl_3rdDiv.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_multi_theta::FERRER||pl.dfType!=pl_1stDiv.dfType
								||pl.dfType!=pl_2ndDiv.dfType||pl.dfType!=pl_3rdDiv.dfType, 
			"Definition type must be FERRER for evaluation"); 
			
    	check_error(pl.maxDeg()!=L||pl_1stDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl_2ndDiv.maxDeg()!=L||pl_3rdDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl.order()!=pl_1stDiv.order(), "Order mismatch");
    	check_error(pl.order()!=pl_2ndDiv.order(), "Order mismatch");
    	check_error(pl.order()!=pl_3rdDiv.order(), "Order mismatch");
    	
    	int i_low=pl_1stDiv.ntl;
    	int i_high=pl_1stDiv.nth;
    	
    	check_error(pl.ntl!=i_low||pl.nth!=i_high, "Theta array mismatch");    	
		check_error(pl_2ndDiv.ntl!=i_low||pl_2ndDiv.nth!=i_high, "Theta array mismatch");   
		check_error(pl_3rdDiv.ntl!=i_low||pl_3rdDiv.nth!=i_high, "Theta array mismatch"); 
			
    	int i,l,m;
    	m=pl.order();
    	
    	if(m==0)
		{
			for(i=i_low;i<=i_high;i++)
			{
				pl_3rdDiv[i][0]=0.0;
				for(l=1;l<=L;l++)
				{
					pl_3rdDiv[i][l]=dd[l]*(-ddinv[l]*t.ct[i]*pl_2ndDiv[i][l]
					    +(ddinv[l]*t.sinvsqr[i]-1.0)*pl_1stDiv[i][l]);
				}
			}
		}
		else
		{
			for(i=i_low;i<=i_high;i++)
			{
				for(l=m;l<=L;l++)
				{
					pl_3rdDiv[i][l]=dd[l]*(-ddinv[l]*t.ct[i]*pl_2ndDiv[i][l]
					    +((1.0+msqr[m])*ddinv[l]*t.sinvsqr[i]-1.0)*pl_1stDiv[i][l]
						-2.0*msqr[m]*ddinv[l]*t.sinvsqr[i]*t.ct[i]*pl[i][l]);
				}
			}
		}
    }       

	void evaluate_1stDiv(legendre_order_one_theta &pl_1stDiv, 
							legendre_order_one_theta &pl, trig_multi_theta &t, int i)
    {
    	check_error(pl.nmType!=legendre_order_one_theta::CplxFull||pl.nmType!=pl_1stDiv.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_one_theta::FERRER||pl.dfType!=pl_1stDiv.dfType, 
			"Definition type must be FERRER for evaluation"); 
    	check_error(pl.maxDeg()!=L||pl_1stDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl.order()!=pl_1stDiv.order(), "Order mismatch");
    	
    	int l,m;
    	m=pl.order();
    	
    	pl_1stDiv[m]=m*t.ct[i]*pl[m];	
    	
    	for(l=m+1;l<=L;l++)
    	{
    		pl_1stDiv[l]=t.sinv[i]*(l*t.c[i]*pl[l]-cml[m][l]*pl[l-1]);
    	}
    }

	void evaluate_2ndDiv(legendre_order_one_theta &pl_2ndDiv, 
	                        legendre_order_one_theta &pl_1stDiv, 
							legendre_order_one_theta &pl, trig_multi_theta &t, int i)
    {
      	check_error(pl.nmType!=legendre_order_one_theta::CplxFull||pl.nmType!=pl_1stDiv.nmType
		  						||pl.nmType!=pl_2ndDiv.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_one_theta::FERRER||pl.dfType!=pl_1stDiv.dfType
								||pl.dfType!=pl_2ndDiv.dfType, 
			"Definition type must be FERRER for evaluation"); 
			
    	check_error(pl.maxDeg()!=L||pl_1stDiv.maxDeg()!=L||pl_2ndDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl.order()!=pl_1stDiv.order(), "Order mismatch");
    	check_error(pl.order()!=pl_2ndDiv.order(), "Order mismatch");
    	
    	int l,m;
    	m=pl.order();
    	
    	if(m==0)
		{
			pl_2ndDiv[0]=0.0;
			for(l=1;l<=L;l++)
			{
				pl_2ndDiv[l]=-dd[l]*(ddinv[l]*t.ct[i]*pl_1stDiv[l]+pl[l]);
			}
		}
		else
		{
			for(l=m;l<=L;l++)
			{
				pl_2ndDiv[l]=-dd[l]*(ddinv[l]*t.ct[i]*pl_1stDiv[l]-(msqr[m]*ddinv[l]*t.sinvsqr[i]-1.0)*pl[l]);
			}			
		}
    }

    void evaluate_3rdDiv(legendre_order_one_theta &pl_3rdDiv, 
    						legendre_order_one_theta &pl_2ndDiv,        
	                        legendre_order_one_theta &pl_1stDiv, 
							legendre_order_one_theta &pl, trig_multi_theta &t, int i)
    {
      	check_error(pl.nmType!=legendre_order_one_theta::CplxFull||pl.nmType!=pl_1stDiv.nmType
		  						||pl.nmType!=pl_2ndDiv.nmType||pl.nmType!=pl_3rdDiv.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(pl.dfType!=legendre_order_one_theta::FERRER||pl.dfType!=pl_1stDiv.dfType
								||pl.dfType!=pl_2ndDiv.dfType||pl.dfType!=pl_3rdDiv.dfType, 
			"Definition type must be FERRER for evaluation"); 
			
    	check_error(pl.maxDeg()!=L||pl_1stDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl_2ndDiv.maxDeg()!=L||pl_3rdDiv.maxDeg()!=L, "Degree mismatch");
    	check_error(pl.order()!=pl_1stDiv.order(), "Order mismatch");
    	check_error(pl.order()!=pl_2ndDiv.order(), "Order mismatch");
    	check_error(pl.order()!=pl_3rdDiv.order(), "Order mismatch");
    	
    	int l,m;
    	m=pl.order();
    	
    	if(m==0)
		{
			pl_3rdDiv[0]=0.0;
			for(l=1;l<=L;l++)
			{
				pl_3rdDiv[l]=dd[l]*(-ddinv[l]*t.ct[i]*pl_2ndDiv[l]
				    +(ddinv[l]*t.sinvsqr[i]-1.0)*pl_1stDiv[l]);
			}
		}
		else
		{
			for(l=m;l<=L;l++)
			{
				pl_3rdDiv[l]=dd[l]*(-ddinv[l]*t.ct[i]*pl_2ndDiv[l]
				    +((1.0+msqr[m])*ddinv[l]*t.sinvsqr[i]-1.0)*pl_1stDiv[l]
					-2.0*msqr[m]*ddinv[l]*t.sinvsqr[i]*t.ct[i]*pl[l]);
			}			
		}
    }        
        
	void evaluate_div(legendre_one_theta &pml_div, legendre_one_theta &pml)
    {
      	check_error(pml.nmType!=legendre_one_theta::CplxFull||pml.nmType!=pml_div.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(pml.dfType!=legendre_one_theta::FERRER||pml.dfType!=pml_div.dfType, 
			"Definition type must be FERRER for evaluation"); 
			
    	check_error(pml.maxDeg()!=L||pml_div.maxDeg()!=L, "Degree mismatch");
    	
    	int m,l;
    	
    	pml_div[0][0]=0.0;
    	if(L==0)return;    	
    	
    	for(l=1;l<=L;l++)
    	{
    		pml_div[0][l]=-ddsqrt[l]*pml[1][l];
    	}
    	pml_div[1][1]=dml[1][1]*pml[0][1];
    	if(L==1)return;    	
    	
    	for(m=1;m<=L;m++)
    	{
    		pml_div[m][m]=dml[m][m]*pml[m-1][m];
    		for(l=m+1;l<=L;l++)
    		{
    			pml_div[m][l]=dml[m][l]*pml[m-1][l]-dml[m+1][l]*pml[m+1][l];
    		}    		
    	}
    }
    
	void evaluate_div(legendre_multi_theta &ptml_div, legendre_multi_theta &ptml)
    {
      	check_error(ptml.nmType!=legendre_multi_theta::CplxFull||ptml.nmType!=ptml_div.nmType, 
			"Normalization type must be CplxFull for evaluation");
		check_error(ptml.dfType!=legendre_multi_theta::FERRER||ptml.dfType!=ptml_div.dfType, 
			"Definition type must be FERRER for evaluation"); 
    	check_error(ptml.maxDeg()!=L||ptml_div.maxDeg()!=L, "Degree mismatch");
    	
    	int i_low=ptml_div.ntl;
    	int i_high=ptml_div.nth;
    	
    	check_error(ptml.ntl!=i_low||ptml_div.nth!=i_high, "Theta array mismatch");
    	
    	int i,m,l;
    	
    	for(i=i_low;i<=i_high;i++)
    	{
    		ptml_div[i][0][0]=0.0;
     		if(L==0)continue;    	
    	
			for(l=1;l<=L;l++)
	    	{
	    		ptml_div[i][0][l]=-ddsqrt[l]*ptml[i][1][l];
	    	}
    		ptml_div[i][1][1]=dml[1][1]*ptml[i][0][1];
	    	if(L==1)continue;    	

	    	for(m=1;m<=L;m++)
	    	{
	    		ptml_div[i][m][m]=dml[m][m]*ptml[i][m-1][m];
	    		for(l=m+1;l<=L;l++)
	    		{
	    			ptml_div[i][m][l]=dml[m][l]*ptml[i][m-1][l]-dml[m+1][l]*ptml[i][m+1][l];
	    		}    		
	    	}
    	}
    }
};

#endif
