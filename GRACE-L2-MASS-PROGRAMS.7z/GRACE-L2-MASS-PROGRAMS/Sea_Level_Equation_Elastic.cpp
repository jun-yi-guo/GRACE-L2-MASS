//Copyright: Jun-Yi Guo

#include<iostream>
#include<cstdlib>
    
#include "Sea_Level_Equation_Elastic.h"
 
using namespace std; 
 
int main(int argc,char *argv[])
{
    string sourcefile;

    cout<<endl
        <<"Usage: grid_conv [file]"<<endl
        <<"   Input data locations are specified in [file]"<<endl
        <<"   The default for [file] is \"Sea_Level_Equation_Elastic.txt\""<<endl
        <<"   Sea README_Sea_Level_Equation_Elastic.txt for detail description"<<endl;
           
    if(argc==1)
    { 
        sourcefile="Sea_Level_Equation_Elastic.txt";    
    }
    else if(argc==2)
    {
        sourcefile=argv[1];
    }
    else    
    {
        cout<<"Too many arguments"<<endl;
        exit(1);     
    }

    cout<<endl<<"Running..."<<endl;
    
    (slc_ocwe)sourcefile;

//    system("pause");
    return 0;
} 
