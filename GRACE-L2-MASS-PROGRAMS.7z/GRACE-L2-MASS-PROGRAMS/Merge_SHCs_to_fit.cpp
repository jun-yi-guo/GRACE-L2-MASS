//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

#include "rshc.h"
#include "mat.h"
#include "vec.h"

using namespace std;

int main()
{
    int i,j,l,m,Deg,numFile,numCoef;
    string ofile;
    
    ifstream control("Merge_SHCs_to_fit.txt");

    cout<<"Teading data ..."<<endl<<flush;
    
    control>>ofile;
    control>>Deg;
    control>>numFile;

    vec<string> ifile(numFile);
    
    rshc *shc;
    shc=new rshc[numFile];
    
    for(i=0;i<numFile;i++)
    {
        control>>ifile[i];                  
        shc[i].resize(Deg);
        shc[i].input_s0(ifile[i].c_str());
    }    

    cout<<"Outputing"<<endl<<flush;

    ofstream output(ofile.c_str());
    output.precision(16);
    
    output<<numFile<<endl;
    for(i=0;i<numFile;i++)output<<ifile[i].substr(0,4)<<"   "<<ifile[i].substr(5,3)<<endl;
    
    numCoef=shc[0].numCoef();
    
    output<<numCoef<<"   "<<3<<endl;

    for(l=0;l<=Deg;l++)
    {
        output<<"c"<<"  "<<l<<"   "<<0;
        for(j=0;j<numFile;j++)output<<"   "<<shc[j].c(0,l);
        output<<endl;
        
        output<<"s"<<"  "<<l<<"   "<<0;
        for(j=0;j<numFile;j++)output<<"   "<<0;
        output<<endl;

        for(m=1;m<=l;m++)
        {
            output<<"c"<<"  "<<l<<"   "<<m;  
            for(j=0;j<numFile;j++)output<<"   "<<shc[j].c(m,l);           
            output<<endl;
            
            output<<"s"<<"  "<<l<<"   "<<m;  
            for(j=0;j<numFile;j++)output<<"   "<<shc[j].s(m,l);                                    
            output<<endl;
        }
    }
                          
    output.close();

    delete[]shc;
    system("pause");
    return 1;
}
