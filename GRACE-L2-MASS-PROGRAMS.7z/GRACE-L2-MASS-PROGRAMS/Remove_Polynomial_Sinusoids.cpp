//Copyright: Jun-Yi Guo

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cmath>

#include "linalg.h"

#define PI 3.141592653589793238

using namespace std;

string int2str(int i,int N);

void Polynomial_Sinusoids(double iniTim,int numMon,double *degMon,double *coeMon,
     int numHar,double *perHar,double *coeCos, double *coeSin,
     int numTim, double *Tim, double *fun);

void Polynomial_Sinusoids_Remove(double iniTim,int numMon,double *degMon,double *coeMon,
     int numHar,double *perHar,double *coeCos, double *coeSin,
     int numTim, double *Tim, double *data_in, double *data_out);

int main()
{
    int i,j,k,numTim,numMon,numHar,numAttr,numTS,yyyy,ddd;

    double iniTim,*degMon,*perHar,*Tim,*data_in,*data_out;
    
    double *Data,*coeMon,*coeCos,*coeSin;
  
    string ifile,ofile,*attr,*pol_file,*cos_file,*sin_file,stmp;
  
    ifstream control("Remove_Polynomial_Sinusoids.txt");
    
    control>>iniTim;

    control>>numMon;
    degMon=Vector(numMon+1);
    pol_file=new string[numMon+1];

    for(i=0;i<numMon;i++)
    {
        control>>degMon[i];
        control>>pol_file[i];
    }
    
    control>>numHar;
    perHar=Vector(numHar+1);
    cos_file=new string[numHar+1];
    sin_file=new string[numHar+1];

    for(i=0;i<numHar;i++)
    {
        control>>perHar[i];
        control>>cos_file[i];
        control>>sin_file[i];
    }
    
    control>>ifile;
    control>>ofile;
    
    control.close();   
    
	ifstream *pol_in,*cos_in,*sin_in;
	pol_in=new ifstream[numMon+1];
	cos_in=new ifstream[numHar+1];
	sin_in=new ifstream[numHar+1];
	
	for(i=0;i<numMon;i++)
		pol_in[i].open(pol_file[i].c_str());
	for(i=0;i<numHar;i++)
	{
		cos_in[i].open(cos_file[i].c_str());
		sin_in[i].open(sin_file[i].c_str());
	}
	
    ifstream in(ifile.c_str());
    ofstream out(ofile.c_str());
    out.precision(16);

    coeMon=Vector(numMon+1);
    coeCos=Vector(numHar+1);    
    coeSin=Vector(numHar+1); 

    in>>numTim;
    
    out<<numTim<<endl;

    Tim=Vector(numTim);
    data_in=Vector(numTim);
    data_out=Vector(numTim);        
    for(i=0;i<numTim;i++)
    {
        in>>yyyy;
        in>>ddd;
        Tim[i]=yyyy+ddd/365.25;
        cout<<"Year: "<<yyyy<<" Day: "<<ddd<<" -> "<<Tim[i]<<endl;
    
        out<<yyyy<<"  "<<int2str(ddd,3)<<endl;
    }
         
    in>>numTS;
    in>>numAttr;     
    attr=new string[numAttr];
         
    out<<numTS<<"  "<<numAttr<<endl;
      
    for(i=0;i<numTS;i++)
    {
        for(j=0;j<numAttr;j++)in>>attr[j];      
        for(j=0;j<numTim;j++)in>>data_in[j];
        
        for(j=0;j<numAttr;j++)
		{
			for(k=0;k<numMon;k++)
			{
				pol_in[k]>>stmp;
				if(stmp!=attr[j])
				{
					cout<<"Attributes different between polynomial file and data file"<<endl;
					exit(1);
				}
			}
			for(k=0;k<numHar;k++)
			{
				cos_in[k]>>stmp;
				if(stmp!=attr[j])
				{
					cout<<"Attributes different between cos coefficient file and data file"<<endl;
					exit(1);
				}
				sin_in[k]>>stmp;
				if(stmp!=attr[j])
				{
					cout<<"Attributes different between sin coefficient file and data file"<<endl;
					exit(1);
				}
			}
		}
        
        for(k=0;k<numMon;k++)pol_in[k]>>coeMon[k];
        for(k=0;k<numHar;k++)
		{
			cos_in[k]>>coeCos[k];
			sin_in[k]>>coeSin[k];
		}

        Polynomial_Sinusoids_Remove(iniTim,numMon,degMon,coeMon,
             numHar,perHar,coeCos,coeSin,numTim,Tim,data_in,data_out);                       
        
        for(j=0;j<numAttr;j++)out<<attr[j]<<"   ";
        for(j=0;j<numTim;j++)out<<data_out[j]<<"   ";
        out<<endl;
    }

    for(i=0;i<numMon;i++)
		pol_in[i].close();
	for(i=0;i<numHar;i++)
	{
		cos_in[i].close();
		sin_in[i].close();
	}

    in.close();
    out.close();
         
    FreeVector(degMon);
    FreeVector(coeMon);
    FreeVector(perHar);
    FreeVector(coeCos);
    FreeVector(coeSin);
    FreeVector(Tim);
    FreeVector(data_in);
    FreeVector(data_out);
    
    delete[]attr;
    delete[]pol_file;
    delete[]cos_file;
    delete[]sin_file;
    
    return 0;   
}

string int2str(int i,int N)
{
     int j,M;
     string value,prev;
     char c[10],tmp[10];
     
//     prev=itoa(i,tmp,10);
     
     ostringstream ss;
     ss<<i;
     prev=ss.str();
     
     M=prev.size();
     
     if(M>N)
     {
         cout<<"String length too short to accormodate the integer"<<endl;
         return 0;
     }
     
     value="";
     for(j=0;j<N-M;j++)value+="0";
     value+=prev;
     return value;  
}

void Polynomial_Sinusoids(double iniTim,int numMon,double *degMon,double *coeMon,
             int numHar,double *perHar,double *coeCos, double *coeSin,
             int numTim, double *Tim, double *fun)
{
    int i,j;
    double phi;
    
    for(i=0;i<numTim;i++)
    {
        fun[i]=0;
        
        for(j=0;j<numMon;j++)
        {
            fun[i]+=coeMon[j]*pow(Tim[i]-iniTim,degMon[j]);
        }
        
        for(j=0;j<numHar;j++)
        {
            phi=(2.0*PI/perHar[j])*(Tim[i]-iniTim);
            fun[i]+=coeCos[j]*cos(phi)+coeSin[j]*sin(phi);
        }
    }
}

void Polynomial_Sinusoids_Remove(double iniTim,int numMon,double *degMon,double *coeMon,
     int numHar,double *perHar,double *coeCos, double *coeSin,
     int numTim, double *Tim, double *data_in, double *data_out)
{
     double *fun;
     fun=Vector(numTim); 
     
     Polynomial_Sinusoids(iniTim,numMon,degMon,coeMon,numHar,perHar,coeCos,coeSin,numTim,Tim,fun);
     
     VecSubVec(numTim,data_in,fun,data_out);
     
     FreeVector(fun);
}
