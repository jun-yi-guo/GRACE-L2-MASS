//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

#include "rshc.h"

using namespace std;

int main()
{
    int i,j,Deg,numFile;
    string ds,ifile1,ifile2,ofile;
    ifstream input("Diff_Sum_Pairs_SHCs.txt");

	input>>ds;
		check_error(!(ds=="DIFF"||ds=="SUM"),"the first line must be either 'DIFF' or 'SUM'");
	
    input>>Deg;
    
    rshc shc1(Deg),shc2(Deg),shc0(Deg);

    input>>numFile;

    for(i=0;i<numFile;i++)
    {
        input>>ifile1;
        input>>ifile2;
        input>>ofile;
        shc1.input_s0(ifile1.c_str());
        shc2.input_s0(ifile2.c_str());
        
        if(ds=="DIFF")for(j=0;j<shc1.numCoef();j++)shc0[j]=shc1[j]-shc2[j];
        else for(j=0;j<shc1.numCoef();j++)shc0[j]=shc1[j]+shc2[j];
        
        shc0.output_s0(ofile.c_str(),16);
        cout<<i+1<<" over "<<numFile<<" done"<<endl;
    }

    input.close();
//    system("pause");
    return 0;
}
