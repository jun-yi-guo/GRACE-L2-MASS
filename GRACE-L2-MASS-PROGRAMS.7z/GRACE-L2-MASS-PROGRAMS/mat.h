// File name: mat.h
// Copyright: Junyi Guo
// Author: Junyi Guo
// Created on April 18, 2001
// Rewritten on September 8, 2002
// Bug fixed on July 20, 2004
// Modified for package fsh on Juin 13, 2006 
// Modified for having arbitrary lower index
// on April 27, 2016

#ifndef mat_h
#define mat_h

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <sstream>

#include "check_error.h"

using namespace std;

template<class T>class vec;

    /**
     * This is a numerical full matrix class templated. It is
     * row-oriented and  0-based, i.e. C-style indexing is
     * used. The element at i-th row and j-th colunm of a mat
     * object \em A can be accessed using \em A(i,j) or \em A[i][j]. The
     * first element is \em A(0,0) or \em A[0][0]. Bound check is made when
     * using \em A(i,j) and when the macro \em TNL_DEBUG is predefined.
     * But no bound check is made when using \em A[i][j]. In fact the
     * access speed of \em A[i][j] is as fast as primitive C arrays.
     * So it is recommanted to use \em A[i][j] when writing utilities,
     * checking only the upper bounds first, and to use \em A(i,j) for
     * random access when bound check should be best done.
     */

template<class T>class mat
{
  private:

    T* v_;
    T** r_;
    
    int m_;
    int n_;
    int mn_;
    
    int ml_,mh_;
    int nl_,nh_;
    
    bool is_submat;

    void initialize(int m, int n)
    {
    	check_error(!((m>0&&n>0)||(m==0&&n==0)),"The numbers of row and column must be both larger than 0 or both equal to 0");
        if(m>0&&n>0)
        {
            initialize(0,m-1,0,n-1);
        }
        else
        {
	        m_=0;
	        n_=0;
	        mn_=0;  
	        ml_=0;
	        mh_=-1;
	        nl_=0;
	        nh_=-1;       
			is_submat=false;		 	
		}
    }
    
    void initialize(int ml, int mh, int nl, int nh)
    {
		check_error(mh<ml||nh<nl,"Higher index cannot be smaller than lower index");

        m_=mh-ml+1;
        n_=nh-nl+1;
        mn_=m_*n_;        
        ml_=ml;
        mh_=mh;
        nl_=nl;
        nh_=nh;   

        r_=new(nothrow)T*[m_];
        check_error(r_==NULL,"not enough menory");
        r_-=ml_;
				     	
        v_=new(nothrow)T[mn_];
        check_error(v_==NULL,"not enough menory");
		v_-=nl_;
        r_[ml_]=v_;

        for(int i=ml_+1;i<=mh_;i++)r_[i]=r_[i-1]+n_;
        
        is_submat=false;
    }
    
    void destroy()
    {
        if(mn_!=0)
        {
            delete[](r_+ml_);
            if(is_submat==false)delete[](v_+nl_);
        }
    }

  public:

        /**
         * Construct an object of \em m rows and \em n columns.
         * The values of the elements are unspecified
         */
         
    explicit mat(int m=0, int n=0)
    {
        initialize(m,n);
    }

    explicit mat(int ml, int mh, int nl, int nh)
    {
        initialize(ml,mh,nl,nh);
    }
    
        /** 
         * The copy constructor 
         */
         
    mat(const mat<T>& A)
    {
        initialize(A.ml_, A.mh_, A.nl_, A.nh_);
        int i,j;
        for(i=ml_;i<=mh_;i++)for(j=nl_;j<=nh_;j++)r_[i][j]=A[i][j];
    }

    mat(mat<T>& A, int m1A, int m2A, int n1A, int n2A, int m1new, int m2new, int n1new, int n2new)
    {
    	initialize(0,0);
    	sub_mat(A,m1A,m2A,n1A,n2A,m1new,m2new,n1new,n2new);
    }
    
        /**
         * The destructor.
         */

    ~mat()
    {
        destroy();
    }

    void sub_mat(mat<T>& A, int m1A, int m2A, int n1A, int n2A, int m1new, int m2new, int n1new, int n2new)
	{  
		if(is_submat==false)check_error(mn_!=0, "only an empty matrix can be used as sub-matrix");
		check_error(m1A<A.ml_||m2A>A.mh_||n1A<A.nl_||n2A>A.nh_, "sub-mat index outside permissible range");
		check_error(m2new-m1new!=m2A-m1A||n2new-n1new!=n2A-n1A, "sub-mat old and new index ranges not compatible");
		check_error(m2A<m1A||n2A<n1A, "no sub-mat selected (selected higher index smaller than lower index)");
		
		m_=m2A-m1A+1;
		n_=n2A-n1A+1;
		mn_=m_*n_;
		ml_=m1new;
		mh_=m2new;		
		nl_=n1new;
		nh_=n2new;

//		DATA **T_submatrix(DATA **a,int oldrl,int oldrh,int oldcl,int oldch,int newrl,int newcl)	
//	    int i,j,nrow=oldrh-oldrl+1,ncol=oldcl-newcl;
//	    DATA **m;
//	    m=new DATA *[nrow];
//	    if(!m)nrerror("allocation failure in submatrix()");
//	    m -= newrl;
//	    for(i=oldrl,j=newrl;i<=oldrh;i++,j++) m[j]=a[i]+ncol; 
//	    return m;
		
        r_=new(nothrow)T*[m_];
        check_error(r_==NULL,"not enough menory");
        r_-=ml_;		

		int i,j;
		int nshift=n1A-n1new;
	    for(i=m1A,j=m1new;i<=m2A;i++,j++) r_[j]=A[i]+nshift; 

		is_submat=true;
	}
         
    T** matPtr() const
    {
        return r_;
    }

        /**
         * Convert the object to a primitive C array. This
         * permmits to pass a Matrix object as pointer 
         * parameter (one dimensional array) to a C function.
         */
         
    T* vecPtr() const
    {
    	check_error(is_submat==true, "sub-mat: vecPtr() is meaningless");
        return v_+nl_;
    }

        /** 
         * Return the number of rows. 
         */
         
    int numRows() const
    {
        return m_;
    }
    
        /** 
         * Return the number of columns. 
         */
         
    int numCols() const
    {
        return n_;
    }
    
    int LowerRowIndex() const
    {
        return ml_;
    }
    
    int HigherRowIndex() const
    {
        return mh_;
    }
    
    int LowerColumnIndex() const
    {
        return nl_;
    }
    
    int HigherColumnIndex() const
    {
        return nh_;
    }    
    
        /** 
         * Resize the matrix to \em m rows and \em n colunms. 
         */        
         
    void resize(int m=0, int n=0)
    {
        if(m_!=m||n_!=n||is_submat==true)
        {
            destroy();
            initialize(m,n);
        }
        else
        {
        	ml_=0;
        	mh_=m-1;
        	nl_=0;
        	nh_=n-1;
        }
    }
    
    void resize(int ml, int mh, int nl, int nh)
    {
        if(m_!=mh-ml+1||n_!=nh-nl+1||is_submat==true)
        {
            destroy();
            initialize(ml,mh,nl,nh);
        }
        else
        {
        	ml_=ml;
        	mh_=mh;
        	nl_=nl;
        	nh_=nh;
        }
    }    

        /** 
         * Evaluate the the one dimensional array \em v to the object. 
         */
         
    void evaluate(const T* v)
    {
        int i,j;
        for(i=0;i<m_;i++)for(j=0;j<n_;j++)r_[i+ml_][j+nl_]=v[i*n_+j];
    }

        /**
         * Set the elements of the object successively equal to the values
         * given in the string \em s, the values are separated by spaces.
         */ 
 
    void evaluate(char *s)
    {
        istringstream ins(s);
        int i,j;
        for(i=ml_;i<=mh_;i++)for(j=nl_;j<=nh_;j++)ins>>r_[i][j];
    }

        /**
         * Evaluate to this object the object \em A of different element data
         * type. If the data type of this object is \em T, and the data
         * type of the object \em x is \em T1, the automatic conversion
         * from \em T1 to \em T is required. Otherwise the behavior is
         * unspecified.
         */

    template<class T1>void convert(mat<T1>& A)
    {
        check_error(!(m_==A.numRows()&&n_==A.numCols()),"Dimension mismatch");
        
		int mlA=A.LowerRowIndex();
		int nlA=A.LowerColumnIndex();
		        
        int i,j;
        for(i=0;i<m_;i++)for(j=0;j<n_;j++)
			r_[i+ml_][j+nl_]=static_cast<T>(A[i+mlA][j+nlA]);
    }

        /** 
         * Element accessing using [][]. No bound check is made. 
         */
         
    T* operator[](int i)
    {
        return r_[i];
    }

        /** 
         * Element accessing using [][]. No bound check is made. 
         */
         
    const T* operator[](int i) const
    {
        return r_[i];
    }

        /**
         * The \em rv is assigned to \em lv. The sizes of \em rv and
         * of \em lv should be equal.
         */
         
    mat<T>& operator=(const mat<T> &A)
    {
        if(this==&A)return *this;
        
 //       cout<<m_<<" "<<A.m_<<"      "<<n_<<"  "<<A.n_<<endl;
        
        check_error(m_!=A.m_||n_!=A.n_,"Sizes of Mats are different");
        
        int i,j;
        for(i=0;i<m_;i++)
        for(j=0;j<n_;j++)
        	r_[i+ml_][j+nl_]=A.r_[i+A.ml_][j+A.nl_];
        
        return *this;
    }
    
        /**
         * The \em rv is assigned to every element of \em lv. 
         */        
         
    mat<T>& operator=(const T& a)
    {
        int i,j;
        for(i=ml_;i<=mh_;i++)for(j=nl_;j<=nh_;j++)r_[i][j]=a;
        return *this;
    }
    
        /** 
         * The unitary + operator. Add the \em rv to the object. 
         */        
         
    mat<T>& operator+=(const mat<T>& A)
    {
        check_error(!(m_==A.m_&&n_==A.n_),"Sizes of mats are different");
        int i,j;
        for(i=0;i<m_;i++)
		for(j=0;j<n_;j++)
			r_[i+ml_][j+nl_]+=A.r_[i+A.ml_][j+A.nl_];
        return *this;
    }

        /**
         * The unitary + operator. Add the \em rv to every element
         * of the object.
         */      
           
    mat<T>& operator+=(const T& a)
    {
        int i,j;
        for(i=ml_;i<=mh_;i++)
		for(j=nl_;j<=nh_;j++)
			r_[i][j]+=a;
        return *this;
    }

        /** 
         * The unitary - operator. Substract the \em rv from the object. 
         */        
         
    mat<T>& operator-=(const mat<T>& A)
    {
        check_error(!(m_==A.m_&&n_==A.n_),"Sizes of mats are different");
        int i,j;
        for(i=0;i<m_;i++)
		for(j=0;j<n_;j++)
			r_[i+ml_][j+nl_]-=A.r_[i+A.ml_][j+A.nl_];
        return *this;
    }

        /**
         * The unitary - operator. Substract the \em rv from every
         * element of the object.
         */        
         
    mat<T>& operator-=(const T& a)
    {
        int i,j;
        for(i=ml_;i<=mh_;i++)
		for(j=nl_;j<=nh_;j++)
			r_[i][j]-=a;
        return *this;
    }

        /**
         * The unitary * operator. Multiply the \em rv to the object
         * element by element.
         */        
         
    mat<T>& operator*=(const mat<T>& A)
    {
        check_error(!(m_==A.m_&&n_==A.n_),"Sizes of vecs are different");
        int i,j;
        for(i=0;i<m_;i++)
		for(j=0;j<n_;j++)
			r_[i+ml_][j+ml_]*=A.r_[i+A.ml_][j+A.nl_];
        return *this;
    }
    
        /**
         * The unitary * operator. Multiply the \em rv to every
         * element of the object.
         */        
         
    mat<T>& operator*=(const T& a)
    {
        int i,j;
        for(i=ml_;i<=mh_;i++)
		for(j=nl_;j<=nh_;j++)
			r_[i][j]*=a;
        return *this;
    }

        /**
         * The unitary / operator. Devide every element the object
         * the corresponding element of the \em rv.
         */        
         
    mat<T>& operator/=(const mat<T>& A)
    {
        check_error(!(m_==A.m_&&n_==A.n_),"Sizes of vecs are different");
        int i,j;
        for(i=0;i<m_;i++)
		for(j=0;j<n_;j++)
			r_[i+ml_][j+nl_]/=A.r_[i+A.ml_][j+A.nl_];
        return *this;
    }

        /**
         * The unitary / operator. Devide every element of the
         * object by the \em rv.
         */        
         
    mat<T>& operator/=(const T& a)
    {
        int i,j;
        for(i=ml_;i<=mh_;i++)
		for(j=nl_;j<=nh_;j++)
			r_[i][j]/=a;
        return *this;
    }

}; // mat

    /**\relates mat
     * The unitary + operator
     */

template<class T>mat<T>& operator+(const mat<T>& A)
{
    return A;
}

    /**\relates mat
     * The binary + operator.
     */

template<class T>mat<T> operator+(const mat<T>& A, const mat<T>& B)
{
    check_error(!(A.numRows()==B.numRows()&&A.numCols()==B.numCols()),"Size of matrices are not compatible");
    mat<T> C(A);
    C+=B;
    return C;
}

    /**\relates mat
     * The binary + operator. The right operand is added to every elemrnt of the left operand.
     */

template<class T>mat<T> operator+(const mat<T>& A, const T& b)
{
    mat<T> C(A);
    C+=b;
    return C;
}

    /**\relates mat
     * The binary + operator. The left operand is added to every elemrnt of the right operand.
     */

template<class T>mat<T> operator+(const T& a, const mat<T>& B)
{
   return B+a;
}

    /**\relates mat
     * The unitary - operator
     */

template<class T>mat<T> operator-(const mat<T>& A)
{
	int lri=A.LowerRowIndex();
	int hri=A.HigherRowIndex();
	int lci=A.LowerColumnIndex();
	int hci=A.HigherColumnIndex();
	
    mat<T> C(lri,hri,lci,hci);
    
    int i,j;
    for(i=lri;i<=hri;i++)
	for(j=lci;j<=hci;j++)
		C[i][j]=-A[i][j];
    return C;
}

    /**\relates mat
     * The binary - operator.
     */

template<class T>mat<T> operator-(const mat<T>& A, const mat<T>& B)
{
    check_error(!(A.numRows()==B.numRows()&&A.numCols()==B.numCols()),"Size of matrices are not compatible");
    mat<T> C(A);
    C-=B;
    return C;
}

    /**\relates mat
     * The binary - operator. The right operand is subtracted from every elemrnt
     * of the left operand.
     */

template<class T>mat<T> operator-(const mat<T>& A, const T& b)
{
    mat<T> C(A);
    C-=b;
    return C;
}

    /**\relates mat
     * The binary - operator. Substract from the left oprand every element
     * of the right oprand.
     */

template<class T>mat<T> operator-(const T& a, const mat<T>& B)
{
	int lri=B.LowerRowIndex();
	int hri=B.HigherRowIndex();
	int lci=B.LowerColumnIndex();
	int hci=B.HigherColumnIndex();
	
    mat<T> C(lri,hri,lci,hci);

    int i,j;
    for(i=lri;i<=hri;i++)
	for(j=lci;j<=hci;j++)
		C[i][j]=a-B[i][j];
    return C;
}

    /**\relates mat
     * The binary * operator. Elementwise multiplication
     */

template<class T>mat<T> operator*(const mat<T>& A, const mat<T>& B)
{
    check_error(!(A.numRows()==B.numRows()&&A.numCols()==B.numCols()),"Size of matrices are not compatible");
    mat<T> C(A);
    C*=B;
    return C;
}

    /**\relates mat
     * The binary * operator. The right operand is multiplied with every elemrnt
     * of the left operand.
     */

template<class T>mat<T> operator*(const mat<T>& A, const T& b)
{
    mat<T> C(A);
    C*=b;
    return C;
}

    /**\relates mat
     * The binary * operator. The left operand is multiplied with every elemrnt
     * of the right operand.
     */

template<class T>mat<T> operator*(const T& a, const mat<T>& B)
{
    return B*a;
}


    /**\relates mat
     * The binary / operator. Elementwise division
     */

template<class T>mat<T> operator/(const mat<T>& A, const mat<T>& B)
{
    check_error(!(A.numRows()==B.numRows()&&A.numCols()==B.numCols()),"Size of matrices are not compatible");
    mat<T> C(A);
    C/=B;
    return C;
}

    /**\relates mat
     * The binary / operator. The right operand is used to divide every elemrnt
     * of the left operand.
     */

template<class T>mat<T> operator/(const mat<T>& A, const T& b)
{
    mat<T> C(A);
    C/=b;
}

    /**\relates mat
     * The binary / operator. The left operand is divided by every elemrnt
     * of the right operand.
     */

template<class T>mat<T> operator/(const T& a, const mat<T>& B)
{
	int lri=B.LowerRowIndex();
	int hri=B.HigherRowIndex();
	int lci=B.LowerColumnIndex();
	int hci=B.HigherColumnIndex();
	
    mat<T> C(lri,hri,lci,hci);

    int i,j;
    for(i=lri;i<=hri;i++)
	for(j=lci;j<=hci;j++)
		C[i][j]=a/B[i][j];
    return C;
}

    /**\relates mat
     * The binary == operator.
     */

template<class T>bool operator==(const mat<T>& A, const mat<T>& B)
{
    if(A.numRows()!=B.numRows()||A.numCols()!=B.numCols())return false;
    int i,j;
    for(i=0;i<A.numRows();i++)for(j=0;j<A.numCols();j++)
	if(A[i+A.LowerRowIndex()][j+A.LowerColumnIndex()]
	    !=B[i+B.LowerRowIndex()][j+B.LowerColumnIndex()])return false;
    return true;
}

    /**\relates mat
     * The binary != operator.
     */

template<class T>bool operator!=(const mat<T>& A, const mat<T>& B)
{
    return !(A==B);
}

/**\relates mat
 * Matrix multiplication \f$AB\f$
 */
     
template<class T>mat<T> mul(const mat<T>& A, const mat<T>& B)
{
    check_error(A.numCols()!=B.numRows(),"Size of matrices are not compatible");
    int m=A.numRows();
	int n=B.numCols();
    int mlA=A.LowerRowIndex();
    int nlA=A.LowerColumnIndex();
    int mlB=B.LowerRowIndex();
    int nlB=B.LowerColumnIndex();
    
    mat<T> C(m,n);
    int l=A.numCols();
    int i,j,k;
    for(i=0;i<m;i++)
	for(j=0;j<n;j++)
	for(k=0,C[i][j]=0;k<l;k++)
		C[i][j]+=A[i+mlA][k+nlA]*B[k+mlB][j+nlB];
		
	return C;
}

    /**\relates mat
     * Matrix multiplication \f$A^TB\f$
     */    
     
template<class T>mat<T> transMul(const mat<T>& A, const mat<T>& B)
{
    check_error(!(A.numCols()==B.numCols()),"Size of matrices are not compatible");
    int m=A.numCols(), n=B.numCols();
    mat<T> C(m,n);
    
    int mlA=A.LowerRowIndex();
    int nlA=A.LowerColumnIndex();
    int mlB=B.LowerRowIndex();
    int nlB=B.LowerColumnIndex();    
    
    int l=A.numRows();
    int i,j,k;
    for(i=0;i<m;i++)
	for(j=0;j<n;j++)
	for(k=0,C[i][j]=0;k<l;k++)
		C[i][j]+=A[k+mlA][i+nlA]*B[k+mlB][j+nlB];
		
	return C;
}

    /**\relates mat
     * Matrix multiplication \f$AB^T\f$
     */       

template<class T>mat<T> mulTrans(const mat<T>& A, const mat<T>& B)
{
    check_error(!(A.numCols()==B.numCols()),"Size of matrices are not compatible");
    int m=A.numRows(), n=B.numRows();
    mat<T> C(m,n);
    
    int mlA=A.LowerRowIndex();
    int nlA=A.LowerColumnIndex();
    int mlB=B.LowerRowIndex();
    int nlB=B.LowerColumnIndex();    
        
    int l=A.numCols();
    int i,j,k;
    for(i=0;i<m;i++)
	for(j=0;j<n;j++)
	for(k=0,C[i][j]=0;k<l;k++)
		C[i][j]+=A[i+mlA][k+nlA]*B[j+mlB][k+nlB];
		
	return C;
}

    /**\relates mat
     * Matrix multiplication \f$APB\f$
     */
     
template<class T>mat<T> mul(const mat<T>& A, const mat<T>& P, const mat<T>& B)
{
    check_error(!(A.numCols()==P.numRows()&&P.numCols()==B.numRows()),"Size of matrices are not compatible");
    mat<T> D(A.numRows(),P.numCols());
    D=mul(A,P);
    mat<T> C(D.numRows(),B.numCols());
    C=mul(D,B);
    return C;
}

    /**\relates mat
     * Matrix multiplication \f$A^TPB\f$
     */    
     
template<class T>mat<T> transMul(const mat<T>& A, const mat<T>& P, const mat<T>& B)
{
    check_error(!(A.numRows()==P.numRows()&&P.numCols()==B.numRows()),"Size of matrices are not compatible");
    mat<T> D(A.numCols(),P.numCols());
    D=trans_mul(A,P);
    mat<T> C(A.numCols(),B.numCols());
    C=mul(D,B);
    return C;
}

    /**\relates mat
     * Matrix multiplication \f$APB^T\f$
     */    
     
template<class T>mat<T> mulTrans(const mat<T>& A, const mat<T>& P, const mat<T>& B)
{
    check_error(!(A.numCols()==P.numRows()&&P.numCols()==B.numCols()),"Size of matrices are not compatible");
    mat<T> D(A.numRows(),P.numCols());
    D=mul(A,P);
    mat<T> C(A.numRows(),B.numRows());
    C=mul_trans(D,B);
    return C;
}

    /**\relates mat
     * Matrix-vec multiplication \f$Ax\f$
     */       
     
template<class T>vec<T> mul(const mat<T>& A, const vec<T>& x)
{
    check_error(!(A.numCols()==x.size()),"Size of matrix and vec are not compatible");
    int n=A.numRows();
    vec<T> b(n);
    
    int mlA=A.LowerRowIndex();
    int nlA=A.LowerColumnIndex();
    int lix=x.lower_index();
 
    int l=x.size();
    int i,k;
    for(i=0;i<n;i++)
	for(k=0,b[i]=0;k<l;k++)
		b[i]+=A[i+mlA][k+nlA]*x[k+lix];
    return b;
}

    /**\relates mat
     * Matrix-vec multiplication \f$A^Tx\f$
     */     

template<class T>vec<T> transMul(const mat<T>& A, const vec<T>& x)
{
    check_error(!(x.size()==A.numRows()),"Sizes of vecs and Matrix Mismatch");
    int n=A.numCols();
    vec<T>b(n); 
    
    int mlA=A.LowerRowIndex();
    int nlA=A.LowerColumnIndex();
    int lix=x.lower_index();
	    
    int l=x.size();
    int i,k;
    for(i=0;i<n;i++)
	for(k=0,b[i]=0;k<l;k++)
		b[i]+=A[k+mlA][i+nlA]*x[k+lix];
    return b;
}

    /**\relates mat
     * Matrix-vec multiplication \f$x^TAy\f$
     */  

template<class T>T transMul( const vec<T>& x, const mat<T>& A, const vec<T>& y)
{
    check_error(!(x.size()==A.numRows()&&A.numCols()==y.size()),"Size of matrix and vec are not compatible");
    vec<T> b(A.numRows());
    b=mul(A,y);
    return dot_prod(x,b);
}

    /**\relates mat
     * Write to stream.
     */

template<class T>ostream& operator<<(ostream& s, const mat<T>& A){
    int m,n,i,j;
    m=A.numRows();
    n=A.numCols();
    int mlA=A.LowerRowIndex();
    int nlA=A.LowerColumnIndex();    
  
    s<<m<<"    "<<n;
    for(i=0;i<m;i++)
	{
        s<<endl;
        for(j=0;j<n;j++)
			s<<A[i+mlA][j+nlA]<<"  ";
    }
    return s;
}

    /** \relates mat
     * Read from stream.
     */

template<class T>istream& operator>>(istream& s,mat<T>& A){
    int m,n,i,j;
    s>>m;
    s>>n;
    check_error(!((m>0&&n>0)||(m==0&&n==0)),"Illegal size of matrix in data file");
    if(m!=A.numRows()||n!=A.numCols())A.resize(m,n);
    
    int mlA=A.LowerRowIndex();
    int nlA=A.LowerColumnIndex(); 
    for(i=0;i<m;i++)
	for(j=0;j<n;j++)
		s>>A[i+mlA][j+nlA];
    return s;
}

#endif 
