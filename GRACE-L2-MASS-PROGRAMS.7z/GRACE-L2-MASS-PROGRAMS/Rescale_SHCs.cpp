//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <fstream>
#include <string>
#include <cmath>
#include <algorithm>

#include "rshc.h"
#include "vec.h"

using namespace std;

int main()
{
    int i,l,m,DEG,numFile;
	double a,R;     
    string ifile,ofile;

    ifstream input("Rescale_SHCs.txt");

    input>>DEG;
    input>>a;
    input>>R;
    input>>numFile;
    
//    check_error(TDEG>MDEG,"truncation bandwidth too high");

    rshc shcs(DEG);

    vec<double> fac(DEG+1);
    fac[1]=a/R;
    for(i=2;i<=DEG;i++)fac[i]=fac[i-1]*fac[1];

    for(i=0;i<numFile;i++)
    {
        input>>ifile;
        input>>ofile;

        shcs.input_s0(ifile.c_str());

        for(l=1;l<=DEG;l++)
        {
            shcs.c(0,l)*=fac[l];
            for(m=1;m<=l;m++)
            {
                shcs.c(m,l)*=fac[l];
                shcs.s(m,l)*=fac[l];                 
            }
        }
        
        shcs.output_s0(ofile.c_str(),16);   
        
        cout<<i+1<<" over "<<numFile<<" done"<<endl;        
    }

    system("pause");
    return 0;
}
