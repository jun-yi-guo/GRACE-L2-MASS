//Copyright: Jun-Yi Guo

#ifndef rsht_h
#define rsht_h

#include <fstream>
#include <string>
#include <sstream>

#include <algorithm>

#include "vec.h"
#include "mat.h"
#include "fftpack++.h"
#include "rshc.h"
#include "trig.h"
#include "rshana.h"
#include "rshsyn.h"
#include "grid.h"

using namespace std;

class rsht_memo
{
  private:

    int bw_;
    int gsize_;
    
    rfft rfft_;	

	rshana ana_;
	rshsyn syn_;
	legendre_multi_theta alf_;
	legendre_multi_theta alfd1_;
	legendre_multi_theta alfd2_;
	legendre_multi_theta alfd3_;
	
	int d;

	vec<double>t_;	
	trig_multi_theta trig_t_;
	
	vec<double>lmbd_;
	vec<trig_one_lambda_real> trig_lmd;
	bool is_trig_lambda;
	
	double PI;

    void initialize(int bw, int dd)
    { 
        bw_=bw;
        if(bw_==0)return;
        d=dd;

        gsize_=2*bw_;
        rfft_.resize(gsize_);

		grid grd_("Gauss",gsize_,gsize_);
		t_.resize(bw_);
		grd_.latitude_GE0_to_theta_RAD(t_);
		trig_t_.reset(t_);

        ana_.resize(bw_);
        ana_.initialize(t_,trig_t_);
        syn_.resize(bw_);

		legendre lgdr(bw_-1);		
		lgdr.evaluate_pmm(trig_t_);
		alf_.reset(t_,bw_-1);
		lgdr.evaluate(alf_,trig_t_);

    	check_error(d>3, "Derivative is implemented only up to order 3");
    	if(d>=1)
    	{
    		alfd1_.reset(t_,bw_-1);
			lgdr.evaluate_div(alfd1_,alf_);
    	}
    	if(d>=2)
    	{
    		alfd2_.reset(t_,bw_-1);
			lgdr.evaluate_div(alfd2_,alfd1_);    		
    	}
    	if(d==3)
    	{
    		alfd3_.reset(t_,bw_-1);
			lgdr.evaluate_div(alfd3_,alfd2_);    		
    	}
    	
    	PI=4.0*atan(1.0);
    	is_trig_lambda=false;
    }
    
    double output_lgdr(int i, int m, int l, legendre_multi_theta &p_)
	{
	 	double value;

	 	if(i<bw_)
		{
			return p_[i][m][l];
		}
		else
		{
			if((l-m)%2==0) return p_[(gsize_-1)-i][m][l];
			else return -p_[(gsize_-1)-i][m][l];
		}
	}
	
	void evaluate_trig_lambda()
	{
    	if(is_trig_lambda==false)
    	{
    		lmbd_.resize(gsize_);
			trig_lmd.resize(gsize_);	
			double dlam=2.0*PI/gsize_;
    		for(int kk=0;kk<gsize_;kk++)
			{
				lmbd_[kk]=kk*dlam;
				trig_lmd[kk].reset(bw_-1);
    			trig_lmd[kk].evaluate(lmbd_[kk]);
			}
			
			is_trig_lambda=true;
		}		
	}
   
    void destroy(){}

  public:

    explicit rsht_memo(int bw=0, int dd=0)
    {
        initialize(bw,dd);
    }

    /**
     *  Denstructor
     */

    ~rsht_memo(){}

    void resize(int bw=0, int dd=0)
    {
        if(bw_!=bw)initialize(bw,dd);
    }

    void forward(rshc &coef, mat<double>& data)
    {
    	ana_.analysis(coef,rfft_,alf_,data);
    }
    
    	int bw()
	{
		return bw_;
	}
	
	int maxDeg()
	{
		return bw_-1;
	}

    void inverse(mat<double>& data, rshc& coef, int dd=0)
    {
		if(dd==0)
		 {
		 	syn_.synthesis(data,rfft_,alf_,coef);
		 }
		 else if(dd==1)
		 {
		 	check_error(alfd1_.maxDeg()!=alf_.maxDeg(), "First order derivative not evaluated");
		 	syn_.synthesis(data,rfft_,alfd1_,coef);
		 }
		 else if(dd==2)
		 {
		 	check_error(alfd2_.maxDeg()!=alf_.maxDeg(), "Second order derivative not evaluated");
		 	syn_.synthesis(data,rfft_,alfd2_,coef);
		 }
		 else
		 {
		 	check_error(alfd3_.maxDeg()!=alf_.maxDeg(), "Third order derivative not evaluated");
		 	syn_.synthesis(data,rfft_,alfd3_,coef);
		 }
	}

    void inverse(double &data, int j, int k, rshc& coef, int dd=0)
    {
    	int kk,l,m;
			
		evaluate_trig_lambda();
		
		legendre_one_theta p_(bw_-1);
		 
		if(dd==0)
		{
		 	for(l=0;l<=bw_-1;l++)
		 	{
		 		p_[0][l]=output_lgdr(j,0,l,alf_);
			 	for(m=1;m<=l;m++)
			 	{
			 		p_[m][l]=output_lgdr(j,m,l,alf_);
				}		 		
			}

		 	syn_.synthesis(data,p_,trig_lmd[k],coef);
		 }
		 else if(dd==1)
		 {
		 	check_error(alfd1_.maxDeg()!=alf_.maxDeg(), "First order derivative not evaluated");
		 	
		 	for(l=0;l<=bw_-1;l++)
		 	{
		 		p_[0][l]=output_lgdr(j,0,l,alfd1_);
			 	for(m=1;m<=l;m++)
			 	{
			 		p_[m][l]=output_lgdr(j,m,l,alf_);
				}		 		
			}

		 	syn_.synthesis(data,p_,trig_lmd[k],coef);
		 }
		 else if(dd==2)
		 {
		 	check_error(alfd2_.maxDeg()!=alf_.maxDeg(), "Second order derivative not evaluated");
		 	
		 	for(l=0;l<=bw_-1;l++)
		 	{
		 		p_[0][l]=output_lgdr(j,0,l,alfd2_);
			 	for(m=1;m<=l;m++)
			 	{
			 		p_[m][l]=output_lgdr(j,m,l,alf_);
				}		 		
			}

		 	syn_.synthesis(data,p_,trig_lmd[k],coef);
		 }
		 else
		 {
		 	check_error(alfd3_.maxDeg()!=alf_.maxDeg(), "Third order derivative not evaluated");
		 	
		 	for(l=0;l<=bw_-1;l++)
		 	{
		 		p_[0][l]=output_lgdr(j,0,l,alfd3_);
			 	for(m=1;m<=l;m++)
			 	{
			 		p_[m][l]=output_lgdr(j,m,l,alf_);
				}		 		
			}

		 	syn_.synthesis(data,p_,trig_lmd[k],coef);
		 }
	}
	 
	double theta(int i)
	{
		if(i<bw_)return t_[i];
		else return PI-t_[(gsize_-1)-i];
	}
	
	double theta_c(int i)
	{
		if(i<bw_)return trig_t_.c[i];
		else return -trig_t_.c[(gsize_-1)-i];
	}

	double theta_s(int i)
	{
		if(i<bw_)return trig_t_.s[i];
		else return trig_t_.s[(gsize_-1)-i];
	}	
	
	double theta_csqr(int i)
	{
		if(i<bw_)return trig_t_.csqr[i];
		else return trig_t_.csqr[(gsize_-1)-i];
	}
	
	double theta_ssqr(int i)
	{
		if(i<bw_)return trig_t_.ssqr[i];
		else return trig_t_.ssqr[(gsize_-1)-i];
	}
	
	double theta_sinv(int i)
	{
		if(i<bw_)return trig_t_.sinv[i];
		else return trig_t_.sinv[(gsize_-1)-i];
	}
	
	double theta_sinvsqr(int i)
	{
		if(i<bw_)return trig_t_.sinvsqr[i];
		else return trig_t_.sinvsqr[(gsize_-1)-i];
	}

	double theta_ct(int i)
	{
		if(i<bw_)return trig_t_.ct[i];
		else return -trig_t_.ct[(gsize_-1)-i];
	}
	
	double theta_ctsqr(int i)
	{
		if(i<bw_)return trig_t_.ctsqr[i];
		else return -trig_t_.ctsqr[(gsize_-1)-i];
	}
	
	double lambda(int i)
	{
		evaluate_trig_lambda();
		return lmbd_[i];
	}	
	
	double lambda_cm(int i,int m)
	{
		evaluate_trig_lambda();
		return trig_lmd[i].cm[m];
	}
	
	double lambda_sm(int i,int m)
	{
		evaluate_trig_lambda();
		return trig_lmd[i].sm[m];
	}

	double lgdr(int i, int m, int l)
	{
		return output_lgdr(i,m,l,alf_);
	}
	
	double lgdr_div_1st(int i, int m, int l)
	{
		check_error(d<1, "First order derivative not evaluated");
		return output_lgdr(i,m,l,alfd1_);
	}
	
	double lgdr_div_2nd(int i, int m, int l)
	{
		check_error(d<2, "Second order derivative not evaluated");		
		return output_lgdr(i,m,l,alfd2_);
	}
	
	double lgdr_div_3rd(int i, int m, int l)
	{
		check_error(d<3, "Third order derivative not evaluated");		
		return output_lgdr(i,m,l,alfd3_);
	}
};

class rsht_fly
{
  private:

	double PI;
    int bw_;
    int gsize_;
    rfft rfft_;	

	rshana ana_;
	rshsyn syn_;
	
	vec<double>t_;
	legendre lgdr_;
	trig_multi_theta trig_t_;

    void initialize(int bw)
    { 
		PI=4.0*atan(1.0);
		
        bw_=bw;
        if(bw_==0)return;
        
        gsize_=2*bw_;
        rfft_.resize(gsize_);
		
		grid grd_("Gauss",gsize_,gsize_);
		t_.resize(bw_);
		grd_.latitude_GE0_to_theta_RAD(t_);
		trig_t_.reset(t_);

        ana_.resize(bw_);
        ana_.initialize(t_,trig_t_);
        syn_.resize(bw_);

		lgdr_.resize(bw_-1);		
		lgdr_.evaluate_pmm(trig_t_);
    }

    void destroy(){}

  public:

    explicit rsht_fly(int bw=0)
    {
        initialize(bw);
    }

    ~rsht_fly(){}

    void resize(int bw=0)
    {
        if(bw_!=bw)initialize(bw);
    }
    
	int bw()
	{
		return bw_;
	}
	
	int maxDeg()
	{
		return bw_-1;
	}

	double theta(int i)
	{
		if(i<bw_)return t_[i];
		else return PI-t_[(gsize_-1)-i];
	}
	
		double theta_c(int i)
	{
		if(i<bw_)return trig_t_.c[i];
		else return -trig_t_.c[(gsize_-1)-i];
	}

	double theta_s(int i)
	{
		if(i<bw_)return trig_t_.s[i];
		else return trig_t_.s[(gsize_-1)-i];
	}	
	
	double theta_csqr(int i)
	{
		if(i<bw_)return trig_t_.csqr[i];
		else return trig_t_.csqr[(gsize_-1)-i];
	}
	
	double theta_ssqr(int i)
	{
		if(i<bw_)return trig_t_.ssqr[i];
		else return trig_t_.ssqr[(gsize_-1)-i];
	}
	
	double theta_sinv(int i)
	{
		if(i<bw_)return trig_t_.sinv[i];
		else return trig_t_.sinv[(gsize_-1)-i];
	}
	
	double theta_sinvsqr(int i)
	{
		if(i<bw_)return trig_t_.sinvsqr[i];
		else return trig_t_.sinvsqr[(gsize_-1)-i];
	}

	double theta_ct(int i)
	{
		if(i<bw_)return trig_t_.ct[i];
		else return -trig_t_.ct[(gsize_-1)-i];
	}
	
	double theta_ctsqr(int i)
	{
		if(i<bw_)return trig_t_.ctsqr[i];
		else return -trig_t_.ctsqr[(gsize_-1)-i];
	}
	

    void forward(rshc &coef, mat<double>& data)
    {
 		ana_.analysis(coef,rfft_,lgdr_,trig_t_,data);
    }

    void inverse(mat<double>& data, rshc& coef, int d=0)
    {
    	syn_.synthesis(data,rfft_,lgdr_,trig_t_,coef,d);
	}
	
    void inverse(double& data, double theta, double lambda, rshc& coef, int d=0)
    {
    	syn_.synthesis(data,lgdr_,theta,lambda,coef,d);
	}
};

#endif
