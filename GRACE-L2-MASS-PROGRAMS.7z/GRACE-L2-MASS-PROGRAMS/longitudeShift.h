//Copyright: Jun-Yi Guo

#ifndef grid_conv_h
#define grid_conv_h

#include <iostream>
#include <fstream>
#include <string>

#include "fftpack++.h"

class longitudeShift
{
  private:

    enum {rmShift, addShift}shiftType_;

    int numLat_;
    int numLon_;
    
    int numFil_;
    
    ifstream ctr;

    double latVal;
    vec<double> source;
    vec<double> result;
    vec<double> preResult;

    string cfile_;
    string ifile_;
    string ofile_;
    
    rfs for_;
    rfs back_; 
    
    ifstream in;
    ofstream out;

    void initialize()
    {
        string stmp;
        
        // read shift type
        
        ctr>>stmp;
        check_error(stmp!="rmShift"&&stmp!="addShift", "Wrong shift type");
        
        if(stmp=="rmShift")
        {
            shiftType_=rmShift;
        }
        else
        {
            shiftType_=addShift;    
        }
        
        // read grid numbers  and initialize array and fft size
        
        ctr>>numLat_;
        ctr>>numLon_;
        
        source.resize(numLon_);
        result.resize(numLon_);
        preResult.resize(2*numLon_);

        for_.resize(numLon_);
        back_.resize(2*numLon_);

       // read input and output data file names 
        
        ctr>>numFil_;
    }

    void read()
    {
        int k;
        double dtmp;
        
        double tlon,dlon;

        double tol=1.0e-2;


        // compute longitude interval, will be used to check
        // if the grid in data file is correct

        dlon=360.0/numLon_;

        // read original data
        
        switch(shiftType_)
        { 
          case rmShift:
 
            for(k=0;k<numLon_;k++)
            {
                in>>dtmp;
                if(k>0)check_error(fabs(dtmp-latVal)>tol, "Error in source data file"); 
                latVal=dtmp;

                in>>tlon;
                check_error(fabs(tlon-(k+0.5)*360.0/numLon_)/dlon>tol, "Error in source data file"); 
                in>>source[k];
            }
                          
            break;

          case addShift:

            for(k=0;k<numLon_;k++)
            {
                in>>dtmp;
                if(k>0)check_error(fabs(dtmp-latVal)>tol, "Error in source data file"); 
                latVal=dtmp;

                in>>tlon;
                check_error(fabs(tlon-k*360.0/numLon_)>tol, "Error in source data file"); 
                in>>source[k];
            }

            break;
        }
    }

    void conv()
    {
        int k;

        for_.forward(source);
        for(k=0;k<numLon_;k++)preResult[k]=source[k];
        for(k=numLon_;k<2*numLon_;k++)preResult[k]=0.0;
        
        back_.inverse(preResult);

        switch(shiftType_)
        { 
          case rmShift:
          
            result[0]=preResult[2*numLon_-1];
            for(k=1;k<numLon_;k++)result[k]=preResult[2*k-1];
            
            break;
            
          case addShift:
               
            for(k=0;k<numLon_;k++)result[k]=preResult[2*k+1];
            
            break;
        }
    }

    void output()
    {
        int k;
    
        switch(shiftType_)
        { 
          case rmShift:

            for(k=0;k<numLon_;k++)
            {
                out<<latVal<<"  "
                   <<k*360.0/numLon_<<"   "
                   <<result[k]<<endl;                    
            }           
            break;

          case addShift:
               
            for(k=0;k<numLon_;k++)
            {
                out<<latVal<<"  "
                   <<(k+0.5)*360.0/numLon_<<"   "
                   <<result[k]<<endl;                    
            }
            break;
        }
    }

    void perform(string cfile)
    {
        if(cfile!="0")
        {       
            cfile_=cfile;
            
            ctr.open(cfile_.c_str());
            check_error(!ctr.is_open(),"Input file not opened");

            initialize();
           
            for(int k=0;k<numFil_;k++)
            {
            
                ctr>>ifile_;
                ctr>>ofile_;
                check_error(ifile_==ofile_,"Input and output files must be different");
                 
                in.open(ifile_.c_str());
                check_error(!in.is_open(),"Input file not opened");
                
                out.open(ofile_.c_str());
                out.precision(15);
    
                for(int i=0;i<numLat_;i++)
                {
                    read();
                    conv();
                    output();
                }
                
                in.close();
                out.close();
                
                cout<<k<<"  "<<ifile_<<"   "<<ofile_<<endl<<flush;
            }
            ctr.close();
        }
        else
        {
             cout<<"No input file is asignedf"<<endl;
        }
    }

  public:

    explicit longitudeShift(string cfile="0")
    {
        perform(cfile);
    }

    ~longitudeShift(){}

    void convert(string cfile="0")
    {
        perform(cfile);
    }
};

#endif
