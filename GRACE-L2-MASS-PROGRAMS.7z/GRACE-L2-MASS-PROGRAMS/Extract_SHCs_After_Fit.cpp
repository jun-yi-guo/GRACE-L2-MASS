//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <cmath>

#include "rshc.h"

using namespace std;

int main()
{
    int i,j,k,numPoly,numSin,num,numGri,numAttr,Deg;
    double dtmp;
    
    string ifile, tfile, cfile, sfile, type;
    string tfile_attr, cfile_attr, sfile_attr;

    char tmp[1024];

    ifstream input("Extract_SHCs_After_Fit.txt");

    input>>ifile;
    input>>numPoly;
    for(i=0;i<numPoly;i++)input>>dtmp;
    input>>numSin;
    for(i=0;i<numSin;i++)input>>dtmp;    
    input>>type;
    input>>num;
    if(type=="polynomial")
    {
        input>>tfile;
        input>>tfile_attr;
        cfile="NULL";
        sfile="NULL";
        cfile_attr="NULL";
        sfile_attr="NULL";
    }
    else if(type=="sinusoid")
    {
        input>>cfile;
        input>>sfile; 
		input>>cfile_attr;
        input>>sfile_attr;  
        tfile="NULL";
        tfile_attr="NULL";      
    }
    else
    {
         cerr<<"must be 'polynomial' or 'sinusoid'"<<endl;
         system("pause");
         exit(0);    
    }
     
    input.close();
    
    ifstream in(ifile.c_str());

    for(i=0;i<20;i++)in.getline(tmp,1024);
    in>>numGri;
    in>>numAttr;
    Deg=floor(sqrt(numGri))-1;
    if((Deg+1)*(Deg+2)!=numGri)
    {
        cerr<<"Error in data file: number of coefficients"<<endl;
        exit(0);
    }
    
    char attr;
    int l,m;
    
    if(type=="polynomial")
    {
        rshc coeTre(Deg);
        
        ofstream t_attr(tfile_attr.c_str());
        t_attr.precision(16);
        
        for(j=0;j<numGri;j++)
        {
            in>>attr;
            in>>l;
            in>>m;
            for(i=0;i<num-1;i++)in>>dtmp;
            
            if(attr=='c')
			{
				in>>coeTre.c(m,l);
				t_attr<<attr<<"  "<<l<<"  "<<m<<"  "<<coeTre.c(m,l)<<endl;
			}
            else 
			{
				in>>coeTre.s(m,l);
				t_attr<<attr<<"  "<<l<<"  "<<m<<"  "<<coeTre.s(m,l)<<endl;
			}
			
            
            for(i=0;i<numPoly-num;i++)in>>dtmp;
            for(i=0;i<2*numSin;i++)in>>dtmp;
            for(i=0;i<numPoly+2*numSin;i++)in>>dtmp;
            in>>dtmp;
            in>>dtmp;
        }
        coeTre.output_s0(tfile.c_str(),16);     
		t_attr.close();           
    }
    else
    {
        rshc coeCos(Deg);
        rshc coeSin(Deg);   

		ofstream c_attr(cfile_attr.c_str());
		ofstream s_attr(sfile_attr.c_str()); 
		c_attr.precision(16);
		s_attr.precision(16);
           
        for(j=0;j<numGri;j++)
        {
            in>>attr;
            in>>l;
            in>>m;
            
            for(i=0;i<numPoly;i++)in>>dtmp;
            for(i=0;i<num-1;i++)
            {
               in>>dtmp;
               in>>dtmp;
            }
            if(attr=='c')
            {
                in>>coeCos.c(m,l);
                in>>coeSin.c(m,l);
                
                c_attr<<attr<<"  "<<l<<"  "<<m<<"  "<<coeCos.c(m,l)<<endl;
                s_attr<<attr<<"  "<<l<<"  "<<m<<"  "<<coeSin.c(m,l)<<endl;
            }
            else
            {
                in>>coeCos.s(m,l);
                in>>coeSin.s(m,l);
                
                c_attr<<attr<<"  "<<l<<"  "<<m<<"  "<<coeCos.s(m,l)<<endl;
                s_attr<<attr<<"  "<<l<<"  "<<m<<"  "<<coeSin.s(m,l)<<endl;                
            }
            
            for(i=0;i<2*(numSin-num);i++)in>>dtmp;
            for(i=0;i<numPoly+2*numSin;i++)in>>dtmp;
            in>>dtmp;
            in>>dtmp;            
        }
        
        coeCos.output_s0(cfile.c_str(),15);
        coeSin.output_s0(sfile.c_str(),15);  
		
		c_attr.close();
		s_attr.close();        
    }

    in.close();
    
 //   system("pause");
    return 0;
}
