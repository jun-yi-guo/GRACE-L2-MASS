#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <fstream>
#include <string>  
#include <sstream>
#include <iomanip>

#include "check_error.h" 
#include "vec.h"
#include "mat.h"
#include "grid.h" 
#include "rsht.h" 

#include "mat_lower_triangle.h"

using namespace std;

int main(int argc,char *argv[])
{ 
	int i,j,k,l,m,n,p,q,itmp;
	double dtmp;

	//4 pi G/g_R
	double PI=4.0*atan(1.0);
	double G=6.6742e-11; 
	double GM=3.986005e+14;
	
	ifstream ctl("Mass_Corrected_Asphericity.txt");	
	
	double R,gR,coef;
	
	ctl>>R;
	gR=GM/(R*R);
	coef=4*PI*G/gR;	
	
	int bw_topo;
	string ifile_topo;	
	
	ctl>>bw_topo;
	ctl>>ifile_topo;
	
	int maxDeg_topo=bw_topo-1;
	int numlat_topo=2*bw_topo, numlon_topo=2*bw_topo;

	int bw_mass;
	int num_mass;
	
	ctl>>bw_mass;
	ctl>>num_mass;	
	
	int maxDeg_mass=bw_mass-1;
	int numlat_mass=2*bw_mass, numlon_mass=2*bw_mass;

	vec<string> ifile_mass(num_mass),ofile_mass(num_mass); 
	for(i=0;i<num_mass;i++)
	{
		ctl>>ifile_mass[i];
		ctl>>ofile_mass[i];
	}

	ctl.close();

	mat_lower_triangle<rshc> delta_k_qp(bw_mass);
	mat_lower_triangle<rshc> delta_k_qm(bw_mass);
	
	for(p=0;p<=maxDeg_mass;p++)
	for(q=0;q<=p;q++)
	{
		delta_k_qp[p][q].resize(maxDeg_mass);
		delta_k_qm[p][q].resize(maxDeg_mass);
	}
	
	cout<<"Pre-camputation ..."<<endl;
	{
		mat<double> epsilon(numlat_topo,numlon_topo);
		grid grd_topo("Gauss",numlat_topo,numlon_topo);
		grd_topo.input(ifile_topo,epsilon);
		epsilon/=R;
	
		rsht_memo rsht(bw_topo);
		rshc SHCsp(maxDeg_topo),SHCsm(maxDeg_topo);	
		
		vec<double> theta(2*bw_topo);
		for(int j=0;j<2*bw_topo;j++)
			theta[j]=rsht.theta(j);
	
		mat<double>lambda_sin(2*bw_topo,bw_topo),lambda_cos(2*bw_topo,bw_topo);
		for(int k=0;k<2*bw_topo;k++)
		for(int m=0;m<=maxDeg_topo;m++)	
		{
			lambda_sin[k][m]=rsht.lambda_sm(k,m);
			lambda_cos[k][m]=rsht.lambda_cm(k,m);
		}
	
		legendre_multi_theta alf(theta,maxDeg_topo);
		alf.setNormType(legendre_multi_theta::CplxFull);
		for(int n=0;n<=maxDeg_topo;n++)
		for(int k=0;k<=n;k++)
		for(int j=0;j<2*bw_topo;j++)
			alf[j][k][n]=rsht.lgdr(j,k,n);
		alf.toRealFull();
	
		mat<double> delta_k(numlat_topo,numlon_topo);
	
		for(int p=0;p<=maxDeg_mass;p++)
		for(int q=0;q<=p;q++)
		{
			if(q%10==0)cout<<"doing degree p="<<p<<" and order q="<<q<<"   "<<endl;
	
			// q positive, cos 
			for(int j=0;j<2*bw_topo;j++)
			for(int k=0;k<2*bw_topo;k++)
				delta_k[j][k]=(pow(1.0+epsilon[j][k],p+2)-1.0)*alf[j][q][p]*lambda_cos[k][q]/(2.0*p+1.0);
	
			SHCsp.setNormType(rshc::CplxFull);
			rsht.forward(SHCsp,delta_k);
			SHCsp.toRealFull();
	
			for(int n=0;n<=maxDeg_mass;n++)
			{
				dtmp=2.0*n+1.0;
				for(int k=0;k<=n;k++)
				{
					delta_k_qp[p][q].c(k,n)=SHCsp.c(k,n)*dtmp;
					delta_k_qp[p][q].s(k,n)=SHCsp.s(k,n)*dtmp;
				}		
			}
	
			// q negative, sin 
			for(int j=0;j<2*bw_topo;j++)
			for(int k=0;k<2*bw_topo;k++)
				delta_k[j][k]=(pow(1.0+epsilon[j][k],p+2)-1.0)*alf[j][q][p]*lambda_sin[k][q]/(2.0*p+1.0);
			
			SHCsm.setNormType(rshc::CplxFull);
			rsht.forward(SHCsm,delta_k);
			SHCsm.toRealFull();
	
			for(int n=0;n<=maxDeg_mass;n++)
			{
				dtmp=2.0*n+1.0;
				for(int k=0;k<=n;k++)
				{
					delta_k_qm[p][q].c(k,n)=SHCsm.c(k,n)*dtmp;
					delta_k_qm[p][q].s(k,n)=SHCsm.s(k,n)*dtmp;
				}			
			}
		}
	}	
		
	cout<<"Calculating correction"<<endl;
	mat<double> mass0(numlat_mass,numlon_mass),mass(numlat_mass,numlon_mass);
	grid grd_mass("Gauss",numlat_mass,numlon_mass);

	rsht_memo rsht(bw_mass);
	rshc SHCm0(maxDeg_mass),SHCm_1(maxDeg_mass),SHCm_t(maxDeg_mass);	

	for(i=0;i<num_mass;i++)
	{
		grd_mass.input(ifile_mass[i],mass0);
		SHCm0.setNormType(rshc::CplxFull);
		rsht.forward(SHCm0,mass0);
		SHCm0.toRealFull();
		
		SHCm_1.setNormType(rshc::RealFull);
		SHCm_t.setNormType(rshc::RealFull);
	
		double dtmp_c,dtmp_s,dtmp_nc,dtmp_ns;
	
		for(p=0;p<=maxDeg_mass;p++)
		{       
			dtmp=coef/(2.0*p+1.0);
			for(q=0;q<=p;q++)
			{
				SHCm0.c(q,p)*=dtmp;
				SHCm0.s(q,p)*=dtmp;
			}		
		}
	
	 	//approximate
	 	for(p=0;p<bw_mass;p++)
		{
			dtmp=(2.0*p+1.0)/coef;
			for(q=0;q<=p;q++)
			{
				SHCm_1.c(q,p)=SHCm0.c(q,p)*dtmp;
				SHCm_1.s(q,p)=SHCm0.s(q,p)*dtmp;
	
				dtmp_c=0.0;
				dtmp_s=0.0;		
				for(n=0;n<bw_mass;n++)
				for(k=0;k<=n;k++)
				{
					dtmp_c+=SHCm0.c(k,n)*delta_k_qp[p][q].c(k,n)+SHCm0.s(k,n)*delta_k_qp[p][q].s(k,n);
					dtmp_s+=SHCm0.c(k,n)*delta_k_qm[p][q].c(k,n)+SHCm0.s(k,n)*delta_k_qm[p][q].s(k,n);
				}
	
				SHCm_1.c(q,p)-=dtmp*dtmp_c;
				SHCm_1.s(q,p)-=dtmp*dtmp_s;
			}
	 	}
	
	  	for(int iter=0;iter<5;iter++)
		{
		 	for(p=0;p<bw_mass;p++)
			{
				dtmp=(2.0*p+1.0)/coef;
				for(q=0;q<=p;q++)
				{
					SHCm_t.c(q,p)=SHCm0.c(q,p)*dtmp;
					SHCm_t.s(q,p)=SHCm0.s(q,p)*dtmp;
		
					dtmp_c=0.0;
					dtmp_s=0.0;		
					for(n=0;n<bw_mass;n++)
					{
						dtmp_nc=0.0;
						dtmp_ns=0.0;
						for(k=0;k<=n;k++)
						{
							dtmp_nc+=SHCm_1.c(k,n)*delta_k_qp[p][q].c(k,n)+SHCm_1.s(k,n)*delta_k_qp[p][q].s(k,n);
							dtmp_ns+=SHCm_1.c(k,n)*delta_k_qm[p][q].c(k,n)+SHCm_1.s(k,n)*delta_k_qm[p][q].s(k,n);
						}
						dtmp_c+=dtmp_nc/(2.0*n+1.0);
						dtmp_s+=dtmp_ns/(2.0*n+1.0);
					}
		
					SHCm_t.c(q,p)-=dtmp_c*(2.0*p+1.0);
					SHCm_t.s(q,p)-=dtmp_s*(2.0*p+1.0);		
				}
		 	}
		 	
		 	SHCm_1=SHCm_t;
		}
	
		SHCm_t.toCplxFull();
		rsht.inverse(mass,SHCm_t);
		grd_mass.output(ofile_mass[i],mass);
		
		cout<<i+1<<" out of "<<num_mass<<" done"<<endl;
	}

	return 0;
}
