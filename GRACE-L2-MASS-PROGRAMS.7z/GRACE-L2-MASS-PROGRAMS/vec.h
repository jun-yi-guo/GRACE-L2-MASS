// File name: vec.h
// Copyright: Junyi Guo
// Author: Junyi Guo
// Created on April 18, 2001
// Modified on September 3, 2002
// Modified on January 26, 2004
// Bug fixed on July 20, 2004
// Modified for fft package on Juin 11, 2006
// Modified to permit arbitrary index for firast element
// on April 26, 2016

#ifndef vec_h
#define vec_h

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <complex>

#include "check_error.h"

using namespace std;

    /**
     *  This is a numerical Vec class templated. It is considered
     *  to be a colunm Vec. C-style indexing is used. The \em i - th
     *  element of a Vec object \em v can be accessed using \em v[i]. 
     *  The first element is \em v[0]. Bound check is not performed.
     */

template<class T>
class vec
{

  private:

    T *v_;
    int n_;
    int nl_,nh_;
    
    bool is_subvec;

    void initialize(int n)
    {
    	check_error(n<0,"The size of a vec object can not be negative");

		if(n!=0)
		{
			initialize(0,n-1);
 	    }
 	    else
 	    {
	    	n_=0;		
		    nl_=0;
		    nh_=-1;   	    	 	    	
			is_subvec=false;
		}

    }
    
    void initialize(int nl,int nh)
    {
    	check_error(nh<nl,"Higher index cannot be smaller than lower index");
       
        n_=nh-nl+1;
        nl_=nl;
        nh_=nh;
		        
        v_=new(std::nothrow)T[n_];
        check_error(v_==NULL, "not enough menory");

        v_-=nl_;
        is_subvec=false;
    }
            
    void destroy()
    {
        if(n_==0)return;
        if(is_subvec==false)delete[](v_+nl_);
    }

  public:

    /**
     * The default constructor. The object thus constructed has no element,
     * i.e. the size of the object is zero.
     */

    vec()
    {
        initialize(0);
    }

    /**
     * Create a \em vec object having \em n elements. The values of
     * ther elements are un-specified.
     */
         
    explicit vec(int n)
    {
        initialize(n);
    }

    explicit vec(int nl,int nh)
    {
        initialize(nl,nh);
    }
    
    /** 
     * The copy constructor. Deep copy is assumed.
     */
     
    vec(const vec<T>& x)
    {
        initialize(x.nl_,x.nh_);
        for(int i=nl_;i<=nh_;i++)v_[i]=x[i];
    }

	vec(vec<T>& x, int n1x, int n2x, int n1new, int n2new)
	{
		initialize(0);
		set_sub_vec(x,n1x,n2x,n1new,n2new);
	}

    /**
     * The destructor.
     */ 
         
    ~vec()
    {
        destroy();
    }

	void set_sub_vec(vec<T>& x, int n1x, int n2x, int n1new, int n2new)
	{
		if(is_subvec==false)check_error(n_!=0, "only an empty vector can be used as sub-vector");
		check_error(n1x<x.nl_||n2x>x.nh_, "sub-vector index outside permissible range");
		check_error(n2new-n1new!=n2x-n1x, "sub-vector old and new index ranges not compatible");
		
		v_=x.v_+(n1x-n1new);  
		
		n_=n2x-n1x+1;		
		nl_=n1new;
		nh_=n2new;

		is_subvec=true;
	}

    /**
     * Convert the object to a primitive C array. This
     * permmits to pass a vec object as pointer parameter
     * to a C function (index range remains nl_ to nh+).
     */
         
    T* ptr() const
    {
        return v_+nl_;
    }

    /**
     * Return the size of the object, i.e. the number of
     * elements of the object.
     */ 
         
    int size() const
    {
        return n_;
    }   

    int lower_index() const
    {
        return nl_;
    }   

    int higher_index() const
    {
        return nh_;
    }   
    
    /**
     * Change the size of the object to \em n, i.e. to make it
     * have \em n elements. The defaut value is set to be zero.
     * The original data are destructed.
     */

    void resize(int n=0)
    {
        if(n_!=n||is_subvec==true)
        {
            destroy();
            initialize(n);
        }
        else
        {
        	nl_=0;
        	nh_=n-1;
        }
    }
    
    void resize(int nl,int nh)
    {
		if(n_!=nh-nl+1||is_subvec==true)
        {
	        destroy();
	        initialize(nl,nh);        		
		}
        else
        {
            nl_=nl;
            nh_=nh;
		}
    }

    /**
     * evaluate the elements values of the object with
     * the corresponding elements of the primitive C array. The result is not
     * defined if the length of \em v is smaller.
     */
         
    void evaluate(char *s)
    {
        istringstream ins(s);
        for(int i=nl_;i<=nh_;i++)ins>>v_[i];
    }
    
    /**
     * evaluate the elements values of the object with
     * the corresponding elements of the primitive C array. The result is not
     * defined if the length of \em v is smaller.
     */

    void evaluate(const T* v)
    {
        for(int i=0;i<n_;i++)v_[i+nl_]=v[i];
    }

    /**
     * Evaluate to this object the object \em x of different element data
     * type. If the data type of this object is \em T, and the data
     * type of the object \em x is \em T1, the automatic conversion
     * from \em T1 to \em T is required. Otherwise the behavior is
     * unspecified.
     */

    template<class T1>void convert(const vec<T1>& x)
    {
        check_error(n_!=x.size(),"Sizes of vecs are different");
        
        int nlx=x.lower_index();

        for(int i=0;i<n_;i++)v_[i+nl_]=static_cast<T>(x[i+nlx]);
    }

    /** 
     * Element accessing using [].	No bound check is made. 
     */
         
    T& operator[](int i)
    {
        return v_[i];
    }

    /** 
     * Element accessing using [].	No bound check is made. 
     */
         
    const T& operator[](int i) const
    {
        return v_[i];
    }

    /**
     * The \em rv is assigned to \em lv. The sizes of \em rv and
     * of \em lv should be equal.
     */
         
    vec<T>& operator=(const vec<T>& x)
    {
        if(this==&x)return *this;
        check_error(n_!=x.n_,"Sizes of vecs are different");
        int nlx=x.lower_index();
        for(int i=0;i<n_;i++)v_[i+nl_]=x[i+nlx];
        return *this;
    }

    /**
     * evaluate all element of the present object with \em a
     */
         
    vec<T>& operator=(const T& a)
    {
        for(int i=nl_;i<=nh_;i++)v_[i]=a;
        return *this;
    }

    /** 
     * The unitary + operator. Add the \em rv to the object. 
     */
         
    vec<T>& operator+=(const vec<T>& x)
    {
        check_error(n_!=x.n_,"Sizes of vecs are different");
        int nlx=x.lower_index();
        for(int i=0;i<n_;i++)v_[i+nl_]+=x.v_[i+nlx];
        return *this;
    }
    
    /**
     * The unitary + operator. Add the \em rv to every element
     * of the object.
     */
         
    vec<T>& operator+=(const T& a)
    {
        for(int i=nl_;i<=nh_;i++)v_[i]+=a;
        return *this;
    }
    
    /** 
     * The unitary - operator. Substract the \em rv from the object. 
     */
         
    vec<T>& operator-=(const vec<T>& x)
    {
        check_error(n_!=x.n_,"Sizes of vecs are different");
        int nlx=x.lower_index();
        for(int i=0;i<n_;i++)v_[i+nl_]-=x.v_[i+nlx];
        return *this;
    }
    
    /**
     * The unitary - operator. Substract the \em rv from every
     * element of the object.
     */
         
    vec<T>& operator-=(const T& a)
    {
        for(int i=nl_;i<=nh_;i++)v_[i]-=a;
        return *this;
    }
    
    /**
     * The unitary * operator. Multiply the \em rv to the object
     * element by element.
     */
         
    vec<T>& operator*=(const vec<T>& x)
    {
        check_error(n_!=x.n_,"Sizes of vecs are different");
        int nlx=x.lower_index();
        for(int i=0;i<n_;i++)v_[i+nl_]*=x.v_[i+nlx];
        return *this;
    }
    
    /**
     * The unitary * operator. Multiply the \em rv to every
     * element of the object.
     */
         
    vec<T>& operator*=(const T& a)
    {
        for(int i=nl_;i<=nh_;i++)v_[i]*=a;
        return *this;
    }
    
    /**
     * The unitary / operator. Devide every element the object
     * the corresponding element of the \em rv.
     */
         
    vec<T>& operator/=(const vec<T>& x)
    {
        check_error(n_!=x.n_,"Sizes of vecs are different");
        int nlx=x.lower_index();
        for(int i=0;i<n_;i++)v_[i+nl_]/=x.v_[i+nlx];
        return *this;
    }
    
    /**
     * The unitary / operator. Devide every element of the
     * object by the \em rv.
     */
         
    vec<T>& operator/=(const T& a)
    {
        for(int i=nl_;i<=nh_;i++)v_[i]/=a;
        return *this;
    }

};//class vec

    /** \relates vec
     * The unitary + operator 
     */
     
template<class T>vec<T>& operator+(vec<T>& x)
{
    return x;
}

    /** \relates vec
     * The binary + operator. 
     */
     
template<class T>vec<T> operator+(const vec<T>& x, const vec<T>& y)
{
    check_error(x.size()!=y.size(),"Size of vecs are different");
    vec<T> b(x);
    b+=y;
    return b;
}

    /** \relates vec
     * Add \em a to every element of \em x. 
     */
     
template<class T>vec<T> operator+(const vec<T>& x, const T& a)
{
    vec<T> b(x);
    b+=a;
    return b;
}

    /** \relates vec
     * Add \em a to every element of \em x. 
     */
     
template<class T>vec<T> operator+(const T& a, const vec<T>& x)
{
    return x+a;
}

    /** \relates vec
     * The unitary - operator. 
     */
     
template<class T>vec<T> operator-(const vec<T>& x)
{
	int nl=x.lower_index();
	int nh=x.higher_index();
    vec<T> b(nl,nh);
    for(int i=nl;i<=nh;i++)b[i]=-x[i];
    return b;
}

    /** \relates vec
     * The binary - operator. 
     */
     
template<class T>vec<T> operator-(const vec<T>& x, const vec<T>& y)
{
    check_error(x.size()!=y.size(),"Size of vecs are different");
    vec<T> b(x);
    b-=y;
    return b;
}

    /** \relates vec
     * Substract \em a from every element of \em x. 
     */
     
template<class T>vec<T> operator-(const vec<T>& x, const T& a)
{
    vec<T> b(x);
    b-=a;
    return b;
}

    /** \relates vec
     * Substract from \em a every element of \em x. 
     */
     
template<class T>vec<T> operator-(const T& a, const vec<T>& x)
{
    vec<T> b(x.size());
    b=a;
    int n=b.size();
    for(int i=0;i<n;i++)b[i]-=x[i];
    return b;
}

    /** \relates vec
     * Elementwise multiplication. 
     */
     
template<class T>vec<T> operator*(const vec<T>& x, const vec<T>& y)
{
    check_error(x.size()!=y.size(),"Size of vecs are different");
    vec<T> b(x);
    b*=y;
    return b;
}

    /** \relates vec
     * The binary * operator. 
     */
     
template<class T>vec<T> operator*(const vec<T>& x, const T& a)
{
    vec<T> b(x);
    b*=a;
    return b;
}

    /** \relates vec
     * The binary * operator. 
     */
     
template<class T>vec<T>operator*(const T& a, const vec<T>& x)
{
    return x*a;
}

    /** \relates vec
     * Elementwise division. 
     */
     
template<class T>vec<T> operator/(const vec<T>& x, const vec<T>& y)
{
    check_error(x.size()!=y.size(),"Size of vecs are different");
    vec<T> b(x);
    b/=y;
    return b;
}

    /** \relates vec
     * The binary / operator. 
     */
     
template<class T>vec<T> operator/(const vec<T>& x, const T& a)
{
    vec<T> b(x);
    b/=a;
    return b;
}

    /** \relates vec
     * Divide \em a with every element of \em x. 
     */
     
template<class T>vec<T> operator/(const T& a, const vec<T>& x)
{
	int nl=x.lower_index();
	int nh=x.higher_index();
    vec<T> b(nl,nh);
    b=a;
    for(int i=nl;i<=nh;i++)b[i]/=x[i];
    return b;
}

    /** \relates vec
     * The binary == operator. 
     */
     
template<class T>bool operator==(const vec<T>& x, const vec<T>& y)
{
    if(x.size()!=y.size())return false;
    int nlx=x.lower();
    int nly=y.lower_index();
	int n=x.size(); 
    for(int i=0;i<n;i++)if(x[i+nlx]!=y[i+nly])return false;
    return true;
}

    /** \relates vec
     * The binary != operator. 
     */
     
template<class T>bool operator!=(const vec<T>& x, const vec<T>& y)
{
    return !(x==y);
}

    /** \relates vec
     * Return the dot product of \em x and \em y. 
     */
     
template<class T>T dotProd(const vec<T>& x, const vec<T>& y)
{
    check_error(x.size()==y.size(),"Size of vecs are different");
    int n=x.size();
    int nlx=x.lower_index();
    int nly=y.lower_index();
    T e=0;
    for(int i=0;i<n;i++)e+=x[i+nlx]*y[i+nly];
    return e;
}

    /**\relates vec
     * Return the cross product of \em x and \em y. Both \em x and \em y
     * must be of size 3.
     */
     
template<class T>vec<T> crossProd(const vec<T>& x, const vec<T>& y)
{
    check_error(x.size()==3&&y.size()==3,"Size of vecs must be 3");
    int nlx=x.lower_index();
    int nly=y.lower_index();
    vec<T> b(3);
    b[0]=x[1+nlx]*y[2+nly]-x[2+nlx]*y[1+nly];
    b[1]=x[2+nlx]*y[0+nly]-x[0+nlx]*y[2+nly];
    b[2]=x[0+nlx]*y[1+nly]-x[1+nlx]*y[0+nly];
    return b;
}

    /**\relates vec
     * Write the vec to an output stream. The sequence is: size,
     * and then element by element.
     */
     
template<class T>std::ostream& operator<<(std::ostream& s, const vec<T>& x)
{
    int nl=x.lower_index();
    int nh=x.higher_index();
    int size=x.size();
    s<<size<<std::endl;
    for(int i=nl;i<=nh;i++)s<<x[i]<<"  "<<std::endl;
    return s;
}
    
    /**\relates vec
     * Read the vec from a input stream. The sequence is: size,
     * and then element by element.
     */	
     
template<class T>std::istream& operator>>(std::istream& s, vec<T>& x)
{
    int size;
    s>>size;
    if(size!=x.size())x.resize(size);
    int nl=x.lower_index();
    int nh=x.higher_index();
    for(int i=nl;i<=nh;i++)s>>x[i];
    return s;
}
      
#endif // vec_h

//eof(vec.h)
