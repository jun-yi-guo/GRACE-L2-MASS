//Copyright: Jun-Yi Guo

#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>

using namespace std;

int main()
{
	int i,j,numLat,numLon,numFile;

    string ifile1, ifile2, ofile;
    
    double lat0, lon0, lat, lon, diff, mass1, mass2;
    
    double tol=1.0e-3;

 	ifstream input("Extract_Region.txt");

    input>>numLat;
    input>>numLon;
    
	input>>numFile;

    ifstream in1,in2;
    ofstream out;

    for(i=0;i<numFile;i++)
    {
        input>>ifile1;
        input>>ifile2;
        input>>ofile;
        
        in1.open(ifile1.c_str());
        in2.open(ifile2.c_str());
        out.open(ofile.c_str());
        out.precision(16);
        
        for(j=0;j<numLat*numLon;j++)
        {                              
             in1>>lat0;
             in1>>lon0;
             in1>>mass1;   
             
             in2>>lat;
             in2>>lon;
             in2>>mass2;   
             
             if(fabs(lat-lat0)>tol||fabs(lon-lon0)>tol)
             {
                 cout<<"Error in data file: Grid different"<<endl;
                 return 0;    
             }
             
             if(mass2==0)mass1=0.0;    
             
             out<<lat<<"   "<<lon<<"   "<<mass1<<endl;         
        }

        out.close();
        in1.close();
        in2.close();

        cout<<i+1<<" over "<<numFile<<" done."<<endl; 
    }

//    system("pause");

	return 0; 
}
