//Copyright: Jun-Yi Guo

#ifndef slc_ocwe_h
#define slc_ocwe_h

#include <cstdlib>
#include <fstream>
#include <string>
#include <cmath>

#include "rsht.h"

using namespace std;

class slc_ocwe
{
  private:
  
    string ifile_;
    string rot_switch;
    
    string prbDesc_;
    
    int bw_;
    int size_;
    
    double tol_;
    
    double R;
    double rho_E;
    double J2;
    double mgr;
    double k2bt;
    double h2bt;
    double l2bt;
    
    double c13,c23,c33,m1,m2,m3,c20p,c21p,s21p;

    double rho_w;

    double mass_o;
    double area_o;

    vec<double>lat;
    vec<double>lon;
    
    mat<int>ocean;
    mat<int>source;
    
    mat<double>mass0;
    
    mat<double>mass;
    mat<double>geoid;
    mat<double>vert;
    mat<double>east;
    mat<double>south;

    vec<double>hn;
    vec<double>ln;
    vec<double>kn;

    rshc smass0;
    rshc sother;

    rsht_memo sphTrans;

    void initialize()
    {
        size_=2*bw_;

        lat.resize(size_);
        lon.resize(size_);
        
        ocean.resize(size_,size_);
        source.resize(size_,size_);
        
        mass0.resize(size_,size_);

        mass.resize(size_,size_);

        geoid.resize(size_,size_);
        vert.resize(size_,size_);
        east.resize(size_,size_);
        south.resize(size_,size_);
        
        hn.resize(bw_);
        ln.resize(bw_);
        kn.resize(bw_);

        smass0.resize(bw_-1);
        sother.resize(bw_-1);

        double PI=4.0*atan(1.0);
        double halfPI=PI/2.0;
        
        for(int i=0;i<size_;i++)
        {
            lat[i]=halfPI-PI*(i+0.5)/size_;
            lon[i]=PI*i/bw_;
        }
        
        cout.setf(ios::scientific);
        cout.precision(2);
    }

    template<class T> double sum(mat<T> &x)
    {
        int i,j;
        double s,dlon,halfdlat;

        dlon=lon[1]-lon[0];
        halfdlat=0.5*(lat[0]-lat[1]);
        
        s=0.0;
        for(i=0;i<size_;i++)
        for(j=0;j<size_;j++)
        {
            s+=dlon*(sin(lat[i]+halfdlat)-sin(lat[i]-halfdlat))*x[i][j];
        }
        return s;
    }   
    
    double sum(mat<int> &mask, mat<double> &x)
    {
        int i,j;
        double s,dlon,halfdlat;

        dlon=lon[1]-lon[0];
        halfdlat=0.5*(lat[0]-lat[1]);
        
        s=0.0;
        for(i=0;i<size_;i++)
        for(j=0;j<size_;j++)
        {
            s+=dlon*(sin(lat[i]+halfdlat)-sin(lat[i]-halfdlat))*mask[i][j]*x[i][j];
        }
        return s;
    }   

    void read()
    {
        ifstream ctl(ifile_.c_str());
        check_error(!ctl.is_open(),"Input data file not opened");

        cout<<"Reading data ..."<<endl;
        
        ctl>>prbDesc_;
        ctl>>bw_;
        ctl>>tol_;
        
        ctl>>R;
        ctl>>rho_E;
        ctl>>J2;
        ctl>>mgr;
        ctl>>k2bt;
        ctl>>h2bt;
        ctl>>l2bt;
        
        ctl>>rho_w;

        initialize();
        
        int i,j,k;
        
        string ifn;
        ifstream ifs;
        
        // load love numbers
        
        cout<<"   Reading load Love numbers in CE ..."<<endl;
        ctl>>ifn;
        ifs.open(ifn.c_str());
        check_error(!ifs.is_open(),"Cannot open file for load Love numbers");
        for(i=0;i<bw_;i++)
        {
            ifs>>hn[i];
            ifs>>ln[i];
            ifs>>kn[i];      
        }
        ifs.close();
        
        // degree1 1 LN from CE to CF frame
        
        double h1p=(2.0/3.0)*(hn[1]-ln[1]),
               l1p=-h1p/2.0,
               k1p=-(1.0/3.0)*hn[1]-(2.0/3.0)*ln[1];
               
        hn[1]=h1p;
        ln[1]=l1p;
        kn[1]=k1p;
        
        cout<<"      Love number converted to CF"<<endl;
        
        
        // transform lat and lon to degree
        
        double PI=4.0*atan(1.0);
        double D2R=PI/180.0;
        double R2D=180.0/PI;

        for(int i=0;i<size_;i++)
        {
            lat[i]*=R2D;
            lon[i]*=R2D;
        }

        double tlat,tlon;
        double dlon=lon[1]-lon[0];
        
        // ocean function
        
        cout<<"   Reading ocean function ..."<<endl;
        ctl>>ifn;
        ifs.open(ifn.c_str());
        check_error(!ifs.is_open(),"Cannot open file for ocean function");
        for(j=0;j<size_;j++)
        for(k=0;k<size_;k++)
        {
            ifs>>tlat;
            ifs>>tlon;
            check_error(fabs(tlat-lat[j])/dlon>tol_||fabs(tlon-lon[k])/dlon>tol_, 
                "Wrong grid in ocean function data");
            ifs>>ocean[j][k];
        }
        ifs.close();
        
        // source land function
        
        cout<<"   Reading mass area shape function ..."<<endl;
        ctl>>ifn;
        ifs.open(ifn.c_str());
        check_error(!ifs.is_open(),"Cannot open file for mass area shape function");
        for(j=0;j<size_;j++)
        for(k=0;k<size_;k++)
        {
            ifs>>tlat;
            ifs>>tlon;
            check_error(fabs(tlat-lat[j])/dlon>tol_||fabs(tlon-lon[k])/dlon>tol_, 
                "Wrong grid in source land function data");
            ifs>>source[j][k];
        }
        ifs.close();        
        
        // mass

        cout<<"   Reading mass ..."<<endl;
        ctl>>ifn;
        ifs.open(ifn.c_str());
        check_error(!ifs.is_open(),"Cannot open file for source mass data");
        for(j=0;j<size_;j++)
        for(k=0;k<size_;k++)
        {
            ifs>>tlat;
            ifs>>tlon;
            check_error(fabs(tlat-lat[j])/dlon>tol_||fabs(tlon-lon[k])/dlon>tol_, 
                "Wrong grid in mass data");
            ifs>>mass0[j][k];
            mass0[j][k]*=source[j][k];
        }
        ifs.close();        

        // output file name

        ctl>>rot_switch;
        check_error(!(rot_switch=="Rotational_Feedback_On"||rot_switch=="Rotational_Feedback_Off"),
            "Rotational feedback switch should be either 'Rotational_Feedback_On' or 'Rotational_Feedback_Off'");
        cout<<endl<<"Rotational feedback turned ";
        if(rot_switch=="Rotational_Feedback_On")cout<<"On"<<endl;
        else cout<<"Off"<<endl;
        
        ctl.close();
        
        //transform lat and lon to radian
        
        for(int i=0;i<size_;i++)
        {
            lat[i]*=D2R;
            lon[i]*=D2R;
        } 
               
        // averagely distribute mass in the ocean

        mass_o=-sum(mass0);
        area_o=sum(ocean);

        double tmp=mass_o/area_o;
        for(j=0;j<size_;j++)
        for(k=0;k<size_;k++)
        if(ocean[j][k]==1)
        {
            mass0[j][k]=tmp;
        }        
        cout<<endl<<"End reading"<<endl<<endl;
    }

    void iterate()
    {
        int i,j,k,l,m;
        double tmp;
		
		//mass0 is density, not height!
        sphTrans.forward(smass0,mass0);
        
        // coefficients of Wahr's definition

        tmp=1.0/(R*rho_w);
        for(i=0;i<smass0.numCoef();i++)
        {
            smass0[i]*=tmp;
        }
        //smass0 ==> H/R
        
        // geoid
        
        for(l=0;l<bw_;l++)
        {
            tmp=R*((3.0*rho_w)/rho_E)*((1.0+kn[l])/(2.0*l+1.0));
            sother.c(0,l)=smass0.c(0,l)*tmp;
            for(m=1;m<=l;m++)
            {
                sother.c(m,l)=smass0.c(m,l)*tmp;
                sother.s(m,l)=smass0.s(m,l)*tmp;
            }
        }

        if(rot_switch=="Rotational_Feedback_On")
        {
//        	cout<<smass0.c(0,2)<<endl;
//        	cout<<smass0.c(1,2)<<endl;
//        	cout<<smass0.s(1,2)<<endl;
//        	system("pause");
//        	
//        	cout<<sother.c(0,2)<<endl;
//        	cout<<sother.c(1,2)<<endl;
//        	cout<<sother.s(1,2)<<endl;
//        	system("pause");
        	
        	//without MR and R (as H/R in smass0)
        	c13=-(3.0*rho_w)/(5.0*rho_E)*sqrt(5.0/6.0)*smass0.c(1,2);
        	c23=-(3.0*rho_w)/(5.0*rho_E)*sqrt(5.0/6.0)*smass0.s(1,2);
        	c33=-(2.0*rho_w)/(5.0*rho_E)*sqrt(5.0/1.0)*smass0.c(0,2);

			//true value
            m1=(1.68*0.695)*c23/J2;
            m2=(1.68*0.695)*c13/J2;
            m3=0.695*c33/(0.3307*((8.020-0.9125)/8.020)); //(8.020-0.9125)/8.020)=Cm/C

			//divided by g_R, missing R
			c20p=-(2.0/3.0)*sqrt(1.0/5.0)*mgr*m3;
            c21p=-(1.0/3.0)*sqrt(6.0/5.0)*mgr*m1;
            s21p=-(1.0/3.0)*sqrt(6.0/5.0)*mgr*m2;

			//Scaled by R as in Wahr!
            sother.c(1,2)+=c20p*(1.0+k2bt);
            sother.c(1,2)+=c21p*(1.0+k2bt);
            sother.s(1,2)+=s21p*(1.0+k2bt);
        }

        sphTrans.inverse(geoid,sother);
        
        // vertical displacement

        for(l=0;l<bw_;l++)
        {
            tmp=R*((3.0*rho_w)/rho_E)*(hn[l]/(2.0*l+1.0));
            sother.c(0,l)=smass0.c(0,l)*tmp;
            for(m=1;m<=l;m++)
            {
                sother.c(m,l)=smass0.c(m,l)*tmp;
                sother.s(m,l)=smass0.s(m,l)*tmp;
            }
        }
        
        if(rot_switch=="Rotational_Feedback_On")
        {
            sother.c(1,2)+=c21p*h2bt;
            sother.s(1,2)+=s21p*h2bt;
        }
        
        sphTrans.inverse(vert,sother);

        // mass redistribution in the ocean

        for(j=0;j<size_;j++)
        for(k=0;k<size_;k++)
        {
            if(ocean[j][k]==0)
            {
                mass[j][k]=mass0[j][k];
            }
            else
            {
                mass[j][k]=(geoid[j][k]-vert[j][k])*rho_w;
            }
        }

        tmp=(mass_o-sum(ocean,mass))/area_o;

        for(j=0;j<size_;j++)
        for(k=0;k<size_;k++)
        if(ocean[j][k]==1)
        {
            mass[j][k]+=tmp;                  
        }
    }

    void horiz()
    {
        // need smass0 computed by iterate()
        
        cout<<"Computing horizontal displacement"<<endl;
        
        int i,j,l,m;
        double tmp;
        
        double PI=4.0*atan(1.0);
        
        // southward displacement

        for(l=0;l<bw_;l++)
        {
            tmp=R*((3.0*rho_w)/rho_E)*(ln[l]/(2.0*l+1.0));
            sother.c(0,l)=smass0.c(0,l)*tmp;
            for(m=1;m<=l;m++)
            {
                sother.c(m,l)=smass0.c(m,l)*tmp;
                sother.s(m,l)=smass0.s(m,l)*tmp;
            }
        }
        
        if(rot_switch=="Rotational_Feedback_On")
        {
            sother.c(1,2)+=c21p*l2bt;
            sother.s(1,2)+=s21p*l2bt;
        }

		sphTrans.inverse(south,sother,1);

        // eastward displacement

        for(l=0;l<bw_;l++)
        {
            tmp=R*((3.0*rho_w)/rho_E)*(ln[l]/(2.0*l+1.0));
            sother.c(0,l)=0.0;
            for(m=1;m<=l;m++)
            {
                sother.c(m,l)=smass0.s(m,l)*tmp*m;
                sother.s(m,l)=-smass0.c(m,l)*tmp*m;
            }
        }
        
        if(rot_switch=="Rotational_Feedback_On")
        {
            sother.c(1,2)+=c21p*l2bt;
            sother.s(1,2)+=s21p*l2bt;
        }
        
        sphTrans.inverse(east,sother);

        for(i=0;i<2*bw_;i++)
        {
            tmp=1.0/sin(PI*(0.5*i+0.25)/bw_);
            for(j=0;j<2*bw_;j++)
            {
                east[i][j]*=tmp;
            }
        }
    }

    void evaluate()
    {
        int i,j,k;
        double maxmum,diff;

        iterate();

        for(i=0;i<20;i++)
        {
            cout<<"Iteration "<<i+1<<" done"<<endl;
            
            maxmum=0.0;
            diff=0.0;
            for(j=0;j<size_;j++)
            for(k=0;k<size_;k++)
            if(ocean[j][k]==1)
            {
                maxmum=max(maxmum,fabs(mass[j][k]));
                diff=max(diff,fabs(mass[j][k]-mass0[j][k]));
            }  

            cout<<"Relative Error (maxdiff/max of mass variation in ocean) = "
                <<diff/maxmum<<endl<<endl;

            if(diff/maxmum<tol_)
            {
                break;
            }  
            mass0=mass;
            iterate();      
        }
        if(i==20)cout<<endl<<"Maximum 20 iteration is made. Something is wrong."<<endl;
        
        cout<<"Iteration finished"<<endl<<endl;
        
        horiz();
    }

    void output()
    { 
        cout<<"Outputing ..."<<endl;
        
        int i,j;
        double kg2m=1.0/rho_w;

        string ofile;
        ofstream out;

        // The function "sum" uses "lat" and "lon" in radian.
        // Hence output the average values (one of them need
        // "sum" ) before converting lat and lon to degree

        ofile=prbDesc_+"_average_sea_level_tide_gauge_meter.txt";
        out.open(ofile.c_str());   
            out<<mass_o*kg2m/area_o<<endl;
        out.close();

        ofile=prbDesc_+"_average_sea_level_altimetry_meter.txt";
        out.open(ofile.c_str());   
            out<<(mass_o*kg2m+sum(ocean,vert))/area_o<<endl;
        out.close();

        // transform lat and lon from radian to degree

        double PI=4.0*atan(1.0);
        double R2D=180.0/PI;
        for(i=0;i<size_;i++)
        {
            lat[i]*=R2D;
            lon[i]*=R2D;
        }
        
        ofile=prbDesc_+"_load_kg_per_square_meter.txt";
        out.open(ofile.c_str());
        for(i=0;i<size_;i++)
        for(j=0;j<size_;j++)
            out<<lat[i]<<"  "<<lon[j]<<"  "<<source[i][j]*mass[i][j]<<endl;
        out.close();
        
        ofile=prbDesc_+"_mass_kg_per_square_meter.txt";
        out.open(ofile.c_str());    
        for(i=0;i<size_;i++)
        for(j=0;j<size_;j++)
            out<<lat[i]<<"  "<<lon[j]<<"  "<<mass[i][j]<<endl;
        out.close();

        // mass from kg.m^{-2} to m 
 
        for(i=0;i<size_;i++)
        for(j=0;j<size_;j++)
            mass[i][j]*=kg2m;

        ofile=prbDesc_+"_load_water_thickness_meter.txt";
        out.open(ofile.c_str());    
        for(i=0;i<size_;i++)
        for(j=0;j<size_;j++)
            out<<lat[i]<<"  "<<lon[j]<<"  "<<source[i][j]*mass[i][j]<<endl;
        out.close();

        ofile=prbDesc_+"_mass_water_thickness_meter.txt";
        out.open(ofile.c_str());    
        for(i=0;i<size_;i++)
        for(j=0;j<size_;j++)
            out<<lat[i]<<"  "<<lon[j]<<"  "<<mass[i][j]<<endl;
        out.close();

        ofile=prbDesc_+"_sea_level_tide_gauge_meter.txt";
        out.open(ofile.c_str());    
        for(i=0;i<size_;i++)
        for(j=0;j<size_;j++)
            out<<lat[i]<<"  "<<lon[j]<<"  "<<ocean[i][j]*mass[i][j]<<endl;
        out.close();

        ofile=prbDesc_+"_sea_level_altimetry_meter.txt";
        out.open(ofile.c_str());   
        for(i=0;i<size_;i++)
        for(j=0;j<size_;j++)
            out<<lat[i]<<"  "<<lon[j]<<"  "<<ocean[i][j]*(mass[i][j]+vert[i][j])<<endl;
        out.close();

        ofile=prbDesc_+"_crust_displacement_up_south_east_meter.txt";
        out.open(ofile.c_str());   
        for(i=0;i<size_;i++)
        for(j=0;j<size_;j++)
            out<<lat[i]<<"  "<<lon[j]<<"  "
               <<vert[i][j]<<"  "<<south[i][j]<<"  "<<east[i][j]<<endl;
        out.close();
        
		if(rot_switch=="Rotational_Feedback_On")
        {
	        ofile=prbDesc_+"_rotationa_variation.txt";
	        out.open(ofile.c_str());   
	        out<<"m1="<<m1<<endl;
	        out<<"m2="<<m2<<endl;
	        out<<"m3="<<m3<<endl;
	        out.close();
	    }
    }

  public:

    explicit slc_ocwe(string ifile)
    {
        ifile_=ifile;
        read();
        sphTrans.resize(bw_,1);
        cout<<endl;
        evaluate();
        output();
        cout<<endl;
        cout<<"Everything is done ... BRAVO!"<<endl<<endl;
    }
    
    ~slc_ocwe(){}
};

#endif
