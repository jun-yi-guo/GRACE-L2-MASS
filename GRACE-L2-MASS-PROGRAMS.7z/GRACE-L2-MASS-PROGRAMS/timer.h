// File name: timer.h
// Copyright: Junyi Guo
// Author: Junyi Guo
// Created on April 18, 2001
// Modified on May 7, 2002

#ifndef timer_h
#define timer_h

#include <ctime>
#include <cmath>
#include <iostream>

#include "check_error.h"

using namespace std;

/**
 *  Compute the time elapsed for doing certain jobs. The time is estimated accurate to second. 
 *  The time counted may be continuously elapsed or sum of discontinuous fractions. 
 */ 

class timer
{
  private:

    time_t start_time; 
    double cumulative_time; 
    bool running; 

  public:

        /** Constructor. When an object is constructed, the time elapsed is 
         *  counted before the member function \em stop() is invoked.  
         */

    timer():cumulative_time(0) 
    {
	    running=false;
    } 
             
        /** 
         * Destructor. 
         */
    
    ~timer()
    {
    }
        
        /** Start counting time. If the function \em stop() was invoked, the 
         *  time at present is then not being counted. This function rebegin 
         *  to count time. 
         */
    
    void start()
    {
        check_error(running,"timer can start only if it is not running");
        running=true;
	    start_time=time(NULL);
    }

        /** Stop counting time and return the total time counted. This function 
         *  stops counting time, but the time counted before is still a part of 
         *  the total time counted. The total time counted is returned in unit of 
         *  second 
         */
    
    void stop()
    {
        check_error(!running,"timer can stop only if it is running");
	    running=false;
	    cumulative_time+=difftime(time(NULL),start_time);
    }

        /** Reset total time to zero and stops counting time. This function sets 
         *  the total time counted to zero and stops 
         *  counting time. 
         */

    void reset()
    {
	    cumulative_time=0;
	    running=false;
    }

    double second()
    {
	    if(running)return difftime(time(NULL),start_time)+cumulative_time;
	    else return cumulative_time;           
    }
    
        /** Output the total time counted.  This function returns the total time 
         *  counted in the form of \em Days : \em Hour : \em Minuts : \em seconds. 
         */

    void output()
    {
	    int days,hours,minuts,seconds;
	    double tt;

	    tt=second();
	
	    tt/=24*60*60;
	    days=(int)floor(tt);
	    tt-=days;
	    tt*=24;
	    hours=(int)floor(tt);
	    tt-=hours;
	    tt*=60;
	    minuts=(int)floor(tt);
	    tt-=minuts;
	    tt*=60;
        seconds=(int)tt;
        
	    cout<<days<<"D : "
		    <<hours<<"H : "
		    <<minuts<<"M : "
   		    <<seconds<<"S"
   		    <<endl;
    }
}; //class timer

void wait(int i)
{
    timer tm;
    tm.start();
    
//    cout<<"waiting for "<<i<<" seconds"<<endl;
    
    for(;;)
    {
        if(tm.second()>i)break;
    }
}

#endif //timer_h

//eof(timer.h)
