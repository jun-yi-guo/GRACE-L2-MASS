//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <iostream>
#include <cmath>    
#include <fstream>   
 
#include "Leakage_Land_Gauss_Mix.h"
   
using namespace std;

int main(int argc, char *argv[])
{
    int i,NLAT,NLON,mulat,mulon,NFILE;
    double rt,rl;
    string W,ifile,ofile,of_file;
    double tmp;
    
    ifstream input("Leakage_Land_Gauss_Mix.txt");
    
    input>>of_file;
    input>>NLAT;
    input>>NLON;
    input>>W;
    input>>rt;
    input>>rl;
    input>>mulat;
    input>>mulon;
    input>>NFILE;

    leakage_land_grid_gauss leakage(of_file,rt,rl,W,NLAT,NLON,mulat,mulon);
    
    for(i=0;i<NFILE;i++)
    {
        input>>ifile;
        input>>ofile;
        leakage.solve(ifile,ofile);
        cout<<i+1<<" over "<<NFILE<<" done"<<endl;
    }

    system("PAUSE");
    return 1;
}
