//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

using namespace std;

int main()
{
    int i,j,k,numGri,numLat,numLon,numFil;

    string *sy,*sm,*fileName,ofile;

    double lat,lon,lf,water;

    ifstream input("Merge_Geoid_to_Fit.txt");

    input>>ofile;
    
    input>>numLat;
    input>>numLon;
    
    numGri=numLat*numLon;

    input>>numFil;
    
    fileName=new string[numFil];
    sy=new string[numFil];
    sm=new string[numFil];

    cout<<"extract year and month form file name"<<endl<<flush;
    
    for(i=0;i<numFil;i++)
    {
        input>>fileName[i];
        sy[i]=fileName[i].substr(0,4);
        sm[i]=fileName[i].substr(5,3);

        cout<<fileName[i]<<"  "<<sy[i]<<":"<<sm[i]<<endl;
    }
    
    cout<<"Merging data to a single file"<<endl<<flush;
    
    ifstream in[numFil];
    for(i=0;i<numFil;i++)
    {
        in[i].open(fileName[i].c_str());
        if(!in[i].is_open())
        {
            cout<<"file "<<fileName[i]<<" not opened"<<endl;
            exit(0);
        }
    }
    
    ofstream output(ofile.c_str());
    output.precision(16);
    
    output<<numFil<<endl;
    for(i=0;i<numFil;i++)output<<sy[i]<<"  "<<sm[i]<<endl;
    
    output<<numLat*numLon<<"   "<<2<<endl;

    for(k=0;k<numGri;k++)
    {
        for(i=0;i<numFil;i++)
        {
            in[i]>>lat;
            in[i]>>lon;
            in[i]>>water;
            if(i==0)output<<lat<<"   "<<lon<<"     ";
            output<<water<<"   ";
        }
        output<<endl;
        
        if(k%100==0)cout<<k<<" over "<<numGri<<" done"<<endl;
    }
    output.close();
     
    for(i=0;i<numFil;i++)in[i].close();
    delete[]fileName;
    delete[]sy;
    delete[]sm;

    input.close();
    system("pause");
    return 1;
}
