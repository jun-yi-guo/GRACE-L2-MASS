//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <string>
#include <cmath>

#include "rshc.h"

using namespace std;

int str2int(string s)
{
    return atoi(s.c_str());
}

int main()
{
    int i,j,k,l,m,DEG,numFile;  
    double dy,dd,t0,t;    
    rshc pgr,grc,rst;
    string ref_model,yyyy,ddd,pgrfile,ifile,ofile;
   
    ifstream input("Remove_GIA.txt");

    input>>DEG;
    input>>ref_model;
    
    yyyy=ref_model.substr(0,4);
    ddd=ref_model.substr(5,3);

    dy=str2int(yyyy);
    dd=str2int(ddd);
    t0=dy+(1.0/365.25)*dd;
    cout<<"Reference epoch: "<<yyyy<<":"<<ddd<<"->"<<t0<<endl;
  
    input>>pgrfile;

    pgr.resize(DEG);
    grc.resize(DEG);
    rst.resize(DEG);

    pgr.input_s0(pgrfile.c_str());
    
    input>>numFile;

    for(i=0;i<numFile;i++)
    {
        input>>ifile;
        input>>ofile;

        yyyy=ifile.substr(0,4);
        ddd=ifile.substr(5,3);

        dy=str2int(yyyy);
        dd=str2int(ddd);
        t=dy+(1.0/365.25)*dd;
        cout<<"Epoch: "<<yyyy<<":"<<ddd<<"->"<<t<<endl;

        grc.input_s0(ifile.c_str());

        for(l=0;l<=DEG;l++)
        {
            rst.c(0,l)=grc.c(0,l)-pgr.c(0,l)*(t-t0);
            for(m=1;m<=l;m++)
            {
                rst.c(m,l)=grc.c(m,l)-pgr.c(m,l)*(t-t0);
                rst.s(m,l)=grc.s(m,l)-pgr.s(m,l)*(t-t0);                 
            }
        }
       
        rst.output_s0(ofile.c_str(),15);   
        
//        cout<<i+1<<" over "<<numFile<<" done: "<<ifile<<" -> "<<ofile<<endl;        
    }

//    system("pause");
    return 0;
}
