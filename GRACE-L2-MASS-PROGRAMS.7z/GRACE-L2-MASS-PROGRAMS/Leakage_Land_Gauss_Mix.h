//Copyright: Jun-Yi Guo

#include <iostream>

#include "grid.h"

using namespace std;

class leakage_land_grid_gauss
{
  private:
  
    double rl,rt;
    bool isW;
    int NLAT,NLON;
    int mulat;
    int mulon;

    double sl,st;

    int lcut,hcut;

    int NGLAT,NGLON;
    int NNLAT,NNLON;

    mat<double>Gtl;

    vec<double>sinth;
    vec<double>costh;
    vec<double>cosld;

    mat<double>fd;

    string of_file;
    mat<int>of;

    grid grid_;

    double W(int JJ)
    {
        if(isW)return sinth[JJ];
        else return 1.0;
    }
    
    double G(double x,double sigma)
    {
        return exp(-(x*x)/(2.0*sigma*sigma));
    }

    double GW(int JJ,int m,int n)
    {
        return Gtl[abs(m)][abs(n)]*W(JJ);
    }

    void initialize()
    {
        int i,j,k,m,n;
        double pi=4.0*atan(1.0);
        double tmp;

        double dlat,dlon;

        tmp=1.0/sqrt(2.0*log(2.0));
        st=rt*tmp;
        sl=rl*tmp;

        tmp=asin(rt/rl);
        lcut=int(tmp/(pi/NLAT));
        hcut=NLAT-lcut;

        NNLAT=NLAT*mulat;
        NNLON=NLON*mulon;
        
        dlat=pi/NNLAT;
        dlon=2.0*pi/NNLON;
        
        NGLAT=int(6.0*st/dlat);
        if(NGLAT%2==0)NGLAT++;
        
        NGLON=int(6.0*sl/dlon);
        if(NGLON%2==0)NGLON++;

        Gtl.resize((NGLAT+1)/2,(NGLON+1)/2);
        
        for(n=0;n<(NGLAT+1)/2;n++)
        for(m=0;m<(NGLON+1)/2;m++)
        {
           Gtl[n][m]=G(n*dlat,st)*G(m*dlon,sl);
        }

        costh.resize(NNLAT);
        sinth.resize(NNLAT);
        cosld.resize(NNLON);
        for(j=0;j<NNLAT;j++)
        {
            tmp=(j+0.5)*dlat;
            sinth[j]=sin(tmp);
            costh[j]=cos(tmp);
        }
        for(k=0;k<NNLON;k++)cosld[k]=cos(k*dlon);

        fd.resize(NLAT,NLON);

        grid_.reset("Gauss",NLAT,NLON);
        
        mat<int> ofo(NLAT,NLON);
        grid_.input(of_file,ofo);
        
        of.resize(NNLAT,NNLON);
        int J,K,JJ,KK,MNLAT,MNLON;
        
        MNLAT=(mulat-1)/2;
        MNLON=(mulon-1)/2;
        
        for(j=0;j<NLAT;j++)
        for(k=0;k<NLON;k++)
        {
            J=j*mulat+(mulat-1)/2;
            K=k*mulon;
            
            for(JJ=J-MNLAT;JJ<=J+MNLAT;JJ++)
            for(KK=K-MNLON;KK<=K+MNLON;KK++)
            {
                if(KK>=0&&KK<NNLON)
                {
                    of[JJ][KK]=ofo[j][k];
                }

                else if(KK<0)
                {
                    of[JJ][NNLON+KK]=ofo[j][k];
                }
                else
                {
                    of[JJ][KK-NNLON]=ofo[j][k];
                }                                             
            }
        }
    }
    
    double psi(int J,int K,int JJ,int KK)
    {
        double p;
        p=costh[J]*costh[JJ]+sinth[J]*sinth[JJ]*cosld[abs(KK-K)];
        if(p<-1.0)p=-1.0;
        if(p>1.0)p=1.0;        
        return acos(p);
    }

    double G(double x)
    {
        return exp(-(x*x)/(2.0*st*st));
    }

    void leakage()
    {
        cout<<"Removing leakage ..."<<endl;

        int j,k,M,N,J,JJ,K,KK,Jlow,Jhigh,Klow,Khigh,ofjk;
        
        double YL,YO;

        M=(NGLAT-1)/2;
        N=(NGLON-1)/2;
        
        int counter=0;

        for(j=lcut;j<=hcut;j++)
        for(k=0;k<NLON;k++)
        {
            J=j*mulat+(mulat-1)/2;
            K=k*mulon;
            
            ofjk=of[J][K];
            
            Jlow=J-M;
            Jhigh=J+M;
            if(Jlow<0)
            {
                Jlow=0;
                Jhigh=J+(J-Jlow);
            }
            if(Jhigh>NNLAT-1)
            {
                Jhigh=NNLAT-1;
                Jlow=J-(NNLAT-1-J);
            }        

            Klow=K-N;
            Khigh=K+N;

            YO=0.0; 
            YL=0.0;                          
            
            if(ofjk==0)
            {
                for(JJ=Jlow;JJ<=Jhigh;JJ++)
                for(KK=Klow;KK<=Khigh;KK++)
                {
                    if(KK>=0&&KK<NNLON)
                    {
                        if(of[JJ][KK]==ofjk)
                        {
                            YL+=GW(JJ,JJ-J,KK-K);
                        }
                        else
                        {
                            YO+=GW(JJ,JJ-J,KK-K);                            
                        }
                    }
                    else if(KK<0)
                    {
                        if(of[JJ][NNLON+KK]==ofjk)
                        {
                            YL+=GW(JJ,JJ-J,KK-K);
                        }
                        else
                        {
                            YO+=GW(JJ,JJ-J,KK-K);                            
                        }
                    }
                    else 
                    {
                        if(of[JJ][KK-NNLON]==ofjk)
                        {
                            YL+=GW(JJ,JJ-J,KK-K);
                        }
                        else
                        {
                            YO+=GW(JJ,JJ-J,KK-K);                            
                        }
                    }                    
                }
                fd[j][k]*=(YL+YO)/YL;
            }
            else
            {
                fd[j][k]=0.0;
            }
            
            counter++;
            if(counter%50==0)cout<<counter<<" out of "<<NLAT*NLON<<" done."<<endl;
        }
        
        double p,range,tmp;

        range=3.0*st;

        for(j=0;j<NLAT;j++)
        if(j<lcut||j>hcut)
        for(k=0;k<NLON;k++)
        {
            J=j*mulat+(mulat-1)/2;
            K=k*mulon;
            
            ofjk=of[J][K];
            
            YL=0.0;
            YO=0.0;
            
            if(ofjk==0)
            {
                for(JJ=0;JJ<NNLAT;JJ++)
                for(KK=0;KK<NNLON;KK++)
                {
                    p=psi(J,K,JJ,KK);
                    
                    if(p<range)
                    {
                        if(of[JJ][KK]==ofjk)
                        {
                            YL+=G(p)*sinth[JJ];
                        }
                        else
                        {
                            YO+=G(p)*sinth[JJ];
                        }
                    }
                }
                fd[j][k]*=((YL+YO)/YL);
            }
            else
            {
                fd[j][k]=0.0;
            }
            
            counter++;
            if(counter%50==0)cout<<counter<<" out of "<<NLAT*NLON<<" done."<<endl;
        }        
    }

  public:

    leakage_land_grid_gauss(string of_file_,double rt_,double rl_,string isW_,int NLAT_,int NLON_,
                            int mulat_,int mulon)
    {
        reset(of_file_,rt_,rl_,isW_,NLAT_,NLON_,mulat_,mulon);
    }
    
    ~leakage_land_grid_gauss(){}

    void reset(string of_file_,double rt_,double rl_,string isW_,int NLAT_,int NLON_,
              int mulat_,int mulon_)
    {
        cout<<"Initializing for removing leakage"<<endl;
        
        double pi=4.0*atan(1.0);
        
        check_error(isW_!="wW"&&isW_!="nW","should be wW or nW for weighting selection");
        check_error(mulat_%2==0,"mu must be odd");
        check_error(mulon_%2==0,"mu must be odd");
        
        if(isW_=="wW")isW=true;
        else isW=false;
        
        of_file=of_file_;
        rt=rt_*pi/180.0;
        rl=rl_*pi/180.0;
        NLAT=NLAT_;
        NLON=NLON_;
        mulat=mulat_;
        mulon=mulon_;
        initialize();
    }
    
    void solve(mat<double> &A,mat<double> &B)
    {   
        cout<<"Removing leakage ..."<<endl;

        check_error(A.numRows()!=NLAT&&A.numCols()!=NLON,"Matrix size mismatch");
        check_error(A.numRows()!=NLAT&&A.numCols()!=NLON,"Matrix size mismatch");
        fd=A;
        leakage();
        B=fd;
    }

    void solve(string ifile,string ofile)
    {   
        ifstream in(ifile.c_str());
        ofstream out(ofile.c_str());
        out.precision(15);
        
        grid_.input(in,fd);
        leakage();
        grid_.output(out,fd);
        
        in.close();
        out.close();
    }  
       
    void solve(ifstream &in,ofstream &out)
    {   
        grid_.input(in,fd);
        leakage();
        grid_.output(out,fd);
    }                 
};
