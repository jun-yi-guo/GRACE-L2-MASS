//Copyright: Jun-Yi Guo

#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <cmath>

using namespace std;

int main()
{
	int i,j,k,m,numLat,numLon,numFile,*rm;

    string ifile, rfile, ofile;
    
    double *lat0, *lon0, factor, lat, lon, data, sum;
    
    double tol=1.0e-3;
    
 	ifstream input("Scale_Region.txt");

    input>>numLat;
    input>>numLon;
    input>>factor;
    
    input>>rfile;
    
    ifstream inr(rfile.c_str());
    
    rm=new int[numLat*numLon];
    lat0=new double[numLat];
    lon0=new double[numLon];
    
    k=0;
    for(i=0;i<numLat;i++)
    for(j=0;j<numLon;j++)
    {
        inr>>lat0[i];
        inr>>lon0[j];
        inr>>rm[k];   
        k++;                   
    }

    ofstream out; 
    ifstream in;
    
	input>>numFile;

    for(m=0;m<numFile;m++)
    {
        input>>ifile;
        in.open(ifile.c_str());
        input>>ofile;
        out.open(ofile.c_str());
        out.precision(16);
        
        sum=0.0;
        k=0;
        for(i=0;i<numLat;i++)
        for(j=0;j<numLon;j++)
        {
            in>>lat;
            in>>lon;
            if(fabs(lat-lat0[i])>tol||fabs(lon-lon0[j])>tol)
            {
                cout<<"Error in data file: Grid different"<<endl;
                system("pause");
                return 0;    
            }
            in>>data; 
            
            if(rm[k]==1)data*=factor;
            
            out<<lat<<"  "<<lon<<"  "<<data<<endl;

            k++;                   
        }
        
        in.close();
        out.close();
        cout<<ifile<<" done."<<endl; 
    }

    delete[]rm;
    delete[]lat0;
    delete[]lon0;
    
//    system("pause");

	return 0; 
}
