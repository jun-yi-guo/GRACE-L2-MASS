//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

using namespace std;

int main()
{
    int i,j,k,numPoly,numSin,num,numGri,numAttr;
    double coeTre, coeCos, coeSin, dtmp;
    
    string ifile, tfile, cfile, sfile, type;
    
    char tmp[1024];

    ifstream input("Extract_Geoid_After_Fit.txt");
    
    input>>ifile;
    input>>numPoly;
    for(i=0;i<numPoly;i++)input>>dtmp;
    input>>numSin;
    for(i=0;i<numSin;i++)input>>dtmp;    
    input>>type;
    input>>num;
    
    if(type=="polynomial")
    {
        input>>tfile;
        cfile="NULL";
        sfile="NULL";
    }
    else if(type=="sinusoid")
    {
        input>>cfile;
        input>>sfile;   
        tfile="NULL";      
    }
    else
    {
         cerr<<"must be 'polynomial' or 'sinusoid'"<<endl;
         exit(0);    
    }
     
    input.close();
    
    ifstream in(ifile.c_str());
    
    for(i=0;i<20;i++)in.getline(tmp,1024);
    in>>numGri;
    in>>numAttr;
    
    string attr[numAttr];
    
    if(type=="polynomial")
    {
        ofstream outt(tfile.c_str());
        for(j=0;j<numGri;j++)
        {
            for(i=0;i<numAttr;i++)in>>attr[i];
            for(i=0;i<num-1;i++)in>>dtmp;
            in>>coeTre;
            
            for(i=0;i<numPoly-num;i++)in>>dtmp;
            for(i=0;i<2*numSin;i++)in>>dtmp;
            for(i=0;i<numPoly+2*numSin;i++)in>>dtmp;
            in>>dtmp;
            in>>dtmp;
            
            for(i=0;i<numAttr;i++)outt<<attr[i]<<"   "; 
            outt<<coeTre<<endl; 
        }
        outt.close();                
    }
    else
    {
        ofstream outc(cfile.c_str());
        ofstream outs(sfile.c_str());        
        for(j=0;j<numGri;j++)
        {
            for(i=0;i<numAttr;i++)in>>attr[i];
            for(i=0;i<numPoly;i++)in>>dtmp;
            for(i=0;i<num-1;i++)
            {
               in>>dtmp;
               in>>dtmp;
            }
            in>>coeCos;
            in>>coeSin;
            
            for(i=0;i<2*(numSin-num);i++)in>>dtmp;
            for(i=0;i<numPoly+2*numSin;i++)in>>dtmp;
            in>>dtmp;
            in>>dtmp;
            
            for(i=0;i<numAttr;i++)
            {
                outc<<attr[i]<<"   ";
                outs<<attr[i]<<"   ";
            } 
            outc<<coeCos<<endl; 
            outs<<coeSin<<endl;
        }
        outc.close();
        outs.close();           
    }

    in.close();
//    system("pause");
    return 0;
}
