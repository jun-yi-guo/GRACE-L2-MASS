//Copyright: Jun-Yi Guo

#ifndef grid_conv_h
#define grid_conv_h

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

#include "rfss.h"

class gridConv
{
  private:

    enum dataTypes {floating, integral};
    enum gridTypes {Gauss, Lobbato};

    dataTypes dataType_;
    gridTypes origGridType_;
    gridTypes destGridType_;

    int origNumLat_;
    int origNumLon_;

    int destNumLat_;
    int destNumLon_;

    mat<double> source;
    mat<double> result;

    string cfile_;
    ifstream input;
    
    int numFile_;
    string ifile_;
    string ofile_;
    
    ifstream in;
    ofstream out;
    
    rfssg tg_;
    rfssl tl_; 
    
    void initialize()
    {
        int j,k;
        string indt;

        // read data type
        
        input>>indt;
        
        check_error(indt!="floating"&&indt!="integral", "Wrong data type");
        
        if(indt=="floating")
        {
            dataType_=floating;
        }
        else
        { 
            dataType_=integral;    
        }
        
        // read original grid type
        
        input>>indt;
        
        check_error(indt!="Gauss"&&indt!="Lobbato", "Wrong original grid type: Gauss or Lobbato");
        
        if(indt=="Gauss")
        {
            origGridType_=Gauss;
        }
        else
        {
            origGridType_=Lobbato;    
        }
        
        // read original grid numbers
        
        input>>origNumLat_;
        input>>origNumLon_;
        
        // resize source data matrix
        
        source.resize(origNumLat_,origNumLon_);

        // read destination grid type
        
        input>>indt;
        check_error(indt!="Gauss"&&indt!="Lobbato", "Wrong destination grid type: Gauss or Lobbato");
        
        if(indt=="Gauss")
        {
            destGridType_=Gauss;
        }
        else
        {
            destGridType_=Lobbato;    
        }
                
        // read destination grid numbers
        
        input>>destNumLat_;
        input>>destNumLon_;        

        // resize destination data matrix

        result.resize(destNumLat_,destNumLon_);   

        // number of files to be converted    
        
        input>>numFile_;
    }

    void read_io_files()
    {
        input>>ifile_;
        input>>ofile_;      
    }

    void read_data()
    {
        int j,k;
        string indt;
        double dlat,dlon;
        double tlat,tlon;
        
        double tol=1.0e-2;
        
        // compute approximate latitude and longitude interval
        // will be used to check if the grid in data file is correct

        dlat=180.0/origNumLat_;
        dlon=360.0/origNumLat_;

        // open data file

        in.open(ifile_.c_str());
        check_error(!in.is_open(),"Input data file not opened");
        
        // read original data
        
        switch(origGridType_)
        { 
          case Gauss:
 
            for(j=0;j<origNumLat_;j++)
            for(k=0;k<origNumLon_;k++)
            {
                in>>tlat;
                in>>tlon;
                check_error(fabs((tlat-90.0+(j+0.5)*180.0/origNumLat_)/dlat)>tol,
                   "Error in source data file"); 
                check_error(fabs((tlon-k*360.0/origNumLon_)/dlon)>tol,
                   "Error in source data file"); 
                in>>source[j][k];
            }
                          
            break;

          case Lobbato:

            for(j=0;j<origNumLat_;j++)
            for(k=0;k<origNumLon_;k++)
            {
                in>>tlat;
                in>>tlon;
                check_error(fabs((tlat-90.0+j*180.0/(origNumLat_-1))/dlon)>tol,
                    "Error in source data file"); 
                check_error(fabs((tlon-k*360.0/origNumLon_)/dlon)>tol,
                    "Error in source data file"); 
                in>>source[j][k];
            }
            break;
        }
                
        in.close();
    }

    void conv()
    {
        int j,k,J,K;
        
        switch(origGridType_)
        { 
          case Gauss:
               
            tg_.resize(origNumLat_,origNumLon_);
            tg_.forward(source);
            break;
            
          case Lobbato:
               
            tl_.resize(origNumLat_,origNumLon_);
            tl_.forward(source);
            break;
        }
        
        J=min(origNumLat_,destNumLat_);
        K=min(origNumLon_,destNumLon_);
        
        for(j=0;j<J;j++)
        for(k=0;k<K;k++)
        {
            result[j][k]=source[j][k];
        }
        
        for(j=0;j<J;j++)
        for(k=K;k<destNumLon_;k++)
        {
            result[j][k]=0;
        }
        
        for(j=J;j<destNumLat_;j++)
        for(k=0;k<destNumLon_;k++)
        {
            result[j][k]=0;
        }
        
        switch(destGridType_)
        { 
          case Gauss:
               
            tg_.resize(destNumLat_,destNumLon_);
            tg_.inverse(result);
            break;
            
          case Lobbato:
               
            tl_.resize(destNumLat_,destNumLon_);
            tl_.inverse(result);
            break;
        }
    }

    void output()
    {
        out.open(ofile_.c_str());
        out.precision(15);
        
        int j,k;
        double r;
        
        if(dataType_==integral)
        {
            for(j=0;j<destNumLat_;j++)
            for(k=0;k<destNumLon_;k++)
            {
       	        r=floor(result[j][k]);
	            if(result[j][k]-r>0.5)r++;                      
                result[j][k]=r;
            }            
        }

        switch(destGridType_)
        { 
          case Gauss:
               
            for(j=0;j<destNumLat_;j++)
            for(k=0;k<destNumLon_;k++)
            {
                out<<90.0-(j+0.5)*180.0/destNumLat_<<"  "
                   <<k*360.0/destNumLon_<<"   "
                   <<result[j][k]<<endl;                    
            }           
            break;

          case Lobbato:
            for(j=0;j<destNumLat_;j++)
            for(k=0;k<destNumLon_;k++)
            {
                out<<90.0-j*180.0/(destNumLat_-1)<<"  "
                   <<k*360.0/destNumLon_<<"   "
                   <<result[j][k]<<endl;                    
            }
            break;
        }
        out.close();
    }

    void perform(string cfile)
    {
        if(cfile!="0")
        {       
            cfile_=cfile;
            
            input.open(cfile_.c_str());
            check_error(!input.is_open(),"Input file not opened");
            
            initialize();
            
            for(int i=0;i<numFile_;i++)
            {
                read_io_files();
                read_data();
                conv();
                output();
                
                cout<<i+1<<"   "<<ifile_<<"   "<<ofile_<<endl<<flush;
            }
            input.close();
        }         
    }

  public:

    explicit gridConv(string ifile="0")
    {
        perform(ifile);
    }

    ~gridConv(){}

    void convert(string ifile="0")
    {
        perform(ifile);
    }
};

#endif

