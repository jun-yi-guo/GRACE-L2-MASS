//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cmath>

#include "rshc.h"

using namespace std;

int str2int(string s)
{
    return atoi(s.c_str());
}

string int2str(int i,int N)
{
     int j,M;
     string value,prev;
     char c[10],tmp[10];
     ostringstream ss;
     ss<<i;
     prev=ss.str();
//     prev=itoa(i,tmp,10);
//     prev=to_string(i);
     M=prev.size();

     if(M>N)
     {
         cout<<"String length too short to accormodate the integer"<<endl;
         return 0;
     }
     
     value="";
     for(j=0;j<N-M;j++)value+="0";
     value+=prev;
     return value;  
}

int main()
{
    int i,j,k,Deg,numAVR,numFile,iyr,iday;
    double yr;
    string sfx,ifile,ofile,yyyy,ddd;
    ifstream input("Average_SHCs.txt");
//    cout.precision(16);
    
    input>>sfx;
    input>>Deg;
    
    rshc shc0(Deg),shc(Deg);
    
    input>>numAVR;
    input>>numFile;
    
    for(k=0;k<numAVR;k++)
    {
        yr=0;
    
        cout<<"Working ";
    
        for(i=0;i<numFile;i++)
        {
            input>>ifile;
            
            yyyy=ifile.substr(0,4);
            ddd=ifile.substr(5,3);
            yr+=str2int(yyyy)+str2int(ddd)/365.25;
            
            shc.input_s0(ifile.c_str());
            
//            cout<<ifile<<"  "<<shc[0]<<endl;
            
            if(i==0)shc0=shc;
            else for(j=0;j<shc.numCoef();j++)shc0[j]+=shc[j];
            cout<<".";
        }
        cout<<endl;
    
        yr/=numFile;
        iyr=(int)floor(yr);
        iday=(int)floor(365.25*(yr-iyr));    
        ofile=int2str(iyr,4)+"_"+int2str(iday,3)+sfx+".txt";
 
        for(j=0;j<shc.numCoef();j++)shc0[j]/=numFile;

//     	if(fabs(shc0[0]-1.0)<1.0e-14)shc0[0]=1.0;

        shc0.output_s0(ofile.c_str(),16);

        cout<<k+1<<": Results output in the file "<<ofile<<endl;
    }
    
    input.close();

//    system("pause");
    return 0;
}
