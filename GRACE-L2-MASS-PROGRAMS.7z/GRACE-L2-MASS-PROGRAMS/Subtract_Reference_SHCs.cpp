//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

#include "rshc.h"

using namespace std;

int main()
{
    int i,j,Deg,numFile;
    string afile,ifile,ofile;
    ifstream input("Subtract_Reference_SHCs.txt");

    input>>Deg;
    input>>afile;
    
    rshc shc0(Deg),shc(Deg);
    
    shc0.input_s0(afile.c_str());

    input>>numFile;

    for(i=0;i<numFile;i++)
    {
        input>>ifile;
        input>>ofile;
        shc.input_s0(ifile.c_str());
        for(j=0;j<shc0.numCoef();j++)shc[j]-=shc0[j];
        shc.output_s0(ofile.c_str(),16);
        cout<<i+1<<" over "<<numFile<<" done"<<endl;
    }

    input.close();
//    system("pause");
    return 0;
}
