//Copyright: Jun-Yi Guo

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <cmath>

#include "linalg.h"

using namespace std;

void polyfit_sub(int n, double *t, double *f,int m,double *r,
             double *c,double *std,double &rmsf,double &rmsr)
{
    int i,j,k;
    double **A,**AT,**N,**NINV,*b,*v0,*v;

    A=Matrix(n,m);
    AT=Matrix(m,n);
    N=Matrix(m,m);
    NINV=Matrix(m,m);
    b=Vector(m);
    v0=Vector(n);
    v=Vector(n);

    for(k=0;k<n;k++)
    for(i=0;i<m;i++)
    {
        A[k][i]=pow(t[k],r[i]);
    }

	MatTrans(n,m,A,AT);
	MatMulMat(m,n,m,AT,A,N);	
	
	chol_inv(m,N,NINV);	    

    MatMulVec(m,n,AT,f,b);
   	MatMulVec(m,m,NINV,b,c);
	
	MatMulVec(n,m,A,c,v0);
	VecSubVec(n,v0,f,v);

    double eu=0.0;
    
   	for(i=0,eu=0.0;i<n;i++)eu+=v[i]*v[i];
   	eu/=(n-m); 
   	
   	for(i=0;i<m;i++)std[i]=sqrt(NINV[i][i]*eu);

    rmsf=rms(n,f);
    rmsr=rms(n,v);

    FreeMatrix(A);
    FreeMatrix(AT);
    FreeMatrix(N);
    FreeMatrix(NINV);
    FreeVector(b);
    FreeVector(v0);
    FreeVector(v);    
}

void plnml_sub(int m,double *r,double *c,int n,double *t,double *f)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        f[i]=0;
        for(j=0;j<m;j++)f[i]+=c[j]*pow(t[i],r[j]);
    }
}
