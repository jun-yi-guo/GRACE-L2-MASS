//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <iostream>
#include <cmath>    
#include <fstream>   

#include "Filter_Land_Ocean_Gauss_Mix.h"
 
using namespace std;

int main(int argc, char *argv[])
{
    int i,NLAT,NLON,mu,NFILE;
    double rt,rl;
    string W,ifile,ofile,of_file;
    double tmp;
    
    ifstream input("Filter_Land_Ocean_Gauss_Mix.txt");
    
    input>>of_file;
    input>>NLAT;
    input>>NLON;
    input>>W;
    input>>rt;
    input>>rl;
    input>>mu;
    input>>NFILE;

    filter_cont_ocean_grid_gauss filter(of_file,rt,rl,W,NLAT,NLON,mu);
    
    for(i=0;i<NFILE;i++)
    {
        input>>ifile;
        input>>ofile;
        filter.solve(ifile,ofile);
        cout<<i+1<<" over "<<NFILE<<" done"<<endl;
    }

    system("PAUSE");
    return 1;
}
