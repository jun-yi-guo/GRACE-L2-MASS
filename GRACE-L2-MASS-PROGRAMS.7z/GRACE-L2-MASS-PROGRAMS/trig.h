//Copyright: Jun-Yi Guo

#ifndef trig_h
#define trig_h

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <cmath>
#include <limits>
#include <complex>

#include "vec.h"
#include "mat.h"

using namespace std;

class trig_one_theta
{
  public:
  	double c;
  	double s;
  	double csqr;
  	double ssqr;
  	double sinv;
  	double sinvsqr;
  	double ct;
  	double ctsqr;
	
	void evaluate(double theta)
	{
		c=cos(theta);
		s=sin(theta);
		csqr=c*c;
		ssqr=s*s;		

		sinv=1.0/s;
		sinvsqr=sinv*sinv;
		
		ct=c*sinv;
		ctsqr=ct*ct;
	}
	
	trig_one_theta(double theta=0.0)
	{
		if(theta!=0.0)evaluate(theta);
	}
	
	~trig_one_theta(){}
	
	void reset(double theta=0.0)
	{
		if(theta!=0.0)evaluate(theta);
	}
};

class trig_multi_theta
{
  public:
  	vec<double> c;
  	vec<double> s;
  	vec<double> csqr;
  	vec<double> ssqr;

  	vec<double> sinv;
  	vec<double> sinvsqr; 
	   	
  	vec<double> ct;
  	vec<double> ctsqr;
	  	  	    	
  	int nl,nh,len;

	void initialize(int nl_,int nh_)
	{
		nl=nl_;
		nh=nh_;
		len=nh-nl+1;
		if(len==0)return;
		
		c.resize(nl,nh);
		s.resize(nl,nh);
		csqr.resize(nl,nh);
		ssqr.resize(nl,nh);
		
		sinv.resize(nl,nh);
		sinvsqr.resize(nl,nh);	
			
		ct.resize(nl,nh);
		ctsqr.resize(nl,nh);
	}
	
	void evaluate(vec<double>& theta)
	{
		check_error(theta.lower_index()!=nl||theta.higher_index()!=nh, "Index mismatch");
		
		double dtmp,ctmp,stmp,sinvtmp,cttmp;
		
		for(int i=nl;i<=nh;i++)
		{
			dtmp=theta[i];
			
			ctmp=cos(dtmp);
			stmp=sin(dtmp);
			c[i]=ctmp;
			s[i]=stmp;
			csqr[i]=ctmp*ctmp;
			ssqr[i]=stmp*stmp;
			
			sinvtmp=1.0/stmp;
			sinv[i]=sinvtmp;
			sinvsqr[i]=sinvtmp*sinvtmp;
			
			cttmp=ctmp*sinvtmp;
			ct[i]=cttmp;
			ctsqr[i]=cttmp*cttmp;
		}		
	}

	explicit trig_multi_theta(int clen=0)
	{
		initialize(0,clen-1);
	}
	
	explicit trig_multi_theta(int vec_nl,int vec_nh)
	{
		check_error(vec_nl>vec_nh, "Lower index larger than higher index");
		initialize(vec_nl,vec_nh);
	}
		
	explicit trig_multi_theta(vec<double>& theta)
	{
		initialize(theta.lower_index(),theta.higher_index());
		evaluate(theta);
	}
	
	~trig_multi_theta(){}
	
	void reset(vec<double>& theta)
	{
		if(theta.lower_index()==nl,theta.higher_index()==nh)
		{
			evaluate(theta);		
		}
		else
		{
			initialize(theta.lower_index(),theta.higher_index());
			evaluate(theta);
		}
	}
};

class trig_one_lambda_real
{
  public:
  	int M;
  	vec<double> cm;
  	vec<double> sm;
  	
	void initialize(int M_)
	{
		M=M_;
		cm.resize(0,M);
		sm.resize(0,M);
	}  	
	
	explicit trig_one_lambda_real(int M_=0)
	{
		initialize(M_);
	}

	~trig_one_lambda_real(){}
	
	void reset(int M_)
	{
		initialize(M_);
	}
		
	void evaluate(double lambda)
	{
		double dtmp;
		for(int m=0;m<=M;m++)
		{
			dtmp=m*lambda;
			cm[m]=cos(dtmp);
			sm[m]=sin(dtmp);
		}
	}
};

class trig_one_lambda_complex
{
  public:
  	int M;
  	vec<complex<double> > eim;
  	
	void initialize(int M_)
	{
		M=M_;
		eim.resize(-M,M);
	}  	
	
	explicit trig_one_lambda_complex(int M_=0)
	{
		initialize(M_);
	}

	~trig_one_lambda_complex(){}
	
	void reset(int M_)
	{
		initialize(M_);
	}

	void evaluate(trig_one_lambda_real &real)
	{
		check_error(real.M!=M, "Index size mismathch");
		eim[0].real(real.cm[0]);
		eim[0].imag(real.sm[0]);		
		for(int m=0;m<=M;m++)
		{
			eim[m].real(real.cm[m]);
			eim[m].imag(real.sm[m]);

			eim[-m].real(real.cm[m]);
			eim[-m].imag(-real.sm[m]);
		}
	}
	void reset(trig_one_lambda_real &real)
	{
		if(real.M==M)
		{
			evaluate(real);
		}
		else
		{
			reset(real.M);
			evaluate(real);
		}
	}
};

class trig_multi_lambda_real
{
  public:
  	int nl,nh,len;
  	int M;
  	mat<double> clm;
  	mat<double> slm;
  	
	void initialize(int nl_, int nh_, int M_)
	{
		check_error(nl_>nh_, "Lower index larger than high index");
		nl=nl_;
		nh=nh_;
		len=nh-nl+1;
		M=M_;
		clm.resize(nl,nh,0,M);
		slm.resize(nl,nh,0,M);
	} 
	 	
	void evaluate(vec<double> &lambda)
	{
		check_error(lambda.lower_index()!=nl||lambda.higher_index()!=nh, "Index mismatch");
		double dtmp;
		for(int n=nl;n<=nh;n++)
		for(int m=0;m<=M;m++)
		{
			dtmp=m*lambda[n];
			clm[n][m]=cos(dtmp);
			slm[n][m]=sin(dtmp);
		}
	}

	explicit trig_multi_lambda_real(int len_=0, int M_=0)
	{
		if(len_>0&&M_>0)initialize(0,len_-1,M_);
	}
	
	explicit trig_multi_lambda_real(int nl_, int nh_, int M_)
	{
		initialize(nl_,nh_,M_);
	}

	explicit trig_multi_lambda_real(vec<double> &lambda, int M_)
	{
		initialize(lambda.lower_index(),lambda.higher_index(),M_);
		evaluate(lambda);
	}

	~trig_multi_lambda_real(){}
	
	void reset(int len_,int M_)
	{
		initialize(0,len_-1,M_);
	}

	void reset(int nl_, int nh_, int M_)
	{
		initialize(nl_,nh_,M_);
	}
			
	void reset(vec<double> &lambda, int M_)
	{
		int nl_=lambda.lower_index();
		int nh_=lambda.higher_index();
		
		if(nl_==nl&&nh_==nh&&M_==M)
		{
			evaluate(lambda);
		}
		else
		{
			initialize(nl_,nh_,M_);
			evaluate(lambda);
		}
	}
};

class trig_multi_lambda_complex
{
  public:
  	int nl,nh,len;
  	int M;
  	mat<complex<double> > eilm;
  	
	void initialize(int nl_, int nh_, int M_)
	{
		check_error(nl_>nh_, "Lower index larger than high index");
		nl=nl_;
		nh=nh_;
		len=nh-nl+1;
		M=M_;

		eilm.resize(nl,nh,-M,M);
	} 
	 	
	void evaluate(trig_multi_lambda_real &real)
	{
		check_error(real.nl!=nl||real.nh!=nh||real.M!=M, "Index mismatch");
		double dtmp;
		for(int n=nl;n<=nh;n++)
		{
			eilm[n][0].real(real.clm[n][0]);
			eilm[n][0].imag(real.slm[n][0]);
						
			for(int m=1;m<=M;m++)
			{
				eilm[n][m].real(real.clm[n][m]);
				eilm[n][m].imag(real.slm[n][m]);

				eilm[n][-m].real(real.clm[n][m]);
				eilm[n][-m].imag(-real.slm[n][m]);
			}
		}
	}
		
	explicit trig_multi_lambda_complex(int len_=0, int M_=0)
	{
		if(len_>0&&M_>0)initialize(0,len_-1,M_);
	}
	
	explicit trig_multi_lambda_complex(int nl_, int nh_, int M_)
	{
		initialize(nl_,nh_,M_);
	}

	explicit trig_multi_lambda_complex(trig_multi_lambda_real &real)
	{
		initialize(real.nl,real.nh,real.M);
		evaluate(real);
	}

	~trig_multi_lambda_complex(){}
	
	void reset(int len_,int M_)
	{
		initialize(0,len_-1,M_);
	}

	void reset(int nl_, int nh_, int M_)
	{
		initialize(nl_,nh_,M_);
	}
			
	void reset(trig_multi_lambda_real &real)
	{
		int nl_=real.nl;
		int nh_=real.nh;
		int M_=real.M;
	
		if(nl_==nl&&nh_==nh&&M_==M)
		{
			evaluate(real);
		}
		else
		{
			initialize(nl_,nh_,M_);
			evaluate(real);
		}
	}
};

#endif //trig_h
