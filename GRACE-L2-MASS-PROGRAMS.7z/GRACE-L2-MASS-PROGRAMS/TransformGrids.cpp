//Copyright: Jun-Yi Guo

#include <iostream>
#include <fstream>
#include <string>
   
#include "TransformGrids.h"

using namespace std;

int main(int argc,char *argv[])
{
    string sourcefile;

    cout<<endl
        <<"Usage: TransformGrids [file]"<<endl
        <<"   Input data locations are specified in [file]"<<endl
        <<"   The default for [file] is \"TransformGrids.txt\""<<endl
        <<"   Sea README_grid_conv.txt for detail description"<<endl;
           
    if(argc==1)
    {
        sourcefile="TransformGrids.txt";    
    }
    else if(argc==2)
    {
        sourcefile=argv[1];
    }
    else    
    {
        cout<<"Too many arguments"<<endl;
        exit(1);     
    }

    cout<<endl<<"Converting ..."<<endl;
     
    (gridConv)sourcefile; 

    return 1;
} 
