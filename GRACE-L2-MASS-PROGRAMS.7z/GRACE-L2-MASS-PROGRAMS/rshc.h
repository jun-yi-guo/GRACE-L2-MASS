//Copyright: Jun-Yi Guo

#ifndef rshc_h
#define rshc_h

#include <cstdlib>
#include <iostream>
#include <fstream>

#include "check_error.h"

using namespace std;

    /**
     *  Spherical harmonic coefficient, both real and complex. Real and 
     *  complex coeficients are acessed using different functions.
     */

class rshc
{
  public:
         
    enum nmTypes{CplxFull,RealFull,CplxSemi,RealSemi,UnNorm};
    enum dfTypes{FERRER,HOBSON};
         
  private:

    nmTypes nmType;
    dfTypes dfType;

    int L_;
    int dim_;
    
    double **c_,**s_;

    double *data_;

    void initialize(int L)
    {
         check_error(L<0,"Degree must >= 0");
         
         int m,l;
         int num_alf;
         
         L_=L;
         num_alf=(L_+1)*(L_+2)/2;
         dim_=2*num_alf;

         data_=new(std::nothrow) double[dim_];
         check_error(data_==NULL,"Not enough memory");
         
         c_=new(std::nothrow) double*[L_+1];
         check_error(c_==NULL,"Not enough memory");
         
         s_=new(std::nothrow) double*[L_+1];
         check_error(s_==NULL,"Not enough memory");

		 int itmp;
         for(m=0;m<=L_;m++)
		 {
		 	itmp=(2*L_+3-m)*m/2-m;
		 	c_[m]=data_+itmp;
         	s_[m]=data_+num_alf+itmp;
         }
         for(l=0;l<L_;l++)s_[0][l]=0.0;
    }

    void destroy()
    {
         delete[]c_;
         delete[]s_;
         delete[]data_;
    }
    
    void copy(double *data)
    {
        for(int i=0;i<dim_;i++)data_[i]=data[i];
    }

    void convToCplxFull()
    {
        int m,l;
        double coef,coef0,tmp;
      
        switch(nmType)
        {
            case CplxFull:
                 
                break;

            case RealFull:

                coef=sqrt(2.0);
                for(l=0;l<=L_;l++)
                {
                    for(m=1;m<=l;m++)
                    {
                        c_[m][l]*=coef;
                        s_[m][l]*=coef;
                    }
                } 

                break;
                
            case CplxSemi:
                 
                for(l=0;l<=L_;l++)
                {
                	coef=sqrt(1.0/(2.0*l+1.0));
                    c_[0][l]*=coef;                	
                    for(m=1;m<=l;m++)
                    {
                        c_[m][l]*=coef;
                        s_[m][l]*=coef;
                    }
                } 

                break;
                
            case RealSemi:
            	                 
                for(l=0;l<=L_;l++)
                {
                	coef=sqrt(2.0/(2.0*l+1.0));
                    c_[0][l]*=coef/sqrt(2.0);                	
                    for(m=1;m<=l;m++)
                    {
                        c_[m][l]*=coef;
                        s_[m][l]*=coef;
                    }
                } 

                break;

            case UnNorm:

                for(l=0;l<=L_;l++)
                {
                    coef0=sqrt(1.0/(2.0*l+1.0));
                    c_[0][l]*=coef0;
                    tmp=1.0;
                    for(m=1;m<=l;m++)
                    {
                        tmp*=sqrt((l-m+1.0)*(l+m));
                        coef=coef0*tmp;
                        c_[m][l]*=coef;
                        s_[m][l]*=coef;
                    }
                } 
 
                break;
        }
                
        nmType=CplxFull;  
    }

    void convFromCplxFullTo(nmTypes nm)
    {
        int m,l;
        double tmp,coef0,coef;
        
        switch(nm)
        {
            case CplxFull:
                 
                break;

            case RealFull:
                 
                coef=1.0/sqrt(2.0);
                for(l=0;l<=L_;l++)
                {
                    for(m=1;m<=l;m++)
                    {
                        c_[m][l]*=coef;
                        s_[m][l]*=coef;
                    }
                }         
                 
                break;

            case CplxSemi:
               
                for(l=0;l<=L_;l++)
                {
                    coef=sqrt(2.0*l+1.0);
                    c_[0][l]*=coef;
                    for(m=1;m<=l;m++)
                    {
                        c_[m][l]*=coef;
                        s_[m][l]*=coef;
                    }
                } 
                
                break;
                
            case RealSemi:
               
                for(l=0;l<=L_;l++)
                {
                    coef=sqrt((2.0*l+1.0)/2.0);
                    c_[0][l]*=coef*sqrt(2.0);
                    for(m=1;m<=l;m++)
                    {
                        c_[m][l]*=coef;
                        s_[m][l]*=coef;
                    }
                } 
                
                break;
                
            case UnNorm:
                
                for(l=0;l<=L_;l++)
                {
                	coef0=sqrt(2.0*l+1.0);
                    c_[0][l]*=coef0;
                    tmp=1.0;
                    for(m=1;m<=l;m++)
                    {
                        tmp/=sqrt((l-m+1.0)*(l+m));
                        coef=coef0*tmp;
                        c_[m][l]*=coef;
                        s_[m][l]*=coef;
                    }
                } 
            
                break;
        }

        nmType=nm;  
    }

    void swapType()
    {
        int m,l;
        for(m=0;m<=L_;m++)if(m%2==1)
        {
	        for(l=m;l<=L_;l++)
	        {
	            c_[m][l]=-c_[m][l];
	            s_[m][l]=-s_[m][l];
	        }
    	}
    }

  public:

    /**
     *  Constructor
     */
     
    explicit rshc(int L=0,nmTypes nm=CplxFull,dfTypes df=FERRER)
    {
        nmType=nm;
        dfType=df;
         
        initialize(L);
    }
    
    /** 
     * The copy constructor. Deep copy is assumed.
     */
     
    rshc(const rshc &x)
    {
        nmType=x.nmType;
        dfType=x.dfType;
   
        initialize(x.L_);
        copy(x.data_);
    }          
    
    /**
     *  Denstructor
     */
     
    ~rshc()
    {
        destroy();
    }
    
    /**
     * Set normalization type
     */
     
    void setNormType(nmTypes nm)
    {
        nmType=nm;
    }
    
    /**
     * Set definition type
     */
     
    void setDefType(dfTypes df)
    {
        dfType=df;
    }
        
    /**
     * Return the the maximum order or degree
     */ 
         
    int maxOrd() const
    {
        return L_;
    }   
   
    /**
     * Return the the maximum order or degree
     */ 
         
    int maxDeg() const
    {
        return L_;
    }       
    
    /**
     * Return the total number of coefficients
     */ 
         
    int numCoef() const
    {
        return dim_;
    }   

    /**
     * Change the size of the object, i.e. the maximum order or degree, to \em K.
     */
         
    void resize(int L=0)
    {
        if(L_!=L)
        {
            destroy();
            initialize(L);
        }
    }

    /** 
     * Direct element accessing.	No bound check is made. 
     */
         
    double& operator[](int i)
    {
        return data_[i];
    }

    /** 
     * Direct Element accessing.	No bound check is made. 
     */
         
    const double& operator[](int i) const
    {
        return data_[i];
    }

    /** 
     * Accessing coefficients of cosine for real case.	No bound check is made. 
     */

    double& c(int m,int l)
    {
        return c_[m][l];
    }

    /** 
     * Accessing coefficients of cosine for real case.	No bound check is made. 
     */

    const double& c(int m,int l) const
    {
        return c_[m][l];
    }

    /** 
     * Accessing coefficients of sine for real case.	No bound check is made. 
     */

    double& s(int m,int l)
    {
        return s_[m][l];
    }

    /** 
     * Accessing coefficients of sine for real case.	No bound check is made. 
     */

    const double& s(int m,int l) const
    {
        return s_[m][l];
    }

    /**
     * The \em rv is assigned to \em lv. The sizes of \em rv and
     * of \em lv should be equal.
     */

    rshc& operator=(const rshc& x)
    {
        if(this==&x)return *this;
        check_error(L_!=x.L_,"Sizes of shcs are different");
        copy(x.data_);	
        return *this;
    }
    
    /**
     * The \em rv is assigned to \em lv.
     */

    rshc& operator=(const double x)
    {
        for(int j=0;j<dim_;j++) data_[j]=x;	
        return *this;
    } 
    
    void input(const char file[])
    {
        ifstream in(file);
        int i,j,n,m;
        for(i=0;i<=L_;i++)for(j=i;j<=L_;j++)
        {
            in>>n;
            in>>m;
            check_error(i!=m||j!=n,"Error in data file of shc");
            if(m==0) 
            {
                in>>c(m,n);
            }
            else
            {
                in>>c(m,n);
                in>>s(m,n);
            }
 
        }
        in.close();
    }
    
    void output(const char file[],int nd=15)
    {
        ofstream out(file);
        out.precision(nd);
        int l,m;
        for(m=0;m<=L_;m++)for(l=m;l<=L_;l++)
        {
            if(m!=0)out<<l<<"   "<<m<<"   "<<c(m,l)<<"   "<<s(m,l)<<endl;
            else out<<l<<"   "<<m<<"   "<<c(m,l)<<endl;
        }
        out.close();
    }
    
    void input_s0(const char file[])
    {
        ifstream in(file);
        int i,j,n,m;
        double tmp;
        
        for(i=0;i<=L_;i++)for(j=i;j<=L_;j++)
        {
            in>>n;
            in>>m;
            check_error(i!=m||j!=n,"Error in data file of shc");
            if(m==0) 
            {
                in>>c(m,n);
                in>>tmp;
            }
            else
            {
                in>>c(m,n);
                in>>s(m,n);
            }
 
        }
        in.close();
    }
    
    void output_s0(const char file[],int nd=15)
    {
        ofstream out(file);
        out.precision(nd);
        int l,m;
        for(m=0;m<=L_;m++)for(l=m;l<=L_;l++)
        {
            if(m!=0)out<<l<<"   "<<m<<"   "<<c(m,l)<<"   "<<s(m,l)<<endl;
            else out<<l<<"   "<<m<<"   "<<c(m,l)<<"   "<<0<<endl;
        }
        out.close();
    } 
    
    void input_do(const char file[])
    {
        ifstream in(file);
        int i,j,n,m;
        double tmp;
        
        for(j=0;j<=L_;j++)for(i=0;i<=j;i++)
        {
            in>>n;
            in>>m;
            check_error(j!=n||i!=m,"Error in data file of shc");
            if(m==0) 
            {
                in>>c(m,n);
                in>>tmp;
            }
            else
            {
                in>>c(m,n);
                in>>s(m,n);
            }
 
        }
        in.close();
    }
    
    void output_do(const char file[],int nd=15)
    {
        ofstream out(file);
        out.precision(nd);
        
        int i,j;
       
        for(j=0;j<=L_;j++)
		for(i=0;i<=j;i++)
        {
            out<<j<<"   "<<i<<"      ";
            if(i==0) 
            {
                out<<c(i,j)<<"    "<<0.0<<endl;
            }
            else
            {
                out<<c(i,j)<<"    "<<s(i,j)<<endl;
            }
        }
        out.close();
    }

    void toCplxFull()
    {
        convToCplxFull();
    }

    void toRealFull()
    {
        convToCplxFull();
        convFromCplxFullTo(RealFull);
    }

    void toCplxSemi()
    {
        convToCplxFull();
        convFromCplxFullTo(CplxSemi);
    }
    
    void toRealSemi()
    {
        convToCplxFull();
        convFromCplxFullTo(RealSemi);
    }

    void toUnNorm()
    {
        convToCplxFull();
        convFromCplxFullTo(UnNorm);
    }

    void toHOBSON()
    {
        if(dfType==HOBSON)return;
        swapType();
        dfType=HOBSON;
    }

    void toFERRER()
    {
        if(dfType==FERRER)return;
        swapType();
        dfType=FERRER;
    }

};//class rshc

double rshc_CplxFull_to_RealFull(double c, int order)
{
	if(order!=0)return c/sqrt(2.0); // 1/sqrt(2)
    else return c;    // same
}

double rshc_RealFull_to_CplxFull(double c, int order)
{
	if(order!=0)return c*sqrt(2.0); // sqrt(2)
    else return c;    // same
}

#endif
