//Copyright: Jun-Yi Guo

#ifndef grid_conv_h
#define grid_conv_h

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

#include "rfss.h"
#include "grid.h"

class gridConv
{
  private:

    enum dataTypes {floating, integral, NDT};
    enum gridTypes {Gauss, Lobbato, NGT};

    dataTypes dataType_;
    gridTypes origGridType_;
    gridTypes destGridType_;

    int origNumLat_;
    int origNumLon_;

    int destNumLat_;
    int destNumLon_;

    grid igrid;
    grid ogrid;

    mat<double> source;
    mat<double> result;

    rfssg tg_;
    rfssl tl_; 

    void conv()
    {
        int j,k,J,K;
        
        double r;
        
        switch(origGridType_)
        { 
          case Gauss:
               
            tg_.resize(origNumLat_,origNumLon_);
            tg_.forward(source);
            break;
            
          case Lobbato:
               
            tl_.resize(origNumLat_,origNumLon_);
            tl_.forward(source);
            break;
        }
        
        J=min(origNumLat_,destNumLat_);
        K=min(origNumLon_,destNumLon_);
        
        for(j=0;j<J;j++)
        for(k=0;k<K;k++)
        {
            result[j][k]=source[j][k];
        }
        
        for(j=0;j<J;j++)
        for(k=K;k<destNumLon_;k++)
        {
            result[j][k]=0;
        }
        
        for(j=J;j<destNumLat_;j++)
        for(k=0;k<destNumLon_;k++)
        {
            result[j][k]=0;
        }
        
        switch(destGridType_)
        { 
          case Gauss:
               
            tg_.resize(destNumLat_,destNumLon_);
            tg_.inverse(result);
            break;
            
          case Lobbato:
               
            tl_.resize(destNumLat_,destNumLon_);
            tl_.inverse(result);
            break;
        }
        
        if(dataType_==integral)
        {
            for(j=0;j<destNumLat_;j++)
            for(k=0;k<destNumLon_;k++)
            {
       	        r=floor(result[j][k]);
	            if(result[j][k]-r>0.5)r++;                      
                result[j][k]=r;
            }            
        }
    }

  public:

    gridConv()
    {
        dataType_=NDT;
        origGridType_=NGT;
        destGridType_=NGT;
    }

    ~gridConv(){}
 
    void setDataType(string indt)
    {
        check_error(indt!="floating"&&indt!="integral", "Wrong data type");
        
        if(indt=="floating")
        {
            dataType_=floating;
        }
        else
        {
            dataType_=integral;    
        }          
    }
    
    void setOriginalGrid(string indt,int NLAT,int NLON)
    {
        check_error(indt!="Gauss"&&indt!="Lobbato", "Wrong original grid type");
        
        igrid.reset(indt,NLAT,NLON);
        
        if(indt=="Gauss")
        {
            origGridType_=Gauss;
        }
        else
        {
            origGridType_=Lobbato;    
        }
        
        origNumLat_=NLAT;
        origNumLon_=NLON;
        
        source.resize(origNumLat_,origNumLon_);
    }
 
    void setResultGrid(string indt,int NLAT,int NLON)
    {
        check_error(indt!="Gauss"&&indt!="Lobbato", "Wrong original grid type");
        
        ogrid.reset(indt,NLAT,NLON);
 
        if(indt=="Gauss")
        {
            destGridType_=Gauss;
        }
        else
        {
            destGridType_=Lobbato;    
        }
                
        destNumLat_=NLAT;
        destNumLon_=NLON;  

        result.resize(destNumLat_,destNumLon_);   
    } 

    void perform(mat<double> &A,mat<double> &B)
    {
        check_error(A.numRows()!=origNumLat_&&A.numCols()!=origNumLon_,"Matrix size mismatch");
        check_error(B.numRows()!=destNumLat_&&B.numCols()!=destNumLon_,"Matrix size mismatch");
        source=A;
        conv();
        B=result;
    }

    void perform(ifstream &in,ofstream &out)
    {
        igrid.input(in,source);
        conv();
        ogrid.output(out,result);
    }
};

#endif

