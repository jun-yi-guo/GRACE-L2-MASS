//Copyright: Jun-Yi Guo

#include <cstdlib>
#include <fstream>
#include <string>
#include <cmath>

#include "vec.h"
#include "mat.h"
#include "rshc.h"
#include "linalg.h"
#include "polyfit_sub.h"

using namespace std;

double polyfit(int nn,int ww,double *f,int poly_deg)
{
    double *t,*r,*c,*std,rmsf,rmsr,tmp;
    int i;

    int n,m;
    
    n=ww;
    m=poly_deg+1;

    t=Vector(n); 
    tmp=1.0/n;
    
    for(i=0;i<n;i++)t[i]=i*tmp;

    r=Vector(m);
    for(i=0;i<m;i++)r[i]=i;
 
    c=Vector(m);
    std=Vector(m);
    
    polyfit_sub(n,t,f,m,r,c,std,rmsf,rmsr);
    
    double rst;
    
    rst=0.0;
    for(i=0;i<m;i++)rst+=c[i]*pow(t[nn-1],r[i]);

    FreeVector(t);
    FreeVector(r);
    FreeVector(c);
    FreeVector(std);
    
    return rst;
}

int main()
{
    int ii,i,j,k,n,m,nn,ww,poly_deg,pre_max_deg,win_max_deg,bw,numFile;   
    double *fc,*fs,tmp;
    double tol=1.0e-2;

    string pre,win;
    
    rshc spect_o,spect_d;

    string ifile,ofile;

    ifstream input("Decorrelation_Filter.txt");

    input>>pre;
   
    ifstream prein(pre.c_str());
    prein>>pre_max_deg;
    
    vec<double>pre_deg(pre_max_deg+1);
    for(i=0;i<=pre_max_deg;i++)
    {
        prein>>tmp;
        prein>>pre_deg[i];
    }
    
    prein.close();

    input>>win;
    
    ifstream winin(win.c_str());
    winin>>win_max_deg;
    
    mat<int>win_wid(win_max_deg+1,win_max_deg+1);
    for(i=0;i<=win_max_deg;i++)
    for(j=0;j<=i;j++)
    {
        winin>>tmp;
        winin>>tmp;
        winin>>win_wid[i][j];
    }
    
    winin.close();
    
    input>>poly_deg;
    
    input>>bw;
    
    check_error(bw>win_max_deg,"window width maximum degree too low");
    
    bw++;
    
    spect_o.resize(bw-1);
    spect_d.resize(bw-1);

    input>>numFile;

    for(ii=0;ii<numFile;ii++)
    {
        input>>ifile;
        input>>ofile;

        spect_o.input_s0(ifile.c_str());

        for(m=0;m<bw;m++)
        {
            for(n=m;n<bw;n+=2)
            {
                ww=win_wid[n][m];
                fc=Vector(ww);
                fs=Vector(ww);
                if(m>bw-1-2*ww)
                {
                    spect_d.c(m,n)=0.0;
                    if(m!=0)spect_d.s(m,n)=0.0;
                }
                else
                {
                    if(n<m+(ww-1))
                    {
                        nn=(n-m)/2+1; 
                        for(i=0;i<ww;i++)
                        {
                            fc[i]=spect_o.c(m,m+2*i);
                            if(m!=0)fs[i]=spect_o.s(m,m+2*i);
                        }
                    }
                    else if((m+bw-1)%2==0&&n>(bw-1)-(ww-1))
                    {
                        nn=(n-(bw-1-2*(ww-1)))/2+1; 
                        for(i=0;i<ww;i++)
                        {
                            fc[i]=spect_o.c(m,bw-1-2*(ww-1)+2*i);
                            if(m!=0)fs[i]=spect_o.s(m,bw-1-2*(ww-1)+2*i);
                        }                    
                    }
                    else if((m+bw-1)%2==1&&n>(bw-2)-(ww-1))
                    {
                        nn=(n-(bw-2-2*(ww-1)))/2+1; 
                        for(i=0;i<ww;i++)
                        {
                            fc[i]=spect_o.c(m,bw-2-2*(ww-1)+2*i);
                            if(m!=0)fs[i]=spect_o.s(m,bw-2-2*(ww-1)+2*i);
                        }                  
                    }
                    else
                    {
                        nn=(ww-1)/2+1; 
                        for(i=0;i<ww;i++)
                        {
                            fc[i]=spect_o.c(m,n-(ww-1)+2*i);
                            if(m!=0)fs[i]=spect_o.s(m,n-(ww-1)+2*i);
                        }
                    }
                    
                    tmp=polyfit(nn,ww,fc,poly_deg);
                    spect_d.c(m,n)=spect_o.c(m,n)-tmp;
                    
                    if(m!=0)
                    {
                        tmp=polyfit(nn,ww,fs,poly_deg);
                        spect_d.s(m,n)=spect_o.s(m,n)-tmp;
                    }
                    FreeVector(fc);
                    FreeVector(fs);
                }
            }
            
            for(n=m+1;n<bw;n+=2)
            {
                ww=win_wid[n][m];
                fc=Vector(ww);
                fs=Vector(ww);
                if(m>bw-1-2*ww)
                {
                    spect_d.c(m,n)=0.0;
                    if(m!=0)spect_d.s(m,n)=0.0;
                }
                else
                {
                    if(n<m+1+(ww-1))
                    {
                        nn=(n-(m+1))/2+1; 
                        for(i=0;i<ww;i++)
                        {
                            fc[i]=spect_o.c(m,m+1+2*i);
                            if(m!=0)fs[i]=spect_o.s(m,m+1+2*i);
                        }
                    }
                    else if((m+1+bw-1)%2==0&&n>(bw-1)-(ww-1))
                    {
                        nn=(n-(bw-1-2*(ww-1)))/2+1; 
                        for(i=0;i<ww;i++)
                        {
                            fc[i]=spect_o.c(m,bw-1-2*(ww-1)+2*i);
                            if(m!=0)fs[i]=spect_o.s(m,bw-1-2*(ww-1)+2*i);
                        }                    
                    }
                    else if((m+1+bw-1)%2==1&&n>(bw-2)-(ww-1))
                    {
                        nn=(n-(bw-2-2*(ww-1)))/2+1; 
                        for(i=0;i<ww;i++)
                        {
                            fc[i]=spect_o.c(m,bw-2-2*(ww-1)+2*i);
                            if(m!=0)fs[i]=spect_o.s(m,bw-2-2*(ww-1)+2*i);
                        }                  
                    }
                    else
                    {
                        nn=(ww-1)/2+1; 
                        for(i=0;i<ww;i++)
                        {
                            fc[i]=spect_o.c(m,n-(ww-1)+2*i);
                            if(m!=0)fs[i]=spect_o.s(m,n-(ww-1)+2*i);
                        }
                    }

                    tmp=polyfit(nn,ww,fc,poly_deg);
                    spect_d.c(m,n)=spect_o.c(m,n)-tmp;
                    
                    if(m!=0)
                    {
                        tmp=polyfit(nn,ww,fs,poly_deg);
                        spect_d.s(m,n)=spect_o.s(m,n)-tmp;
                    }
                    FreeVector(fc);
                    FreeVector(fs);
                }
            }
        }
        
        for(n=0;n<=pre_deg[0];n++)
            spect_d.c(0,n)=spect_o.c(0,n);
        
        for(m=1;m<=pre_max_deg;m++)
        for(n=m;n<=pre_deg[m];n++)
        {
            spect_d.c(m,n)=spect_o.c(m,n);
            spect_d.s(m,n)=spect_o.s(m,n);
        }           

        spect_d.output_s0(ofile.c_str(),16);  
        cout<<ii+1<<" over "<<numFile<<" done"<<endl;
    }

 //   system("pause");
    return 0;
}
