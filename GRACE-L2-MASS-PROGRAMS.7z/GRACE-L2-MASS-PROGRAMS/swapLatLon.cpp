//Copyright: Jun-Yi Guo

#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>

using namespace std;

void usage()
{
    cerr<<endl<<"USAGE: swapLatLon [dataDescriptionFile]"<<endl;
    cerr<<"Defaut `dataDescriptionFile' is swapLatLon.txt"<<endl;
}

int main(int argc, char *argv[])
{
	int i, j, k, numLat, numLon, numFile;

    enum {from180to360,from360to180}type; 

    string ifile, ofile, stmp;
    
    double lat, lon, data;

 	ifstream input;
 	
    if(argc>2)
    {
        usage();
        return 0;
    }
    else if(argc==1)
    {
        input.open("swapLatLon.txt");
        if(!input.is_open())
        {
            usage();
            cerr<<endl<<"`swapLatLon.txt' does not exist"<<endl;
            return 0;
        }
    }
    else
    {
        input.open(argv[1]);        
        if(!input.is_open())
        {
            usage();
            cerr<<endl<<"`"<<argv[1]<<"' dose not exist"<<endl;
            return 0;
        }
    }

	input>>numLat;
	input>>numLon;

	input>>numFile;

    ifstream in;
    ofstream out;

    for(k=0;k<numFile;k++)
    {
        input>>ifile;
        input>>ofile;
        
        if(ifile==ofile)
        {
            cerr<<"Input and output files must be different"<<endl;
            return 0;
        }
        
        in.open(ifile.c_str());
        out.open(ofile.c_str());
        
        for(i=0;i<numLat*numLon;i++)
        {
            in>>lat;
            in>>lon;
            in>>data;

        	out<<lon<<"  "<<lat<<"   "<<data<<endl;
        }

        in.close();
        out.close();
        
        cout<<k+1<<"   "<<ifile<<"   "<<ofile<<endl<<flush; 
    }
    
    
    input.close();

    system("pause");

	return 1; 
}
