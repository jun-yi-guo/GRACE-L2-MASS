//Cop[yright: Jun-Yi Guo

#include <cstdlib>
#include <fstream>
#include <string>
#include <cmath>

#include "rsht.h"

using namespace std;

int main()
{
    int i,j,k,l,m,bw,numFile;   
    double R,r,lat,lon,dlat,dlon,tol,tmp;
    
    tol=1.0e-2;
    
    mat<double>filtered,unfiltered;
    rshc sfiltered,sunfiltered;

    string ifile,ofile;

    ifstream input("Isotropic_Gaussian_Grid.txt");

    input>>R;
    input>>r;
    input>>bw;
    input>>numFile;
    
    filtered.resize(2*bw,2*bw);
    unfiltered.resize(2*bw,2*bw);
   
    sfiltered.resize(bw-1);
    sunfiltered.resize(bw-1);

    rsht_memo sphTrans(bw);
    
    dlat=180.0/(2.0*bw);
    dlon=360.0/(2.0*bw);   

    ifstream in;
    ofstream out;

// bw=120;
    
    vec<double>W(bw);

// r=300000.0;

    tmp=log(2.0)/(1.0-cos(r/R));
    W[0]=1.0;
    W[1]=(1.0+exp(-2.0*tmp))/(1.0-exp(-2.0*tmp))-1.0/tmp;
    for(i=2;i<bw;i++)
    {
        if(W[i-1]>1.0e-7) W[i]=-((2.0*i-1.0)/tmp)*W[i-1]+W[i-2];
        else W[i]=0.0;
    }
    
// for(i=0;i<bw;i++)cout<<i<<"  "<<W[i]<<endl;
    
// system("pause");
    
    for(i=0;i<numFile;i++)
    {
        input>>ifile;
        input>>ofile;
        in.open(ifile.c_str());
        out.open(ofile.c_str());
        out.precision(16);
        
        for(j=0;j<2*bw;j++)
        for(k=0;k<2*bw;k++)
        {  
            in>>lat;
            in>>lon;
            check_error(fabs((lat-90.0+(j+0.5)*180.0/(2.0*bw))/dlat)>tol,
               "Error in source data file"); 
            check_error(fabs((lon-k*360.0/(2.0*bw))/dlon)>tol,
               "Error in source data file"); 
            in>>unfiltered[j][k];
        }
        
        sphTrans.forward(sunfiltered,unfiltered);

        for(l=0;l<bw;l++)
        {
            sfiltered.c(0,l)=sunfiltered.c(0,l)*W[l];
            for(m=1;m<=l;m++)
            {
                sfiltered.c(m,l)=sunfiltered.c(m,l)*W[l];
                sfiltered.s(m,l)=sunfiltered.s(m,l)*W[l];
            }
        }

        sphTrans.inverse(filtered,sfiltered);
        
        for(j=0;j<2*bw;j++)
        for(k=0;k<2*bw;k++)
        {
            out<<90.0-(j+0.5)*(180.0/(2*bw))<<"   "
               <<k*360.0/(2*bw)<<"  "
               <<filtered[j][k]<<endl;
        }        
        
        in.close();  
        out.close();  
		  
        cout<<i+1<<" over "<<numFile<<" done."<<endl;              
    }

 //   system("pause");
    return 0;
}
